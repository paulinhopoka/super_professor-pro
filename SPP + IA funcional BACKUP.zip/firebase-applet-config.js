export const firebaseConfig = {
  "projectId": "gen-lang-client-0786840861",
  "appId": "1:1047277581781:web:a908e0f37f2fe63cb9795c",
  "apiKey": "AIzaSyDXq8ysW6Lb3JUROiUZObz-ONcBJWADt5A",
  "authDomain": "gen-lang-client-0786840861.firebaseapp.com",
  "firestoreDatabaseId": "ai-studio-71d09197-cb18-4b0e-bd39-6c05c890df19",
  "storageBucket": "gen-lang-client-0786840861.firebasestorage.app",
  "messagingSenderId": "1047277581781",
  "measurementId": ""
};
