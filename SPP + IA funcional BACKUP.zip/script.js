import { auth, db, provider, signInWithPopup, signOut, onAuthStateChanged, doc, getDoc, setDoc, onSnapshot, createUserWithEmailAndPassword, signInWithEmailAndPassword } from './firebase.js';
import { GoogleGenAI } from '@google/genai';

document.addEventListener('DOMContentLoaded', () => {
    // --- Seletores Globais (Existentes e Novos) ---
    let showingWhatsNew = false;
    const mainContent = document.getElementById('main-content');
    const sections = document.querySelectorAll('.section');
    const navButtons = document.querySelectorAll('.nav-button');
    const modal = document.getElementById('generic-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const modalFooter = document.getElementById('modal-footer');
    const searchInput = document.getElementById('search-input');
    const authButton = document.getElementById('auth-button');
    const logoutButton = document.getElementById('logout-button');
    const languageSelect = document.getElementById('language-select');
    if (languageSelect) {
        languageSelect.addEventListener('change', (e) => {
            appData.settings.language = e.target.value;
            saveData();
            updateLanguageUI();
        });
    }

    const updateLanguageUI = () => {
        const lang = appData.settings.language || 'pt-BR';
        if (languageSelect) languageSelect.value = lang;
        
        const t = translations[lang];
        if (!t) return;

        // Update navigation buttons
        document.querySelectorAll('.nav-button').forEach(btn => {
            const id = btn.id;
            if (id === 'nav-schedule-button') btn.querySelector('span:not(.icon)').textContent = t.nav_schedule;
            if (id === 'nav-schools-button') btn.querySelector('span:not(.icon)').textContent = t.nav_schools;
            if (id === 'nav-tools-button') btn.querySelector('span:not(.icon)').textContent = t.nav_tools;
            if (id === 'nav-contact-button') btn.querySelector('span:not(.icon)').textContent = t.nav_contact;
            if (id === 'nav-settings-button') btn.querySelector('span:not(.icon)').textContent = t.nav_settings;
        });

        // Update section titles
        document.querySelectorAll('.section > h2').forEach(h2 => {
            const icon = h2.querySelector('.icon');
            if (h2.closest('#schedule-section')) { h2.innerHTML = ''; if(icon) h2.appendChild(icon); h2.appendChild(document.createTextNode(' ' + t.title_schedule)); }
            if (h2.closest('#schools-section')) { h2.innerHTML = ''; if(icon) h2.appendChild(icon); h2.appendChild(document.createTextNode(' ' + t.title_schools)); }
            if (h2.closest('#classes-section')) { h2.innerHTML = ''; if(icon) h2.appendChild(icon); h2.appendChild(document.createTextNode(' ' + t.title_classes)); }
            if (h2.closest('#tools-section')) { h2.innerHTML = ''; if(icon) h2.appendChild(icon); h2.appendChild(document.createTextNode(' ' + t.title_tools)); }
            if (h2.closest('#contact-section')) { h2.innerHTML = ''; if(icon) h2.appendChild(icon); h2.appendChild(document.createTextNode(' ' + t.title_contact)); }
            if (h2.closest('#settings-section')) { h2.innerHTML = ''; if(icon) h2.appendChild(icon); h2.appendChild(document.createTextNode(' ' + t.title_settings)); }
        });

        // Update cards in settings
        const settingsSection = document.getElementById('settings-section');
        if (settingsSection) {
            settingsSection.querySelectorAll('.card h3').forEach(h3 => {
                const icon = h3.querySelector('.icon');
                const text = h3.textContent.trim();
                if (text.includes('Sincronização') || text.includes('Sync') || text.includes('Sincronización')) { h3.innerHTML = ''; if(icon) h3.appendChild(icon); h3.appendChild(document.createTextNode(' ' + t.settings_sync)); }
                else if (text === 'Conta' || text === 'Account' || text === 'Cuenta') { h3.innerHTML = ''; if(icon) h3.appendChild(icon); h3.appendChild(document.createTextNode(' ' + t.settings_account)); }
                else if (text.includes('Temas') || text.includes('Themes')) { h3.innerHTML = ''; if(icon) h3.appendChild(icon); h3.appendChild(document.createTextNode(' ' + t.settings_themes)); }
                else if (text.includes('Dados') || text.includes('Data') || text.includes('Datos')) { h3.innerHTML = ''; if(icon) h3.appendChild(icon); h3.appendChild(document.createTextNode(' ' + t.settings_data)); }
                else if (text.includes('Notificações') || text.includes('Notifications') || text.includes('Notificaciones')) { h3.innerHTML = ''; if(icon) h3.appendChild(icon); h3.appendChild(document.createTextNode(' ' + t.settings_notifications)); }
                else if (text.includes('Novidades') || text.includes('News') || text.includes('Novedades')) { h3.innerHTML = ''; if(icon) h3.appendChild(icon); h3.appendChild(document.createTextNode(' ' + t.settings_news)); }
                else if (text.includes('Navegação') || text.includes('Navigation') || text.includes('Navegación')) { h3.innerHTML = ''; if(icon) h3.appendChild(icon); h3.appendChild(document.createTextNode(' ' + t.settings_nav)); }
                else if (text.includes('Contato') || text.includes('Contact') || text.includes('Contacto')) { h3.innerHTML = ''; if(icon) h3.appendChild(icon); h3.appendChild(document.createTextNode(' ' + t.nav_contact)); }
            });
        }

        // Update other UI elements
        const searchInput = document.getElementById('search-input');
        if (searchInput) searchInput.placeholder = t.search_placeholder;

        const welcomeName = document.getElementById('settings-welcome-name');
        if (welcomeName) {
            const name = appData.userProfile.name || (lang === 'pt-BR' ? 'Professor(a)' : (lang === 'en-US' ? 'Teacher' : 'Profesor(a)'));
            welcomeName.textContent = name;
        }
    };

    const translations = {
        'pt-BR': {
            nav_schedule: 'Horários', nav_schools: 'Escolas', nav_tools: 'Ferramentas', nav_contact: 'Contato', nav_settings: 'Ajustes',
            title_schedule: 'Meus Horários', title_schools: 'Minhas Escolas', title_classes: 'Minhas Turmas', title_tools: 'Ferramentas Úteis', title_contact: 'Contato & Suporte', title_settings: 'Configurações',
            search_placeholder: 'Pesquisar...',
            settings_sync: 'Sincronização e Nuvem', settings_account: 'Conta', settings_themes: 'Temas', settings_data: 'Dados', settings_notifications: 'Notificações de Horários', settings_news: 'Novidades da Versão', settings_nav: 'Navegação'
        },
        'en-US': {
            nav_schedule: 'Schedule', nav_schools: 'Schools', nav_tools: 'Tools', nav_contact: 'Contact', nav_settings: 'Settings',
            title_schedule: 'My Schedule', title_schools: 'My Schools', title_classes: 'My Classes', title_tools: 'Useful Tools', title_contact: 'Contact & Support', title_settings: 'Settings',
            search_placeholder: 'Search...',
            settings_sync: 'Sync & Cloud', settings_account: 'Account', settings_themes: 'Themes', settings_data: 'Data', settings_notifications: 'Schedule Notifications', settings_news: 'Version News', settings_nav: 'Navigation'
        },
        'es-ES': {
            nav_schedule: 'Horarios', nav_schools: 'Escuelas', nav_tools: 'Herramientas', nav_contact: 'Contacto', nav_settings: 'Ajustes',
            title_schedule: 'Mis Horarios', title_schools: 'Mis Escuelas', title_classes: 'Mis Clases', title_tools: 'Herramientas Útiles', title_contact: 'Contacto y Soporte', title_settings: 'Configuraciones',
            search_placeholder: 'Buscar...',
            settings_sync: 'Sincronización y Nube', settings_account: 'Cuenta', settings_themes: 'Temas', settings_data: 'Datos', settings_notifications: 'Notificaciones de Horarios', settings_news: 'Novedades de la Versión', settings_nav: 'Navegación'
        }
    };

    const scheduleListContainer = document.getElementById('schedule-list');
    const schoolListContainer = document.getElementById('school-list');
    const classListContainer = document.getElementById('class-list');
    const classesSchoolName = document.getElementById('classes-school-name');
    const studentListContainer = document.getElementById('student-list-container');
    const classDetailsSection = document.getElementById('class-details-section');
    const classDetailsHeader = document.getElementById('class-details-header');
    const classDetailsTitle = document.getElementById('class-details-title');
    const backToSchoolsButton = document.getElementById('back-to-schools-button');
    const backToClassesButton = document.getElementById('back-to-classes-button');
    const navClassesButton = document.getElementById('nav-classes-button');
    const navDetailsButton = document.getElementById('nav-details-button');
    const gradesTableContainer = document.getElementById('grades-table-container');
    const attendanceTableContainer = document.getElementById('attendance-table-container');
    const gradeSetSelect = document.getElementById('grade-set-select');
    const manageGradeStructureButton = document.getElementById('manage-grade-structure-button');
    const saveGradesButton = document.getElementById('save-grades-button');
    const exportGradesCsvButton = document.getElementById('export-grades-csv-button');
    const exportGradesPdfButton = document.getElementById('export-grades-pdf-button');
    const attendanceDateInput = document.getElementById('attendance-date');
    const saveAttendanceButton = document.getElementById('save-attendance-button');
    const viewMonthlyAttendanceButton = document.getElementById('view-monthly-attendance-button');
    const attendanceActionsContainer = document.getElementById('attendance-actions-container');
    const markAllPresentButton = document.getElementById('mark-all-present-button');
    const markNonSchoolDayButton = document.getElementById('mark-non-school-day-button');
    const lessonPlanDateInput = document.getElementById('lesson-plan-date');
    const lessonPlanTextarea = document.getElementById('lesson-plan-textarea');
    const saveLessonPlanButton = document.getElementById('save-lesson-plan-button');
    const classNotesDisplay = document.getElementById('class-notes-display');
    const classNotesContent = document.getElementById('class-notes-content');
    const classNotesEdit = document.getElementById('class-notes-edit');
    const classNotesTextarea = document.getElementById('class-notes-textarea');
    const editClassNotesButton = document.getElementById('edit-class-notes-button');
    const saveClassNotesButton = document.getElementById('save-class-notes-button');
    const cancelClassNotesButton = document.getElementById('cancel-class-notes-button');
    const addScheduleButton = document.getElementById('add-schedule-button');
    const addSchoolButton = document.getElementById('add-school-button');
    const addClassButton = document.getElementById('add-class-button');
    const addStudentButton = document.getElementById('add-student-button');
    const copyPixButton = document.getElementById('copy-pix-button');
    const pixKeyTextElement = document.getElementById('pix-key-text');
    const notificationBanner = document.getElementById('notification-banner');
    const notificationMessage = document.getElementById('notification-message');
    const notificationCloseButton = document.getElementById('notification-close-button');
    const defaultNotificationSound = document.getElementById('notification-sound-default');
    const enableGlobalNotificationsCheckbox = document.getElementById('enable-global-notifications');
    const enableNotificationSoundCheckbox = document.getElementById('enable-notification-sound');
    const customNotificationSoundInput = document.getElementById('custom-notification-sound-input');
    const customSoundFilenameDisplay = document.getElementById('custom-sound-filename');
    const currentCustomSoundDisplay = document.getElementById('current-custom-sound-display');
    const currentCustomSoundName = document.getElementById('current-custom-sound-name');
    const removeCustomSoundButton = document.getElementById('remove-custom-sound-button');
    const forceSyncButton = document.getElementById('force-sync-button');
    const syncStatusText = document.getElementById('sync-status-text');
    const lastSyncTimeDisplay = document.getElementById('last-sync-time');
    const editMapButton = document.getElementById('edit-map-button');
    const classroomContainerDisplay = document.getElementById('classroom-container-display');
    const classroomContainerEdit = document.getElementById('classroom-container-edit');
    const mapEditArea = document.getElementById('map-edit-area');
    const classroomMapEditControls = document.getElementById('classroom-map-edit-controls');
    const mapRowsInput = document.getElementById('map-rows-input');
    const mapColsInput = document.getElementById('map-cols-input');
    const teacherDeskPositionSelect = document.getElementById('teacher-desk-position-select');
    const unassignedStudentsContainer = document.getElementById('unassigned-students-container');
    const cancelMapEditButton = document.getElementById('cancel-map-edit-button');
    const saveMapButton = document.getElementById('save-map-button');
    const teacherDeskTemplate = document.getElementById('teacher-desk-template');
    const classroomGridTemplate = document.getElementById('classroom-grid-template');
    const toolsGrid = document.querySelector('#tools-section .tools-grid');
    const calculatorModal = document.getElementById('advanced-calculator-modal');
    const calculatorDisplay = document.getElementById('calculator-display');
    const standardCalcSection = document.getElementById('calculator-standard-section');
    const weightedCalcSection = document.getElementById('calculator-weighted-section');
    const calcModeStandardBtn = document.getElementById('calc-mode-standard');
    const calcModeWeightedBtn = document.getElementById('calc-mode-weighted');
    const calcButtonsContainer = document.querySelector('.calculator-buttons');
    const weightedGradeInput = document.getElementById('weighted-grade-input');
    const weightedWeightInput = document.getElementById('weighted-weight-input');
    const addPairButton = document.getElementById('add-pair-button');
    const weightedPairsList = document.getElementById('weighted-pairs-list');
    const calculateWeightedAvgButton = document.getElementById('calculate-weighted-avg-button');
    const weightedAverageResult = document.getElementById('weighted-average-result');
    const helpButton = document.getElementById('details-help-button');
    const whatsNewModal = document.getElementById('whats-new-modal');
    const whatsNewTitle = document.getElementById('whats-new-title');
    const whatsNewBody = document.getElementById('whats-new-body');
    const profileAvatarImg = document.getElementById('profile-avatar-img');
    const profileAvatarPlaceholder = document.getElementById('profile-avatar-placeholder');
    const profileAvatarInput = document.getElementById('profile-avatar-input');
    const profileNameInput = document.getElementById('profile-name-input');
    const saveProfileButton = document.getElementById('save-profile-button');
    const profileAvatarContainer = document.getElementById('profile-avatar-container');

    // --- Novos Seletores para Menu Lateral ---
    const hamburgerMenuButton = document.getElementById('hamburger-menu-button');
    const sideMenu = document.getElementById('side-menu');
    const closeSideMenu = document.getElementById('close-side-menu');
    const sideMenuOverlay = document.getElementById('side-menu-overlay');
    const sideNavButtons = document.querySelectorAll('.side-nav-button');
    const sideNavClassesButton = document.getElementById('side-nav-classes-button');
    const sideNavDetailsButton = document.getElementById('side-nav-details-button');

    // --- Side Menu Logic ---
    const openSideMenu = () => {
        sideMenu.classList.add('open');
        sideMenuOverlay.classList.add('show');
    };

    const closeSideMenuFunc = () => {
        sideMenu.classList.remove('open');
        sideMenuOverlay.classList.remove('show');
    };

    if (hamburgerMenuButton) hamburgerMenuButton.addEventListener('click', openSideMenu);
    if (closeSideMenu) closeSideMenu.addEventListener('click', closeSideMenuFunc);
    if (sideMenuOverlay) sideMenuOverlay.addEventListener('click', closeSideMenuFunc);

    sideNavButtons.forEach(button => {
        button.addEventListener('click', () => {
            const sectionId = button.getAttribute('data-section');
            showSection(sectionId);
            closeSideMenuFunc();
        });
    });

    const sideMenuProfile = document.getElementById('side-menu-profile');
    if (sideMenuProfile) {
        sideMenuProfile.addEventListener('click', () => {
            showSection('profile-section');
            closeSideMenuFunc();
        });
    }

    const closeWhatsNewButton = document.getElementById('close-whats-new');
    const okWhatsNewButton = document.getElementById('ok-whats-new');
    const showWhatsNewManualButton = document.getElementById('show-whats-new-manual-button');

    const weekdays = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
    const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    const NOTIFICATION_LEAD_TIME_MINUTES = 5;
    const MAX_CUSTOM_SOUND_SIZE_MB = 2;
    let notificationCheckInterval = null;
    let shownNotificationsThisMinute = {};
    let draggedStudentId = null;
    let draggedElement = null;
    let tempClassroomLayout = null;
    let selectedSeatForAssignment = null;
    let sorterStudentList = [];
    let sorterAvailableStudents = [];
    let sorterDrawnStudents = [];
    let stopwatchInterval = null;
    let stopwatchSeconds = 0;
    let isStopwatchRunning = false;
    let calculator = { displayValue: '0', firstOperand: null, waitingForSecondOperand: false, operator: null, mode: 'standard', weightedPairs: [] };
    let currentStudentObservations = [];

    let scheduleUpdateInterval = null;

    // ATUALIZADO: Versão do App
    const CURRENT_APP_VERSION = '1.8.2';

    const DATA_STORAGE_KEY = 'superProfessorProData_v15'; // Mantido por enquanto, mas a estrutura interna mudou
    const OLD_DATA_STORAGE_KEY_V14 = 'superProfessorProData_v14';

    let appData = {
        schools: [], classes: [], students: [], schedule: [],
        settings: { theme: 'theme-light', globalNotificationsEnabled: true, notificationSoundEnabled: true, customNotificationSound: null, language: 'pt-BR' },
        userProfile: { name: '', avatar: '' },
        lastUpdated: 0
    };
    let currentSchoolId = null; let currentClassId = null; let currentSection = 'schedule-section';

    // --- Funções de Estado e Persistência ---
    const saveAppState = () => { try { localStorage.setItem('lastSection', currentSection || 'schedule-section'); localStorage.setItem('lastSchoolId', currentSchoolId || ''); localStorage.setItem('lastClassId', currentClassId || ''); } catch (e) { console.error("Erro ao salvar estado:", e); } };
    const restoreAppState = () => { const lastSection = localStorage.getItem('lastSection'); const lastSchoolId = localStorage.getItem('lastSchoolId'); const lastClassId = localStorage.getItem('lastClassId'); console.log("Restoring App State:", {lastSection, lastSchoolId, lastClassId}); currentSection = 'schedule-section'; currentSchoolId = null; currentClassId = null; if (appData.schools.length > 0) { currentSchoolId = lastSchoolId || appData.schools[0].id; if (!findSchoolById(currentSchoolId)) { currentSchoolId = appData.schools[0]?.id || null; currentClassId = null; currentSection = currentSchoolId ? 'classes-section' : 'schools-section'; } else { currentClassId = lastClassId || null; if (currentClassId && !findClassById(currentClassId)) { currentClassId = null; } if (lastSection) { if (lastSection === 'class-details-section' && currentClassId && findClassById(currentClassId)) { currentSection = 'class-details-section'; } else if (lastSection === 'classes-section' && currentSchoolId) { currentSection = 'classes-section'; currentClassId = null; } else if (lastSection === 'schools-section') { currentSection = 'schools-section'; currentSchoolId = null; currentClassId = null; } else if (['schedule-section', 'tools-section', 'contact-section', 'settings-section'].includes(lastSection)){ const sectionExists = document.getElementById(lastSection); if(sectionExists) { currentSection = lastSection; if(['schedule-section', 'tools-section', 'contact-section', 'settings-section'].includes(lastSection)) { currentSchoolId = null; currentClassId = null; } } else { currentSection = currentSchoolId ? 'classes-section' : 'schools-section'; currentClassId = null; } } else { currentSection = currentSchoolId ? 'classes-section' : 'schools-section'; currentClassId = null; } } else { if (currentClassId) currentSection = 'class-details-section'; else if (currentSchoolId) currentSection = 'classes-section'; else currentSection = 'schools-section'; } } } else { currentSection = 'schedule-section'; } if(['contact-section', 'settings-section', 'tools-section'].includes(lastSection)){ currentSection = lastSection; } console.log(`Estado Final Restaurado: Section=${currentSection}, School=${currentSchoolId}, Class=${currentClassId}`); };
    const saveData = () => { 
        try { 
            appData.lastUpdated = Date.now();
            localStorage.setItem(DATA_STORAGE_KEY, JSON.stringify(appData)); 
            console.log(`Data saved (${DATA_STORAGE_KEY}).`); 
            if (typeof saveToFirestore === 'function') { 
                saveToFirestore(); 
            } 
        } catch (e) { 
            console.error("Erro salvar:", e); 
            if (e.name === 'QuotaExceededError') { 
                alert("Erro: Não há espaço suficiente para salvar os dados. Isso pode ser devido a um arquivo de som personalizado muito grande."); 
            } else { 
                alert("Erro ao salvar dados."); 
            } 
        } 
    };
    const loadData = () => {
        console.log("loadData called");
        let dataToParse = localStorage.getItem(DATA_STORAGE_KEY);
        let importedVersion = 15; // Assuming current data is effectively v15 structure before this change
        if (!dataToParse) {
            const dataV14 = localStorage.getItem(OLD_DATA_STORAGE_KEY_V14);
            if (dataV14) { console.log("Importing data from v14..."); dataToParse = dataV14; importedVersion = 14; }
        }
        if (dataToParse) {
            try {
                appData = JSON.parse(dataToParse);
                appData.schools = appData.schools || [];
                appData.classes = appData.classes || [];
                appData.students = appData.students || [];
                appData.schedule = appData.schedule || [];
                appData.settings = appData.settings || {};
                appData.settings.theme = appData.settings.theme || 'theme-light';
                appData.settings.navStyle = appData.settings.navStyle || 'fixed';
                appData.settings.globalNotificationsEnabled = appData.settings.globalNotificationsEnabled !== undefined ? appData.settings.globalNotificationsEnabled : true;
                appData.settings.notificationSoundEnabled = appData.settings.notificationSoundEnabled !== undefined ? appData.settings.notificationSoundEnabled : true;
                appData.settings.customNotificationSound = appData.settings.customNotificationSound || null;
                appData.settings.language = appData.settings.language || 'pt-BR';
                appData.userProfile = appData.userProfile || { name: '', avatar: '' };

                appData.classes.forEach(c => {
                    c.notes = c.notes || ''; c.schoolId = c.schoolId || null;
                    c.gradeStructure = c.gradeStructure || [];
                    c.gradeStructure.forEach(gs => { delete gs.periodType; if (gs.colorRanges === undefined) { gs.colorRanges = []; } });
                    c.lessonPlans = c.lessonPlans || {};
                    if (!c.classroomLayout) { c.classroomLayout = { rows: 5, cols: 6, teacherDeskPosition: 'top-center', seats: [] }; } else { c.classroomLayout.seats = c.classroomLayout.seats || []; const validPositions = ['top-left', 'top-center', 'top-right', 'bottom-left', 'bottom-center', 'bottom-right', 'left-top', 'left-center', 'left-bottom', 'right-top', 'right-center', 'right-bottom']; if (!validPositions.includes(c.classroomLayout.teacherDeskPosition)) { c.classroomLayout.teacherDeskPosition = 'top-center'; } }
                    if (c.representativeId === undefined) c.representativeId = null;
                    if (c.viceRepresentativeId === undefined) c.viceRepresentativeId = null;
                });
                appData.students.forEach(s => {
                    s.grades = s.grades || {}; s.attendance = s.attendance || {};
                    Object.keys(s.attendance).forEach(date => { const record = s.attendance[date]; if (record && typeof record === 'object') { record.status = record.status || null; record.justification = String(record.justification || ''); } else { s.attendance[date] = { status: null, justification: '' }; } });
                    s.notes = s.notes || [];
                    if (typeof s.notes === 'string') { const oldNotes = s.notes.trim(); s.notes = oldNotes ? [{ date: getCurrentDateString(), text: oldNotes, category: 'Anotação' }] : []; }
                    else if (!Array.isArray(s.notes)) { s.notes = []; }
                    s.notes = s.notes.map(note => ({
                         date: note?.date && note.date !== 'N/A' ? note.date : getCurrentDateString(),
                         text: note?.text || '',
                         category: note?.category || 'Anotação',
                         suspensionStartDate: note?.suspensionStartDate || null,
                         suspensionEndDate: note?.suspensionEndDate || null
                     })).filter(note => note.text.trim());
                    // **** NOVO: Inicializa campo de programas governamentais ****
                    s.governmentPrograms = Array.isArray(s.governmentPrograms) ? s.governmentPrograms : [];
                 });
                appData.schedule.forEach(item => { if (item.notificationsEnabled === undefined) { item.notificationsEnabled = true; } });

                console.log(`Data loaded (from version ${importedVersion}):`, appData);

                // Se os dados foram migrados de uma versão mais antiga que a atual lógica base (v15),
                // salva para consolidar as migrações.
                if (importedVersion < 15) { // Se importou de v14 ou anterior
                    saveData(); // Salva com as migrações até v15 + a nova de governmentPrograms
                    if (localStorage.getItem(OLD_DATA_STORAGE_KEY_V14)) {
                         localStorage.removeItem(OLD_DATA_STORAGE_KEY_V14);
                    }
                    console.log(`Migrated data saved as ${DATA_STORAGE_KEY}.`);
                }
                updateLanguageUI();
                return true;
            } catch (e) {
                console.error("Erro ao carregar ou migrar dados:", e);
                appData = { schools: [], classes: [], students: [], schedule: [], settings: { theme: 'theme-light', globalNotificationsEnabled: true, notificationSoundEnabled: true, customNotificationSound: null, language: 'pt-BR' }, userProfile: { name: '', avatar: '' } };
                // Inicializa campo para novos dados vazios
                appData.students.forEach(s => s.governmentPrograms = []);
                localStorage.removeItem(OLD_DATA_STORAGE_KEY_V14);
                localStorage.removeItem(DATA_STORAGE_KEY);
                updateLanguageUI();
                return false;
            }
        } else {
            appData = { schools: [], classes: [], students: [], schedule: [], settings: { theme: 'theme-light', globalNotificationsEnabled: true, notificationSoundEnabled: true, customNotificationSound: null, language: 'pt-BR' }, userProfile: { name: '', avatar: '' } };
            // Inicializa campo para novos dados vazios
            appData.students.forEach(s => s.governmentPrograms = []);
            updateLanguageUI();
            return false;
        }
    };

    // --- Funções Utilitárias ---
    const generateId = (prefix = 'id') => `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const applyTheme = (themeName) => { 
        // Remove existing theme classes
        const themeClasses = Array.from(document.body.classList).filter(cls => cls.startsWith('theme-'));
        themeClasses.forEach(cls => document.body.classList.remove(cls));
        
        // Add new theme class
        document.body.classList.add(themeName || 'theme-light');
        
        appData.settings.theme = themeName; 
        const themeSelect = document.getElementById('theme-select');
        if (themeSelect) {
            themeSelect.value = themeName;
        }
    };
    const applyNavStyle = (navStyle) => {
        console.log("Applying nav style:", navStyle);
        appData.settings.navStyle = navStyle || 'fixed';
        document.body.classList.remove('nav-side');
        
        if (appData.settings.navStyle === 'side') {
            document.body.classList.add('nav-side');
        }
        
        const select = document.getElementById('nav-style-select');
        if (select) select.value = appData.settings.navStyle;
        saveData();
    };
    const showSection = (sectionId) => { 
        sections.forEach(section => section.classList.toggle('active', section.id === sectionId)); 
        navButtons.forEach(button => button.classList.toggle('active', button.dataset.section === sectionId)); 
        sideNavButtons.forEach(button => button.classList.toggle('active', button.dataset.section === sectionId));
        
        currentSection = sectionId; 
        navClassesButton.disabled = !currentSchoolId; 
        navDetailsButton.disabled = !currentClassId; 
        sideNavClassesButton.disabled = !currentSchoolId;
        sideNavDetailsButton.disabled = !currentClassId;
        
        document.querySelectorAll('.fab-button').forEach(fab => { if (fab.id !== 'floating-nav-toggle') fab.classList.add('hidden'); }); 
        let fabToShow = null; 
        if (sectionId === 'schedule-section') fabToShow = addScheduleButton; 
        else if (sectionId === 'schools-section') fabToShow = addSchoolButton; 
        else if (sectionId === 'classes-section') fabToShow = addClassButton; 
        
        if (fabToShow) fabToShow.classList.remove('hidden'); 
        mainContent.scrollTop = 0; 
        saveAppState(); 
        if (sectionId === 'settings-section') { updateNotificationSettingsUI(); updateCustomSoundUI(); } 
        if (sectionId === 'schedule-section') { startScheduleUpdates(); } else { stopScheduleUpdates(); } 
    };
    const showModal = (title, contentHtml, footerButtonsHtml = '', modalClass = '') => { 
        modalTitle.textContent = title; 
        modalBody.innerHTML = contentHtml; 
        const defaultFooter = `<button type="button" data-dismiss="modal" class="secondary">Fechar</button>`; 
        // Otimização: Se já houver um botão de fechar/cancelar ou for um modal de decisão, não adiciona o "Fechar" padrão
        if (footerButtonsHtml.includes('data-dismiss="modal"') || 
            modalClass === 'login-prompt-modal' || 
            modalClass === 'sync-conflict-modal') {
            modalFooter.innerHTML = footerButtonsHtml;
        } else {
            modalFooter.innerHTML = footerButtonsHtml ? footerButtonsHtml + defaultFooter : defaultFooter; 
        }
        modal.className = 'modal'; 
        if (modalClass) modal.classList.add(modalClass); 
        modal.classList.add('show'); 
        

        modal.querySelectorAll('[data-dismiss="modal"]').forEach(btn => { 
            const newBtn = btn.cloneNode(true); 
            btn.parentNode.replaceChild(newBtn, btn); 
            newBtn.addEventListener('click', hideModal); 
        }); 
    };
    const hideModal = () => { 
        if (stopwatchInterval) { clearInterval(stopwatchInterval); stopwatchInterval = null; isStopwatchRunning = false; } 
        modal.classList.remove('show'); 
        calculatorModal?.classList.remove('show'); 
        const aiToolModal = document.getElementById('ai-tool-modal');
        if (aiToolModal) aiToolModal.classList.remove('show');
        setTimeout(() => { modalTitle.textContent = ''; modalBody.innerHTML = ''; modalFooter.innerHTML = ''; modal.className = 'modal'; }, 300); 
    };

    const showAlert = (message, title = 'Alerta') => {
        showModal(title, `<p style="text-align: center; padding: 1rem;">${message}</p>`, `<button type="button" class="primary" data-dismiss="modal">OK</button>`);
    };

    const showConfirm = (message, onConfirm, title = 'Confirmação') => {
        const footer = `
            <button type="button" class="secondary" data-dismiss="modal">Cancelar</button>
            <button type="button" class="danger" id="confirm-action-button">Confirmar</button>
        `;
        showModal(title, `<p style="text-align: center; padding: 1rem;">${message}</p>`, footer);
        document.getElementById('confirm-action-button').onclick = () => {
            onConfirm();
            hideModal();
        };
    };

    const alert = showAlert;
    const confirm = (msg) => {
        console.warn("Uso de confirm() síncrono detectado. Use showConfirm() para melhor experiência em iframe.");
        return window.confirm(msg);
    };
    const findSchoolById = (id) => appData.schools.find(s => s.id === id);
    const findClassById = (id) => appData.classes.find(c => c.id === id);
    const findStudentById = (id) => appData.students.find(s => s.id === id);
    const findScheduleById = (id) => appData.schedule.find(sch => sch.id === id);
    const getStudentsByClass = (classId) => appData.students.filter(s => s.classId === classId).sort((a, b) => { const numA = parseInt(a.number) || Infinity; const numB = parseInt(b.number) || Infinity; if (numA !== numB) return numA - numB; return a.name.localeCompare(b.name); });
    const formatDate = (dateString) => { if(!dateString || dateString === 'N/A') return 'Data Indefinida'; try { const [y, m, d] = dateString.split('-'); if (isNaN(new Date(y, m-1, d).getTime())) return 'Data Inválida'; return `${d}/${m}/${y}`; } catch { return dateString; } };
    const getCurrentDateString = () => new Date().toISOString().slice(0, 10);
    const getYesterdayDateString = () => { const d = new Date(); d.setDate(d.getDate() - 1); return d.toISOString().slice(0, 10); };
    const getDaysInMonth = (year, month) => new Date(year, month + 1, 0).getDate();
    const getDayOfWeek = (year, month, day) => new Date(year, month, day).getDay();
    const sanitizeHTML = (str) => { if (str === null || str === undefined) return ''; const temp = document.createElement('div'); temp.textContent = String(str); return temp.innerHTML; };
    const customConfirm = (message) => {
        return new Promise((resolve) => {
            const overlay = document.createElement('div');
            overlay.className = 'modal-overlay show';
            overlay.style.zIndex = '9999';
            overlay.innerHTML = `
                <div class="modal-content" style="max-width: 400px; text-align: center;">
                    <h3 style="margin-top: 0;">Confirmação</h3>
                    <p style="white-space: pre-wrap; margin: 20px 0;">${sanitizeHTML(message)}</p>
                    <div style="display: flex; justify-content: center; gap: 10px;">
                        <button class="custom-confirm-yes danger">Sim</button>
                        <button class="custom-confirm-no secondary">Não</button>
                    </div>
                </div>
            `;
            document.body.appendChild(overlay);
            
            overlay.querySelector('.custom-confirm-yes').onclick = () => {
                document.body.removeChild(overlay);
                resolve(true);
            };
            overlay.querySelector('.custom-confirm-no').onclick = () => {
                document.body.removeChild(overlay);
                resolve(false);
            };
        });
    };

    const customAlert = (message) => {
        return new Promise((resolve) => {
            const overlay = document.createElement('div');
            overlay.className = 'modal-overlay show';
            overlay.style.zIndex = '9999';
            overlay.innerHTML = `
                <div class="modal-content" style="max-width: 400px; text-align: center;">
                    <h3 style="margin-top: 0;">Aviso</h3>
                    <p style="white-space: pre-wrap; margin: 20px 0;">${sanitizeHTML(message)}</p>
                    <div style="display: flex; justify-content: center;">
                        <button class="custom-alert-ok primary">OK</button>
                    </div>
                </div>
            `;
            document.body.appendChild(overlay);
            
            overlay.querySelector('.custom-alert-ok').onclick = () => {
                document.body.removeChild(overlay);
                resolve(true);
            };
        });
    };
    function getContrastYIQ(hexcolor){ if (!hexcolor || hexcolor.length < 4) return '#000000'; hexcolor = hexcolor.replace("#", ""); let r,g,b; if (hexcolor.length === 3) { r = parseInt(hexcolor.substr(0,1)+hexcolor.substr(0,1), 16); g = parseInt(hexcolor.substr(1,1)+hexcolor.substr(1,1), 16); b = parseInt(hexcolor.substr(2,1)+hexcolor.substr(2,1), 16); } else if (hexcolor.length === 6) { r = parseInt(hexcolor.substr(0,2), 16); g = parseInt(hexcolor.substr(2,2), 16); b = parseInt(hexcolor.substr(4,2), 16); } else { return '#000000'; } const yiq = ((r*299)+(g*587)+(b*114))/1000; return (yiq >= 128) ? '#000000' : '#FFFFFF'; }
    const getGradeBackgroundColor = (value, ranges) => { if (value === null || value === undefined || !Array.isArray(ranges) || ranges.length === 0) { return null; } const numericValue = parseFloat(value); if (isNaN(numericValue)) { return null; } for (const range of ranges) { const min = parseFloat(range.min); const max = parseFloat(range.max); if (!isNaN(min) && !isNaN(max) && numericValue >= min && numericValue <= max) { return range.color; } } return null; };
    const applyGradeColor = (element, value, ranges) => { const bgColor = getGradeBackgroundColor(value, ranges); if (bgColor) { element.style.backgroundColor = bgColor; element.style.color = getContrastYIQ(bgColor); } else { element.style.backgroundColor = ''; element.style.color = ''; } };
    const calculateSchoolQuorum = (schoolId, dateString, shiftFilter = "Geral") => { const classesInSchool = appData.classes.filter(c => c.schoolId === schoolId); if (classesInSchool.length === 0) { return { present: 0, total: 0, percentage: 0, message: "Sem turmas" }; } const filteredClasses = shiftFilter === "Geral" ? classesInSchool : classesInSchool.filter(c => c.shift === shiftFilter); if (filteredClasses.length === 0 && shiftFilter !== "Geral") { return { present: 0, total: 0, percentage: 0, message: `Sem turmas (${shiftFilter})` }; } const filteredClassIds = new Set(filteredClasses.map(c => c.id)); const studentsInFilter = appData.students.filter(s => filteredClassIds.has(s.classId)); let presentCount = 0; let totalStudentsInFilter = studentsInFilter.length; if (totalStudentsInFilter === 0) { if(shiftFilter === "Geral" && classesInSchool.length > 0) { return { present: 0, total: 0, percentage: 0, message: "Sem alunos" }; } else if (shiftFilter !== "Geral") { return { present: 0, total: 0, percentage: 0, message: `Sem alunos (${shiftFilter})` }; } else { return { present: 0, total: 0, percentage: 0, message: "Sem alunos" }; } } studentsInFilter.forEach(student => { const attendanceRecord = student.attendance?.[dateString]; if (attendanceRecord?.status === 'P') { presentCount++; } }); const percentage = totalStudentsInFilter > 0 ? Math.round((presentCount / totalStudentsInFilter) * 100) : 0; return { present: presentCount, total: totalStudentsInFilter, percentage: percentage }; };
    const isStudentSuspendedOnDate = (studentId, dateString) => { const student = findStudentById(studentId); if (!student || !Array.isArray(student.notes) || !dateString) return null; return student.notes.find(note => note.category === 'Suspensão' && note.suspensionStartDate && note.suspensionEndDate && dateString >= note.suspensionStartDate && dateString <= note.suspensionEndDate); };
    const timeToMinutes = (timeString) => { if (!timeString || !timeString.includes(':')) return NaN; const [hours, minutes] = timeString.split(':').map(Number); if (isNaN(hours) || isNaN(minutes)) return NaN; return hours * 60 + minutes; };

    // --- Funções de Renderização ---
    const renderScheduleList = () => { scheduleListContainer.innerHTML = ''; if (appData.schedule.length === 0) { scheduleListContainer.innerHTML = '<p style="text-align: center; padding: 1rem;">Nenhum horário cadastrado.</p>'; return; } const now = new Date(); const currentDayIndex = now.getDay(); const currentDayName = weekdays[currentDayIndex]; const currentTimeInMinutes = now.getHours() * 60 + now.getMinutes(); const scheduleByDay = {}; weekdays.forEach(day => scheduleByDay[day] = []); appData.schedule.forEach(item => { if (scheduleByDay[item.day]) scheduleByDay[item.day].push(item); }); const scheduleTemplate = document.getElementById('schedule-item-template'); const fragment = document.createDocumentFragment(); weekdays.forEach((day, dayIndex) => { const itemsForDay = scheduleByDay[day]; if (itemsForDay.length > 0) { itemsForDay.sort((a, b) => (timeToMinutes(a.startTime) || 0) - (timeToMinutes(b.startTime) || 0)); const dayGroup = document.createElement('div'); dayGroup.classList.add('schedule-day-group'); const dayTitle = document.createElement('h3'); dayTitle.classList.add('schedule-day-title'); dayTitle.textContent = (dayIndex === currentDayIndex) ? `${day} (Hoje)` : day; dayGroup.appendChild(dayTitle); let nextItemFoundForToday = false; itemsForDay.forEach(item => { const clone = scheduleTemplate.content.cloneNode(true); const scheduleElement = clone.querySelector('.schedule-item'); const progressBar = clone.querySelector('.progress-bar'); scheduleElement.dataset.id = item.id; const startMinutes = timeToMinutes(item.startTime); const endMinutes = timeToMinutes(item.endTime); scheduleElement.dataset.startMinutes = isNaN(startMinutes) ? '' : String(startMinutes); scheduleElement.dataset.endMinutes = isNaN(endMinutes) ? '' : String(endMinutes); const school = findSchoolById(item.schoolId); scheduleElement.querySelector('.schedule-time').textContent = `${item.startTime || '?'} - ${item.endTime || '?'}`; scheduleElement.querySelector('.school-name').textContent = school ? sanitizeHTML(school.name) : 'Escola não encontrada'; scheduleElement.querySelector('.note').textContent = sanitizeHTML(item.note || ''); const notificationButton = clone.querySelector('.notification-toggle-button'); const notificationIndicator = clone.querySelector('.notification-indicator'); updateNotificationIcon(notificationIndicator, item.notificationsEnabled); notificationButton.addEventListener('click', (e) => { e.stopPropagation(); toggleScheduleNotification(item.id, notificationIndicator); }); clone.querySelector('.edit-schedule-button').addEventListener('click', (e) => { e.stopPropagation(); openScheduleModal(item.id); }); clone.querySelector('.delete-schedule-button').addEventListener('click', (e) => { e.stopPropagation(); if (confirm(`Excluir horário (${item.startTime} na ${school?.name || 'escola'})?`)) { deleteScheduleEntry(item.id); } }); if (dayIndex === currentDayIndex && !isNaN(startMinutes) && !isNaN(endMinutes)) { const isCurrent = currentTimeInMinutes >= startMinutes && currentTimeInMinutes < endMinutes; const isUpcoming = currentTimeInMinutes < startMinutes; if (isCurrent) { scheduleElement.classList.add('current'); const duration = endMinutes - startMinutes; const elapsed = currentTimeInMinutes - startMinutes; const progress = duration > 0 ? Math.min(100, Math.max(0, (elapsed / duration) * 100)) : 0; if (progressBar) progressBar.style.width = `${progress}%`; } else if (isUpcoming && !nextItemFoundForToday) { scheduleElement.classList.add('next'); nextItemFoundForToday = true; if (progressBar) progressBar.style.width = '0%'; } else { if (progressBar) progressBar.style.width = '0%'; } } else { if (progressBar) progressBar.style.width = '0%'; } dayGroup.appendChild(clone); }); fragment.appendChild(dayGroup); } }); scheduleListContainer.appendChild(fragment); };
    const updateNotificationIcon = (indicatorElement, isEnabled) => { if (!indicatorElement) return; indicatorElement.classList.remove('icon-notificacao-on', 'icon-notificacao-off'); if (isEnabled) { indicatorElement.classList.add('icon-notificacao-on'); indicatorElement.parentElement.title = "Notificações Ativadas (Clique para desativar)"; } else { indicatorElement.classList.add('icon-notificacao-off'); indicatorElement.parentElement.title = "Notificações Desativadas (Clique para ativar)"; } };
    const renderSchoolList = () => { schoolListContainer.innerHTML = ''; if (appData.schools.length === 0) { schoolListContainer.innerHTML = '<p style="text-align: center; padding: 1rem;">Nenhuma escola cadastrada.</p>'; return; } const template = document.getElementById('school-item-template'); const today = getCurrentDateString(); appData.schools.sort((a, b) => a.name.localeCompare(b.name)).forEach(school => { const clone = template.content.cloneNode(true); const item = clone.querySelector('.list-item'); item.dataset.id = school.id; item.querySelector('.school-name').textContent = sanitizeHTML(school.name); item.querySelector('.view-classes-button').addEventListener('click', (e) => { e.stopPropagation(); selectSchool(school.id); showSection('classes-section'); }); item.querySelector('.edit-school-button').addEventListener('click', (e) => { e.stopPropagation(); openSchoolModal(school.id); }); item.querySelector('.delete-school-button').addEventListener('click', (e) => { e.stopPropagation(); if (confirm(`Excluir escola "${sanitizeHTML(school.name)}" e TODOS os dados associados (turmas, alunos, etc.)?`)) { deleteSchool(school.id); } }); const quorumContainer = item.querySelector('.school-quorum-info'); const quorumDateInput = quorumContainer.querySelector('.quorum-date-input'); const quorumShiftSelect = quorumContainer.querySelector('.quorum-shift-select'); const quorumDisplay = quorumContainer.querySelector('.quorum-display'); const quorumDateLabel = quorumContainer.querySelector('label[for="quorum-date-input-ID_ESCOLA"]'); const uniqueId = `quorum-date-input-${school.id}`; if (quorumDateLabel) quorumDateLabel.setAttribute('for', uniqueId); if (quorumDateInput) { quorumDateInput.id = uniqueId; quorumDateInput.value = today; quorumDateInput.addEventListener('click', (e) => e.stopPropagation()); } if (quorumShiftSelect) { quorumShiftSelect.addEventListener('click', (e) => e.stopPropagation()); } const updateQuorumDisplay = () => { const selectedDate = quorumDateInput.value; const selectedShift = quorumShiftSelect.value; if (!selectedDate) { quorumDisplay.textContent = 'Data inválida'; quorumDisplay.classList.add('no-data'); quorumDisplay.title = 'Selecione uma data válida'; return; } const quorumData = calculateSchoolQuorum(school.id, selectedDate, selectedShift); quorumDisplay.classList.remove('no-data'); if (quorumData.message) { quorumDisplay.textContent = `(${quorumData.message})`; quorumDisplay.classList.add('no-data'); if (quorumData.message.includes('Sem turmas')) { quorumDisplay.title = `Não há turmas cadastradas para calcular o quórum (${selectedShift}) em ${formatDate(selectedDate)}`; } else if (quorumData.message.includes('Sem alunos')) { quorumDisplay.title = `Não há alunos cadastrados nas turmas para calcular o quórum (${selectedShift}) em ${formatDate(selectedDate)}`; } else { quorumDisplay.title = quorumData.message; } } else { quorumDisplay.textContent = `${quorumData.present}/${quorumData.total} (${quorumData.percentage}%)`; quorumDisplay.title = `${quorumData.present} de ${quorumData.total} alunos presentes (${selectedShift}) em ${formatDate(selectedDate)}`; } }; quorumDateInput.addEventListener('change', updateQuorumDisplay); quorumShiftSelect.addEventListener('change', updateQuorumDisplay); updateQuorumDisplay(); item.addEventListener('click', (e) => { if (!e.target.closest('.school-quorum-info, .list-item-actions')) { selectSchool(school.id); showSection('classes-section'); } }); schoolListContainer.appendChild(clone); }); };
    const renderClassList = (schoolId) => { classListContainer.innerHTML = ''; const school = findSchoolById(schoolId); classesSchoolName.textContent = school ? sanitizeHTML(school.name) : 'Selecione Escola'; if (!school) { classListContainer.innerHTML = '<p style="text-align: center; padding: 1rem;">Escola não encontrada.</p>'; return; } const classesInSchool = appData.classes.filter(c => c.schoolId === schoolId); if (classesInSchool.length === 0) { classListContainer.innerHTML = `<p style="text-align: center; padding: 1rem;">Nenhuma turma cadastrada para ${sanitizeHTML(school.name)}.</p>`; return; } const template = document.getElementById('class-item-template'); classesInSchool.sort((a, b) => a.name.localeCompare(b.name)).forEach(cls => { const clone = template.content.cloneNode(true); const item = clone.querySelector('.list-item'); item.dataset.id = cls.id; const itemInfo = item.querySelector('.item-info'); itemInfo.querySelector('.class-name').textContent = sanitizeHTML(cls.name); itemInfo.querySelector('.class-details').textContent = `${sanitizeHTML(cls.subject || 'Sem matéria')} - ${sanitizeHTML(cls.shift || 'Sem turno')} - ${sanitizeHTML(cls.schedule || 'Sem horário')}`; if(cls.id === currentClassId) item.classList.add('active'); const actions = item.querySelector('.list-item-actions'); actions.querySelector('.view-details-button').addEventListener('click', (e) => { e.stopPropagation(); selectClass(cls.id); showSection('class-details-section'); }); actions.querySelector('.edit-class-button').addEventListener('click', (e) => { e.stopPropagation(); openClassModal(cls.id); }); actions.querySelector('.delete-class-button').addEventListener('click', (e) => { e.stopPropagation(); if (confirm(`Excluir turma "${sanitizeHTML(cls.name)}" e TODOS os dados associados?`)) { deleteClass(cls.id); } }); item.addEventListener('click', () => { selectClass(cls.id); showSection('class-details-section'); }); classListContainer.appendChild(clone); }); };
    const renderStudentList = (classId) => {
        studentListContainer.innerHTML = '';
        const studentsInClass = getStudentsByClass(classId);
        const cls = findClassById(classId);
        if (studentsInClass.length === 0) {
            studentListContainer.innerHTML = '<p style="text-align: center; padding: 1rem;">Nenhum aluno nesta turma ainda.</p>';
            return;
        }
        const template = document.getElementById('student-list-item-template');
        studentsInClass.forEach(std => {
            const clone = template.content.cloneNode(true);
            const item = clone.querySelector('.list-item');
            const wrapper = item.querySelector('.list-item-content-wrapper');
            const mainRow = wrapper.querySelector('.list-item-main-row');
            const hiddenActions = wrapper.querySelector('.list-item-hidden-actions');
            item.dataset.id = std.id;
            mainRow.querySelector('.student-number').textContent = std.number ? `${std.number}.` : '-.';
            mainRow.querySelector('.student-name').textContent = sanitizeHTML(std.name);

            // **** NOVO: Renderizar indicadores de programas governamentais ****
            const programsIndicatorContainer = mainRow.querySelector('.student-programs-indicator');
            if (programsIndicatorContainer) {
                programsIndicatorContainer.innerHTML = ''; // Limpa badges antigos
                if (std.governmentPrograms && std.governmentPrograms.length > 0) {
                    std.governmentPrograms.forEach(program => {
                        const badge = document.createElement('span');
                        badge.classList.add('program-badge');
                        let badgeText = '';
                        let programKey = '';

                        if (program === 'Bolsa Família') {
                            badgeText = 'BF';
                            programKey = 'bolsa-familia';
                        } else if (program === 'Pé de Meia') {
                            badgeText = 'PM';
                            programKey = 'pe-de-meia';
                        } else { // Fallback para outros programas não mapeados
                            badgeText = program.substring(0, 2).toUpperCase();
                            programKey = program.toLowerCase().replace(/[^a-z0-9]/g, '-');
                        }
                        badge.textContent = badgeText;
                        badge.title = program;
                        badge.classList.add(`program-badge-${programKey}`);
                        programsIndicatorContainer.appendChild(badge);
                    });
                }
            }
            // **** FIM: Indicadores de programas ****

            const expandButton = mainRow.querySelector('.expand-actions-button');
            expandButton.addEventListener('click', (e) => { e.stopPropagation(); toggleActions(item); });
            const moveButton = hiddenActions.querySelector('.move-student-button');
            if (moveButton) { moveButton.addEventListener('click', (e) => { e.stopPropagation(); openMoveStudentModal(std.id); }); }
            const repBtn = hiddenActions.querySelector('.set-representative-button');
            const viceBtn = hiddenActions.querySelector('.set-vice-button');
            const notesBtn = hiddenActions.querySelector('.notes-student-button');
            const editBtn = hiddenActions.querySelector('.edit-student-button');
            const deleteBtn = hiddenActions.querySelector('.delete-student-button');
            if (cls?.representativeId === std.id) { item.classList.add('representative'); if (repBtn) repBtn.title = "Remover Rep."; }
            else { if (repBtn) repBtn.title = "Promover a Rep."; }
            if (cls?.viceRepresentativeId === std.id) { item.classList.add('vice-representative'); if (viceBtn) viceBtn.title = "Remover Vice"; }
            else { if (viceBtn) viceBtn.title = "Promover a Vice"; }
            repBtn?.addEventListener('click', (e) => { e.stopPropagation(); toggleRepresentative(std.id); });
            viceBtn?.addEventListener('click', (e) => { e.stopPropagation(); toggleViceRepresentative(std.id); });
            notesBtn?.addEventListener('click', (e) => { e.stopPropagation(); openStudentNotesModal(std.id); });
            editBtn?.addEventListener('click', (e) => { e.stopPropagation(); openStudentModal(std.id); });
            deleteBtn?.addEventListener('click', (e) => { e.stopPropagation(); if (confirm(`Excluir aluno "${sanitizeHTML(std.name)}"?`)) { deleteStudent(std.id); } });
            studentListContainer.appendChild(clone);
        });
    };
    const renderGradeSets = (classId) => { gradeSetSelect.innerHTML = ''; const currentClass = findClassById(classId); if (!currentClass || !currentClass.gradeStructure || currentClass.gradeStructure.length === 0) { gradeSetSelect.innerHTML = '<option value="">Configure</option>'; gradesTableContainer.innerHTML = '<p style="padding: 1rem; text-align: center;">Configure a estrutura de notas clicando no ícone <span class="icon icon-estrutura"></span>.</p>'; saveGradesButton.classList.add('hidden'); manageGradeStructureButton.style.borderColor = 'var(--accent-warning)'; exportGradesCsvButton.classList.add('hidden'); exportGradesPdfButton.classList.add('hidden'); return; } manageGradeStructureButton.style.borderColor = 'transparent'; currentClass.gradeStructure.forEach(gs => { const option = document.createElement('option'); option.value = gs.id; option.textContent = sanitizeHTML(gs.name); gradeSetSelect.appendChild(option); }); if (getStudentsByClass(classId).length > 0) { renderGradesTable(classId, gradeSetSelect.value); } else { gradesTableContainer.innerHTML = '<p style="padding: 1rem; text-align: center;">Adicione alunos para registrar notas.</p>'; saveGradesButton.classList.add('hidden'); exportGradesCsvButton.classList.add('hidden'); exportGradesPdfButton.classList.add('hidden'); } };
    const renderGradesTable = (classId, gradeSetId) => { gradesTableContainer.innerHTML = ''; const currentClass = findClassById(classId); const gradeSet = currentClass?.gradeStructure?.find(gs => gs.id === gradeSetId); const studentsInClass = getStudentsByClass(classId); const colorRanges = gradeSet?.colorRanges || []; if (!gradeSet || studentsInClass.length === 0) { gradesTableContainer.innerHTML = `<p style="padding: 1rem; text-align: center;">${!gradeSet ? 'Selecione um conjunto de notas válido.' : 'Nenhum aluno para exibir notas.'}</p>`; saveGradesButton.classList.add('hidden'); if(exportGradesCsvButton) exportGradesCsvButton.classList.add('hidden'); if(exportGradesPdfButton) exportGradesPdfButton.classList.add('hidden'); return; } saveGradesButton.classList.remove('hidden'); if(exportGradesCsvButton) exportGradesCsvButton.classList.remove('hidden'); if(exportGradesPdfButton) exportGradesPdfButton.classList.remove('hidden'); const table = document.createElement('table'); table.classList.add('data-table'); const thead = table.createTHead(); const tbody = table.createTBody(); const headerRow = thead.insertRow(); const headerTemplate = document.getElementById('grades-header-template'); const headerContent = headerTemplate.content.cloneNode(true); headerRow.appendChild(headerContent.querySelector('.student-col').cloneNode(true)); gradeSet.gradeLabels.forEach(label => { const th = document.createElement('th'); th.classList.add('grade-col'); th.textContent = sanitizeHTML(label); headerRow.appendChild(th); }); headerRow.appendChild(headerContent.querySelector('.sum-col').cloneNode(true)); headerRow.appendChild(headerContent.querySelector('.avg-col').cloneNode(true)); const rowTemplate = document.getElementById('grades-row-template'); studentsInClass.forEach(std => { const clone = rowTemplate.content.cloneNode(true); const row = clone.querySelector('tr'); row.dataset.studentId = std.id; const studentCol = row.querySelector('.student-col'); if(studentCol) { studentCol.querySelector('.student-number').textContent = std.number ? `${std.number}.` : '-.'; studentCol.querySelector('.student-name').textContent = sanitizeHTML(std.name); } const sumCellTemplate = row.querySelector('.sum'); const avgCellTemplate = row.querySelector('.average'); if(sumCellTemplate) sumCellTemplate.remove(); if(avgCellTemplate) avgCellTemplate.remove(); const studentGradesForSet = std.grades[gradeSetId] || {}; const fragment = document.createDocumentFragment(); gradeSet.gradeLabels.forEach(label => { const td = document.createElement('td'); td.classList.add('grade-col'); const input = document.createElement('input'); input.type = 'number'; input.classList.add('grade-input'); input.dataset.label = label; input.min = "0"; input.max = "100"; input.step = "0.1"; input.placeholder = sanitizeHTML(label); const gradeValue = studentGradesForSet[label] ?? ''; input.value = gradeValue; applyGradeColor(input, gradeValue, colorRanges); input.addEventListener('input', (e) => { applyGradeColor(e.target, e.target.value, colorRanges); calculateAndUpdateSumAndAverage(row, gradeSet.gradeLabels, colorRanges); }); td.appendChild(input); fragment.appendChild(td); }); studentCol.after(fragment); if(sumCellTemplate) row.appendChild(sumCellTemplate); if(avgCellTemplate) row.appendChild(avgCellTemplate); calculateAndUpdateSumAndAverage(row, gradeSet.gradeLabels, colorRanges); tbody.appendChild(row); }); gradesTableContainer.appendChild(table); };
    const calculateAndUpdateSumAndAverage = (tableRow, gradeLabels, colorRanges) => { let sum = 0; let count = 0; gradeLabels.forEach(label => { const input = tableRow.querySelector(`input[data-label="${label}"]`); const value = parseFloat(input?.value); if (!isNaN(value)) { sum += value; count++; } }); const sumCell = tableRow.querySelector('.sum'); const avgCell = tableRow.querySelector('.average'); if (sumCell) { sumCell.textContent = count > 0 ? sum.toFixed(1) : '--'; } if (avgCell) { const avg = count > 0 ? (sum / count) : null; avgCell.textContent = avg !== null ? avg.toFixed(1) : '--'; if (colorRanges && colorRanges.length > 0) { applyGradeColor(avgCell, avg, colorRanges); avgCell.classList.remove('grade-low', 'grade-medium', 'grade-high'); } else { avgCell.style.backgroundColor = ''; avgCell.style.color = ''; avgCell.classList.remove('grade-low', 'grade-medium', 'grade-high'); if(avg !== null) { if (avg < 5) avgCell.classList.add('grade-low'); else if (avg < 7) avgCell.classList.add('grade-medium'); else avgCell.classList.add('grade-high'); } } } };
    const calculateSumAndAverageForData = (gradesObject) => { let sum = 0; let count = 0; let average = null; if (gradesObject) { for(const label in gradesObject) { if (label !== 'average' && label !== 'sum') { const value = parseFloat(gradesObject[label]); if (!isNaN(value)) { sum += value; count++; } } } } if (count > 0) { average = parseFloat((sum / count).toFixed(1)); sum = parseFloat(sum.toFixed(1)); } else { sum = null; } return { sum: sum, average: average }; };
    const renderAttendanceTable = (classId, date) => { attendanceTableContainer.innerHTML = ''; saveAttendanceButton.classList.add('hidden'); attendanceActionsContainer.classList.add('hidden'); const studentsInClass = getStudentsByClass(classId); if (!date) { attendanceTableContainer.innerHTML = '<p style="padding: 1rem; text-align: center;">Selecione uma data.</p>'; return; } if (studentsInClass.length === 0) { attendanceTableContainer.innerHTML = '<p style="padding: 1rem; text-align: center;">Nenhum aluno para registrar presença.</p>'; return; } const isNonSchoolDay = studentsInClass.every(std => std.attendance[date]?.status === 'H'); console.log(`Rendering attendance for ${date}. Is Non-School Day: ${isNonSchoolDay}`); attendanceActionsContainer.classList.remove('hidden'); saveAttendanceButton.classList.remove('hidden'); markAllPresentButton.disabled = isNonSchoolDay; if (isNonSchoolDay) { markNonSchoolDayButton.innerHTML = `<span class="icon icon-nao-letivo"></span>Desm. Não Letivo`; markNonSchoolDayButton.classList.remove('secondary'); markNonSchoolDayButton.classList.add('danger'); markNonSchoolDayButton.title = "Reverter para dia letivo normal"; } else { markNonSchoolDayButton.innerHTML = `<span class="icon icon-nao-letivo"></span>Não Letivo`; markNonSchoolDayButton.classList.remove('danger'); markNonSchoolDayButton.classList.add('secondary'); markNonSchoolDayButton.title = "Marcar este dia como não letivo"; } const table = document.createElement('table'); table.classList.add('data-table'); table.innerHTML = `<thead><tr><th class="student-col">Aluno</th><th class="attendance-status">Status</th></tr></thead><tbody></tbody>`; const tbody = table.querySelector('tbody'); const template = document.getElementById('attendance-row-template'); studentsInClass.forEach(std => { const studentId = std.id; const clone = template.content.cloneNode(true); const row = clone.querySelector('tr'); row.dataset.studentId = studentId; const studentCol = row.querySelector('.student-col'); studentCol.querySelector('.student-number').textContent = std.number ? `${std.number}.` : '-.'; studentCol.querySelector('.student-name').textContent = sanitizeHTML(std.name); const statusCell = row.querySelector('.attendance-status'); statusCell.innerHTML = ''; const activeSuspension = isStudentSuspendedOnDate(studentId, date); const attendanceRecord = std.attendance[date] || { status: null, justification: '' }; const currentStatus = attendanceRecord.status; const currentJustification = attendanceRecord.justification || ''; if (activeSuspension) { const noteIndex = appData.students.find(s => s.id === studentId)?.notes.findIndex(n => n === activeSuspension) ?? -1; row.classList.add('suspended-student', 'clickable-suspended'); if (noteIndex !== -1) { row.dataset.suspensionNoteIndex = noteIndex; } statusCell.innerHTML = `<span class="suspended-indicator" title="${sanitizeHTML(activeSuspension.text)}"><span class="icon icon-block"></span> Susp.</span>`; studentCol.style.opacity = '0.7'; } else if (currentStatus === 'H') { statusCell.textContent = 'H'; statusCell.classList.add('status-H'); statusCell.title = "Dia não letivo"; } else { row.classList.remove('suspended-student', 'clickable-suspended'); row.removeAttribute('data-suspension-note-index'); studentCol.style.opacity = '1'; statusCell.innerHTML = ` <button type="button" class="attendance-toggle present"><span class="icon icon-presenca"></span> P</button> <button type="button" class="attendance-toggle absent"><span class="icon icon-falta"></span> F</button> `; const presentButton = statusCell.querySelector('.present'); const absentButton = statusCell.querySelector('.absent'); presentButton.disabled = isNonSchoolDay; absentButton.disabled = isNonSchoolDay; const updateButtonUI = (status, justification) => { presentButton.classList.toggle('selected', status === 'P'); absentButton.classList.toggle('selected', status === 'F'); const isJustified = status === 'F' && !!justification; absentButton.classList.toggle('justified', isJustified); absentButton.innerHTML = `<span class="icon icon-falta"></span> ${isJustified ? 'FJ' : 'F'}`; absentButton.title = isJustified ? `Just.: ${sanitizeHTML(justification.substring(0, 30))}... (Clique para editar)` : 'Faltou (Clique para justificar)'; }; updateButtonUI(currentStatus, currentJustification); presentButton.addEventListener('click', () => { if (presentButton.disabled) return; updateAttendanceStatus(studentId, date, 'P'); }); absentButton.addEventListener('click', () => { if (absentButton.disabled) return; const currentAttendance = findStudentById(studentId)?.attendance[date]; if (currentAttendance?.status === 'F') { openJustificationModal(studentId, date); } else { updateAttendanceStatus(studentId, date, 'F'); } }); } tbody.appendChild(row); }); attendanceTableContainer.appendChild(table); };
    const renderLessonPlan = (classId, date) => { const currentClass = findClassById(classId); if (!currentClass || !date || !lessonPlanTextarea) { if(lessonPlanTextarea) lessonPlanTextarea.value = ''; if(saveLessonPlanButton) saveLessonPlanButton.classList.add('hidden'); return; } currentClass.lessonPlans = currentClass.lessonPlans || {}; const plan = currentClass.lessonPlans[date] || ''; lessonPlanTextarea.value = plan; saveLessonPlanButton.classList.remove('hidden'); };
    const renderClassroomMap = (classId, isEditing = false) => { const cls = findClassById(classId); if (!cls) { console.error("Class not found for map:", classId); classroomContainerDisplay.innerHTML = '<p style="padding: 1rem; text-align: center; grid-column: 1 / -1; grid-row: 1 / -1;">Erro: Turma não encontrada.</p>'; classroomContainerEdit.innerHTML = ''; mapEditArea.classList.add('hidden'); return; } const layout = cls.classroomLayout || { rows: 5, cols: 6, teacherDeskPosition: 'top-center', seats: [] }; const currentLayoutData = isEditing ? tempClassroomLayout : layout; const students = getStudentsByClass(classId); const container = isEditing ? classroomContainerEdit : classroomContainerDisplay; container.innerHTML = ''; const teacherDeskClone = teacherDeskTemplate.content.cloneNode(true); const teacherDeskElement = teacherDeskClone.querySelector('.teacher-desk'); const gridClone = classroomGridTemplate.content.cloneNode(true); const gridContainerElement = gridClone.querySelector('.classroom-map-grid'); teacherDeskElement.className = 'teacher-desk'; teacherDeskElement.classList.add(`position-${currentLayoutData.teacherDeskPosition}`); gridContainerElement.style.gridTemplateColumns = `repeat(${currentLayoutData.cols}, auto)`; container.appendChild(teacherDeskElement); container.appendChild(gridContainerElement); const seatTemplate = document.getElementById('seat-template'); const emptySeatPlaceholder = "Toque/Arraste Aluno"; if (isEditing) clearSeatSelection(); if (currentLayoutData.rows > 0 && currentLayoutData.cols > 0) { for (let r = 1; r <= currentLayoutData.rows; r++) { for (let c = 1; c <= currentLayoutData.cols; c++) { const seatData = currentLayoutData.seats.find(s => s.row === r && s.col === c); const studentId = seatData?.studentId; const student = studentId ? findStudentById(studentId) : null; const seatClone = seatTemplate.content.cloneNode(true); const seatElement = seatClone.querySelector('.seat'); seatElement.dataset.row = r; seatElement.dataset.col = c; const numberSpan = seatElement.querySelector('.seat-student-number'); const nameSpan = seatElement.querySelector('.seat-student-name'); const placeholderSpan = seatElement.querySelector('.seat-placeholder-text'); numberSpan.textContent = ''; nameSpan.textContent = ''; placeholderSpan.textContent = ''; placeholderSpan.classList.remove('seat-placeholder-text'); seatElement.classList.remove('occupied', 'empty', 'selected-for-assignment'); seatElement.removeAttribute('data-student-id'); seatElement.setAttribute('draggable', 'false'); if (student) { seatElement.classList.add('occupied'); seatElement.dataset.studentId = student.id; numberSpan.textContent = student.number ? `${student.number}.` : ''; nameSpan.textContent = sanitizeHTML(student.name); if (isEditing) { seatElement.setAttribute('draggable', 'true'); seatElement.addEventListener('dragstart', handleSeatDragStart); seatElement.addEventListener('click', handleOccupiedSeatClick); seatElement.style.cursor = 'grab'; } else { seatElement.style.cursor = 'default'; } } else { seatElement.classList.add('empty'); if (isEditing) { seatElement.addEventListener('click', handleSeatClickForAssignment); placeholderSpan.textContent = emptySeatPlaceholder; placeholderSpan.classList.add('seat-placeholder-text'); seatElement.style.cursor = 'pointer'; } else { seatElement.style.cursor = 'default'; } } if (isEditing) { seatElement.addEventListener('dragover', handleDragOver); seatElement.addEventListener('dragleave', handleDragLeave); seatElement.addEventListener('drop', handleDropOnSeat); } gridContainerElement.appendChild(seatElement); } } } else if (!isEditing) { gridContainerElement.innerHTML = '<p style="padding: 1rem; text-align: center; grid-column: 1 / -1;">Configure o mapa clicando no botão <span class="icon icon-editar"></span>.</p>'; } else { gridContainerElement.innerHTML = '<p style="padding: 1rem; text-align: center; grid-column: 1 / -1;">Dimensões inválidas (0 fileiras ou colunas).</p>'; } if (isEditing) { renderUnassignedStudents(classId); } classroomContainerDisplay.classList.toggle('hidden', isEditing); mapEditArea.classList.toggle('hidden', !isEditing); };
    const renderUnassignedStudents = (classId) => { if (!tempClassroomLayout) return; const allStudents = getStudentsByClass(classId); const assignedStudentIds = new Set(tempClassroomLayout.seats.map(s => s.studentId).filter(id => id)); unassignedStudentsContainer.innerHTML = '<h5>Alunos sem lugar (Clique aqui após selecionar mesa vazia)</h5>'; const studentTemplate = document.getElementById('draggable-student-template'); allStudents.forEach(student => { if (!assignedStudentIds.has(student.id)) { const clone = studentTemplate.content.cloneNode(true); const studentDiv = clone.querySelector('.draggable-student'); studentDiv.dataset.studentId = student.id; studentDiv.querySelector('.student-number').textContent = student.number ? `${student.number}.` : ''; studentDiv.querySelector('.student-name').textContent = sanitizeHTML(student.name); const oldNode = studentDiv; studentDiv.replaceWith(oldNode.cloneNode(true)); const newNode = unassignedStudentsContainer.appendChild(oldNode); newNode.addEventListener('dragstart', handleStudentListDragStart); newNode.addEventListener('click', handleUnassignedStudentClickForAssignment); } }); };
    const renderStudentObservations = (studentId, noteIndexToHighlight = -1, useLocalCopy = false) => { const listContainer = document.getElementById('student-observations-list'); if (!listContainer) { console.error("Container #student-observations-list não encontrado no modal."); return; } const notes = useLocalCopy ? currentStudentObservations : (findStudentById(studentId)?.notes || []); listContainer.innerHTML = ''; if (notes.length === 0) { listContainer.innerHTML = '<p style="text-align: center; padding: 1rem; color: var(--text-secondary);">Nenhuma observação registrada.</p>'; return; } const sortedNotes = [...notes].sort((a, b) => (b.date || '').localeCompare(a.date || '')); const template = document.getElementById('observation-item-template'); sortedNotes.forEach(note => { const originalIndex = notes.findIndex(n => n === note); if (originalIndex === -1) return; const clone = template.content.cloneNode(true); const itemElement = clone.querySelector('.observation-item'); itemElement.dataset.index = originalIndex; const categoryClean = (note.category || 'anotacao').toLowerCase().replace(/[^a-z0-9]/g, ''); itemElement.classList.add(`category-${categoryClean}`); itemElement.querySelector('.category').textContent = `${note.category || 'Anotação'}`; itemElement.querySelector('.observation-date').textContent = formatDate(note.date); itemElement.querySelector('.observation-text').textContent = sanitizeHTML(note.text); const suspDatesSpan = itemElement.querySelector('.observation-suspension-dates'); if (note.category === 'Suspensão' && note.suspensionStartDate && note.suspensionEndDate) { suspDatesSpan.textContent = `Período: ${formatDate(note.suspensionStartDate)} a ${formatDate(note.suspensionEndDate)}`; suspDatesSpan.classList.remove('hidden'); } else { suspDatesSpan.classList.add('hidden'); } if (!useLocalCopy && originalIndex === noteIndexToHighlight) { itemElement.classList.add('highlighted-note'); setTimeout(() => itemElement.scrollIntoView({ behavior: 'smooth', block: 'center' }), 150); } listContainer.appendChild(clone); }); };

    // --- Funções de CRUD ---
    const openScheduleModal = (scheduleIdToEdit = null) => { const isEditing = scheduleIdToEdit !== null; const scheduleData = isEditing ? findScheduleById(scheduleIdToEdit) : { day: weekdays[new Date().getDay()], notificationsEnabled: true }; const title = isEditing ? 'Editar Horário' : 'Novo Horário'; let schoolOptions = '<option value="">-- Selecione --</option>'; appData.schools.sort((a, b) => a.name.localeCompare(b.name)).forEach(s => { schoolOptions += `<option value="${s.id}" ${scheduleData.schoolId === s.id ? 'selected' : ''}>${sanitizeHTML(s.name)}</option>`; }); let dayOptions = ''; weekdays.slice(1, 6).forEach(day => { dayOptions += `<option value="${day}" ${scheduleData.day === day ? 'selected' : ''}>${day}</option>`; }); if (weekdays.includes(scheduleData.day) && !weekdays.slice(1, 6).includes(scheduleData.day)) { dayOptions += `<option value="${scheduleData.day}" selected>${scheduleData.day}</option>`; } if (!weekdays.includes(scheduleData.day)) { dayOptions += `<option value="Sábado" ${scheduleData.day === 'Sábado' ? 'selected' : ''}>Sábado</option>`; dayOptions += `<option value="Domingo" ${scheduleData.day === 'Domingo' ? 'selected' : ''}>Domingo</option>`; } const modalContent = ` <form id="schedule-form"> <input type="hidden" id="schedule-id" value="${isEditing ? scheduleIdToEdit : ''}"> <div class="form-group"> <label for="schedule-day">Dia:</label> <select id="schedule-day" required>${dayOptions}</select> </div> <div class="form-group d-flex"> <div style="flex: 1; margin-right: 5px;"> <label for="schedule-start-time">Início:</label> <input type="time" id="schedule-start-time" required value="${scheduleData.startTime || ''}"> </div> <div style="flex: 1; margin-left: 5px;"> <label for="schedule-end-time">Fim:</label> <input type="time" id="schedule-end-time" required value="${scheduleData.endTime || ''}"> </div> </div> <div class="form-group"> <label for="schedule-school">Escola:</label> <select id="schedule-school" required>${schoolOptions}</select> </div> <div class="form-group"> <label for="schedule-note">Anotação:</label> <input type="text" id="schedule-note" placeholder="Ex: Aula Turma 8B" value="${sanitizeHTML(scheduleData.note || '')}"> </div> <div class="checkbox-group"> <input type="checkbox" id="enable-schedule-notification" ${scheduleData.notificationsEnabled ? 'checked' : ''}> <label for="enable-schedule-notification">Ativar Notificações para este Horário</label> </div> </form> `; const footerButtons = `<button type="button" id="save-schedule-button" class="success"><span class="icon icon-salvar"></span> Salvar</button>`; showModal(title, modalContent, footerButtons); document.getElementById('save-schedule-button').addEventListener('click', saveScheduleEntry); };
    const saveScheduleEntry = () => { const form = document.getElementById('schedule-form'); if (!form || !form.checkValidity()) { alert('Preencha os campos obrigatórios (Dia, Horários, Escola).'); form?.reportValidity(); return; } const id = document.getElementById('schedule-id').value; const newData = { id: id || generateId('sch'), day: document.getElementById('schedule-day').value, startTime: document.getElementById('schedule-start-time').value, endTime: document.getElementById('schedule-end-time').value, schoolId: document.getElementById('schedule-school').value, note: document.getElementById('schedule-note').value.trim(), notificationsEnabled: document.getElementById('enable-schedule-notification').checked }; if (!newData.schoolId) { alert('Selecione uma escola.'); return; } if (id) { const index = appData.schedule.findIndex(item => item.id === id); if (index > -1) appData.schedule[index] = newData; } else { appData.schedule.push(newData); } saveData(); renderScheduleList(); hideModal(); };
    const deleteScheduleEntry = (id) => { appData.schedule = appData.schedule.filter(item => item.id !== id); saveData(); renderScheduleList(); };
    const toggleScheduleNotification = (scheduleId, indicatorElement) => { const item = findScheduleById(scheduleId); if (item) { item.notificationsEnabled = !item.notificationsEnabled; saveData(); updateNotificationIcon(indicatorElement, item.notificationsEnabled); console.log(`Notification for ${scheduleId} set to: ${item.notificationsEnabled}`); } };
    const openSchoolModal = (schoolIdToEdit = null) => { const isEditing = schoolIdToEdit !== null; const schoolData = isEditing ? findSchoolById(schoolIdToEdit) : {}; const title = isEditing ? 'Editar Escola' : 'Nova Escola'; const modalContent = `<form id="school-form"><input type="hidden" id="school-id" value="${isEditing ? schoolIdToEdit : ''}"><div class="form-group"><label for="school-name">Nome:</label><input type="text" id="school-name" required value="${sanitizeHTML(schoolData.name || '')}"></div></form>`; const footerButtons = `<button type="button" id="save-school-button" class="success"><span class="icon icon-salvar"></span> Salvar</button>`; showModal(title, modalContent, footerButtons); document.getElementById('save-school-button').addEventListener('click', saveSchool); };
    const saveSchool = () => { const form = document.getElementById('school-form'); if (!form || !form.checkValidity()) { alert('Preencha o nome da escola.'); form?.reportValidity(); return; } const id = document.getElementById('school-id').value; const newSchoolData = { id: id || generateId('sch'), name: document.getElementById('school-name').value.trim() }; if (id) { const index = appData.schools.findIndex(s => s.id === id); if (index > -1) appData.schools[index] = newSchoolData; } else { appData.schools.push(newSchoolData); } saveData(); renderSchoolList(); if(currentSection === 'schedule-section') renderScheduleList(); hideModal(); };
    const deleteSchool = (id) => { const classesToDelete = appData.classes.filter(c => c.schoolId === id).map(c => c.id); appData.schools = appData.schools.filter(s => s.id !== id); appData.classes = appData.classes.filter(c => c.schoolId !== id); appData.students = appData.students.filter(s => !classesToDelete.includes(s.classId)); appData.schedule = appData.schedule.filter(sch => sch.schoolId !== id); if (currentSchoolId === id) { currentSchoolId = null; currentClassId = null; showSection('schools-section'); } saveData(); renderSchoolList(); if (currentSection === 'schedule-section') renderScheduleList(); if (currentSection === 'classes-section' && !currentSchoolId) { showSection('schools-section'); } else if (currentSection === 'classes-section') { renderClassList(currentSchoolId); } saveAppState(); };
    const selectSchool = (id) => { currentSchoolId = id; currentClassId = null; renderClassList(id); navClassesButton.disabled = false; navDetailsButton.disabled = true; saveAppState(); };
    const openClassModal = (classIdToEdit = null) => { if (!currentSchoolId) return; const isEditing = classIdToEdit !== null; const classData = isEditing ? findClassById(classIdToEdit) : {}; const title = isEditing ? 'Editar Turma' : 'Nova Turma'; const schoolName = findSchoolById(currentSchoolId)?.name || '?'; const modalContent = `<form id="class-form"><input type="hidden" id="class-id" value="${isEditing ? classIdToEdit : ''}"><p class="mb-1"><strong>Escola:</strong> ${sanitizeHTML(schoolName)}</p><div class="form-group"><label for="class-name">Nome Turma:</label><input type="text" id="class-name" required value="${sanitizeHTML(classData.name || '')}"></div><div class="form-group"><label for="class-subject">Matéria:</label><input type="text" id="class-subject" value="${sanitizeHTML(classData.subject || '')}"></div><div class="form-group d-flex"><div style="flex: 1; margin-right: 5px;"><label for="class-schedule">Horário:</label><input type="time" id="class-schedule" value="${classData.schedule || ''}"></div><div style="flex: 1; margin-left: 5px;"><label for="class-shift">Turno:</label><select id="class-shift"><option value="">--</option><option value="Manhã" ${classData.shift === 'Manhã' ? 'selected' : ''}>Manhã</option><option value="Tarde" ${classData.shift === 'Tarde' ? 'selected' : ''}>Tarde</option><option value="Noite" ${classData.shift === 'Noite' ? 'selected' : ''}>Noite</option><option value="Integral" ${classData.shift === 'Integral' ? 'selected' : ''}>Integral</option></select></div></div></form>`; const footerButtons = `<button type="button" id="save-class-button" class="success"><span class="icon icon-salvar"></span> Salvar</button>`; showModal(title, modalContent, footerButtons); document.getElementById('save-class-button').addEventListener('click', saveClass); };
    const saveClass = () => { const form = document.getElementById('class-form'); if (!form || !form.checkValidity() || !currentSchoolId) { alert('Preencha nome da turma e verifique escola.'); form?.reportValidity(); return; } const id = document.getElementById('class-id').value; const isEditing = !!id; const existingData = isEditing ? findClassById(id) : {}; const newClassData = { id: id || generateId('cls'), schoolId: currentSchoolId, name: document.getElementById('class-name').value.trim(), subject: document.getElementById('class-subject').value.trim(), schedule: document.getElementById('class-schedule').value, shift: document.getElementById('class-shift').value, notes: existingData?.notes || '', gradeStructure: existingData?.gradeStructure || [], lessonPlans: existingData?.lessonPlans || {}, classroomLayout: existingData?.classroomLayout || { rows: 5, cols: 6, teacherDeskPosition: 'top-center', seats: [] }, representativeId: existingData?.representativeId || null, viceRepresentativeId: existingData?.viceRepresentativeId || null }; if (isEditing) { const index = appData.classes.findIndex(c => c.id === id); if (index > -1) appData.classes[index] = newClassData; } else { appData.classes.push(newClassData); } saveData(); renderClassList(currentSchoolId); if (id && id === currentClassId && currentSection === 'class-details-section') { selectClass(id, true); } hideModal(); };
    const deleteClass = (id) => { appData.classes = appData.classes.filter(c => c.id !== id); appData.students = appData.students.filter(s => s.classId !== id); if (currentClassId === id) { currentClassId = null; showSection('classes-section'); } saveData(); renderClassList(currentSchoolId); if (!currentClassId) navDetailsButton.disabled = true; saveAppState(); };
    const selectClass = (id, forceReload = false) => { if (currentClassId !== id || forceReload) { console.log(`Selecionando Turma: ${id}, Forçar Recarga: ${forceReload}`); if (tempClassroomLayout) { cancelClassroomMapEdit(); } currentClassId = id; const selectedClass = findClassById(id); if (selectedClass) { classDetailsTitle.textContent = `${sanitizeHTML(selectedClass.name)} (${sanitizeHTML(selectedClass.subject || 'Sem matéria')})`; renderStudentList(id); renderGradeSets(id); const currentDate = attendanceDateInput.value || getCurrentDateString(); attendanceDateInput.value = currentDate; lessonPlanDateInput.value = currentDate; renderAttendanceTable(id, currentDate); renderLessonPlan(id, currentDate); renderClassroomMap(id); classNotesContent.textContent = sanitizeHTML(selectedClass.notes || 'Nenhuma anotação.'); classNotesTextarea.value = selectedClass.notes || ''; classNotesEdit.classList.add('hidden'); classNotesDisplay.classList.remove('hidden'); if (currentSection === 'classes-section') renderClassList(selectedClass.schoolId); navDetailsButton.disabled = false; classDetailsSection.querySelectorAll('.card').forEach(card => { card.classList.remove('collapsed'); const toggleBtn = card.querySelector('.card-toggle-button .icon'); if (toggleBtn) { toggleBtn.classList.remove('icon-chevron-down'); toggleBtn.classList.add('icon-chevron-up'); if(toggleBtn.parentElement) toggleBtn.parentElement.title = 'Esconder'; } }); } else { currentClassId = null; classDetailsTitle.textContent = "Erro: Turma não encontrada"; studentListContainer.innerHTML = '<p>Erro</p>'; gradesTableContainer.innerHTML = '<p>Erro</p>'; attendanceTableContainer.innerHTML = '<p>Erro</p>'; lessonPlanTextarea.value = ''; saveLessonPlanButton.classList.add('hidden'); classNotesContent.textContent = 'Erro'; classroomContainerDisplay.innerHTML = '<p style="padding: 1rem; text-align: center; grid-column: 1 / -1; grid-row: 1 / -1;">Erro ao carregar mapa.</p>'; navDetailsButton.disabled = true; } saveAppState(); } else { console.log(`Turma ${id} já selecionada.`); } };
    const openStudentModal = (studentIdToEdit = null) => {
        if (!currentClassId) return;
        const isEditing = studentIdToEdit !== null;
        const studentData = isEditing ? findStudentById(studentIdToEdit) : { governmentPrograms: [] }; // Initialize for new student
        const title = isEditing ? 'Editar Aluno' : 'Novo Aluno';
        const className = findClassById(currentClassId)?.name || '?';

        // **** NOVO: HTML para Programas Governamentais ****
        const programsHtml = `
            <div class="form-group" style="margin-top: 1rem;">
                <label>Programas Governamentais:</label>
                <div class="checkbox-group">
                    <input type="checkbox" id="student-program-bolsa-familia" value="Bolsa Família" ${studentData.governmentPrograms && studentData.governmentPrograms.includes('Bolsa Família') ? 'checked' : ''}>
                    <label for="student-program-bolsa-familia">Bolsa Família</label>
                </div>
                <div class="checkbox-group">
                    <input type="checkbox" id="student-program-pe-de-meia" value="Pé de Meia" ${studentData.governmentPrograms && studentData.governmentPrograms.includes('Pé de Meia') ? 'checked' : ''}>
                    <label for="student-program-pe-de-meia">Pé de Meia</label>
                </div>
            </div>
        `;

        const modalContent = `
            <form id="student-form">
                <p class="mb-1"><strong>Turma:</strong> ${sanitizeHTML(className)}</p>
                <input type="hidden" id="student-id" value="${isEditing ? studentIdToEdit : ''}">
                <div class="form-group d-flex align-items-center">
                    <div style="width: 80px; margin-right: 10px;">
                        <label for="student-number">Nº:</label>
                        <input type="number" id="student-number" min="1" step="1" value="${studentData.number || ''}" style="padding: 0.7rem 0.5rem;">
                    </div>
                    <div style="flex-grow: 1;">
                        <label for="student-name">Nome:</label>
                        <input type="text" id="student-name" required value="${sanitizeHTML(studentData.name || '')}">
                    </div>
                </div>
                ${programsHtml} 
            </form>`;
        const footerButtons = `<button type="button" id="save-student-button" class="success"><span class="icon icon-salvar"></span> Salvar</button>`;
        showModal(title, modalContent, footerButtons);
        document.getElementById('save-student-button').addEventListener('click', saveStudent);
    };
    const saveStudent = () => {
        const form = document.getElementById('student-form');
        if (!form || !form.checkValidity()) {
            alert('Preencha o nome do aluno.');
            form?.reportValidity();
            return;
        }
        const id = document.getElementById('student-id').value;
        const studentName = document.getElementById('student-name').value.trim();
        const studentNumberInput = document.getElementById('student-number').value;
        const studentNumber = studentNumberInput ? parseInt(studentNumberInput) : null;

        // **** NOVO: Coleta de dados dos programas ****
        const selectedPrograms = [];
        const bolsaFamiliaCheckbox = document.getElementById('student-program-bolsa-familia');
        const peDeMeiaCheckbox = document.getElementById('student-program-pe-de-meia');
        if (bolsaFamiliaCheckbox && bolsaFamiliaCheckbox.checked) selectedPrograms.push('Bolsa Família');
        if (peDeMeiaCheckbox && peDeMeiaCheckbox.checked) selectedPrograms.push('Pé de Meia');

        if (!currentClassId) return;

        if (!id) {
            const studentsInClass = getStudentsByClass(currentClassId);
            if (studentsInClass.length >= 100) {
                alert('Limite máximo de 100 alunos por turma atingido.');
                return;
            }
        }

        if (id) {
            const student = findStudentById(id);
            if (student) {
                student.name = studentName;
                student.number = studentNumber;
                student.governmentPrograms = selectedPrograms; // Salva programas
            }
        } else {
            const newStudent = {
                id: generateId('std'),
                name: studentName,
                number: studentNumber,
                classId: currentClassId,
                grades: {},
                attendance: {},
                notes: [],
                governmentPrograms: selectedPrograms // Salva programas
            };
            appData.students.push(newStudent);
        }
        saveData();
        renderStudentList(currentClassId);
        if (gradeSetSelect.value) renderGradesTable(currentClassId, gradeSetSelect.value);
        if (attendanceDateInput.value) renderAttendanceTable(currentClassId, attendanceDateInput.value);
        renderClassroomMap(currentClassId);
        hideModal();
    };
    const deleteStudent = (id) => { if (currentClassId) { const cls = findClassById(currentClassId); if (cls?.classroomLayout?.seats) { cls.classroomLayout.seats.forEach(seat => { if (seat.studentId === id) { seat.studentId = null; } }); } if(cls?.representativeId === id) cls.representativeId = null; if(cls?.viceRepresentativeId === id) cls.viceRepresentativeId = null; } appData.students = appData.students.filter(s => s.id !== id); saveData(); renderStudentList(currentClassId); if (gradeSetSelect.value) renderGradesTable(currentClassId, gradeSetSelect.value); if (attendanceDateInput.value) renderAttendanceTable(currentClassId, attendanceDateInput.value); renderClassroomMap(currentClassId); };
    const openStudentNotesModal = (studentId, noteIndexToHighlight = -1) => { const student = findStudentById(studentId); if (!student) return; currentStudentObservations = JSON.parse(JSON.stringify(student.notes || [])); const title = `Observações - ${student.number || '-'}. ${sanitizeHTML(student.name)}`; const modalContent = ` <div id="student-observations-list"></div> <hr style="margin: 1rem 0 0.8rem 0; border-color: var(--border-color);"> <div id="add-observation-section"> <form id="add-observation-form"> <div class="form-group"> <label for="new-observation-category">Categoria:</label> <select id="new-observation-category"> <option value="Anotação">Anotação</option> <option value="Observação" selected>Observação</option> <option value="Ocorrência">Ocorrência</option> <option value="Advertência">Advertência</option> <option value="Suspensão">Suspensão</option> </select> </div> <div id="suspension-fields" class="form-group hidden" style="display: flex; gap: 10px;"> <div style="flex: 1;"> <label for="new-suspension-start-date">Início Suspensão:</label> <input type="date" id="new-suspension-start-date"> </div> <div style="flex: 1;"> <label for="new-suspension-end-date">Fim Suspensão:</label> <input type="date" id="new-suspension-end-date"> </div> </div> <div class="form-group"> <label for="new-observation-text">Descrição:</label> <textarea id="new-observation-text" required></textarea> </div> <button type="button" id="add-observation-button" class="success"><span class="icon icon-adicionar"></span> Adicionar à Lista</button> </form> </div>`; const footerButtons = `<button type="button" id="save-observations-button" class="success"><span class="icon icon-salvar"></span> Salvar Observações</button>`; showModal(title, modalContent, footerButtons, 'student-notes-modal'); renderStudentObservations(studentId, noteIndexToHighlight, true); const categorySelect = document.getElementById('new-observation-category'); const suspensionFields = document.getElementById('suspension-fields'); const startDateInput = document.getElementById('new-suspension-start-date'); const endDateInput = document.getElementById('new-suspension-end-date'); const descriptionTextarea = document.getElementById('new-observation-text'); const saveButton = document.getElementById('save-observations-button'); const addToListButton = document.getElementById('add-observation-button'); const observationsListContainer = document.getElementById('student-observations-list'); const placeholderMap = { 'Anotação': 'Digite uma anotação rápida...', 'Observação': 'Descreva a observação comportamental, acadêmica, etc.', 'Ocorrência': 'Detalhe a ocorrência (briga, desrespeito, etc.).', 'Advertência': 'Descreva o motivo da advertência formal.', 'Suspensão': 'Descreva o motivo grave e o período da suspensão.' }; const updateDynamicFields = () => { const cat = categorySelect.value || 'Observação'; descriptionTextarea.placeholder = placeholderMap[cat] || 'Digite a descrição...'; const pluralSuffix = cat.endsWith('o') || cat.endsWith('a') ? 's' : (cat.endsWith('m') ? 'ns' : 's'); saveButton.innerHTML = `<span class="icon icon-salvar"></span> Salvar ${cat}${pluralSuffix}`; const showSusp = cat === 'Suspensão'; suspensionFields.classList.toggle('hidden', !showSusp); startDateInput.required = showSusp; endDateInput.required = showSusp; if (!showSusp) { startDateInput.value = ''; endDateInput.value = ''; } }; categorySelect.addEventListener('change', updateDynamicFields); updateDynamicFields(); addToListButton?.addEventListener('click', () => { const form = document.getElementById('add-observation-form'); if (!form.checkValidity()) { form.reportValidity(); return; } const category = categorySelect.value; const text = descriptionTextarea.value.trim(); let startDate = null, endDate = null; if (category === 'Suspensão') { startDate = startDateInput.value; endDate = endDateInput.value; if (!startDate || !endDate) { alert("Para Suspensão, as datas de início e fim são obrigatórias."); return; } if (startDate > endDate) { alert("A data de início da suspensão não pode ser posterior à data de fim."); return; } } if (text) { const newObservation = { date: getCurrentDateString(), category: category, text: text, suspensionStartDate: startDate, suspensionEndDate: endDate }; currentStudentObservations.push(newObservation); renderStudentObservations(studentId, -1, true); descriptionTextarea.value = ''; categorySelect.value = 'Observação'; startDateInput.value = ''; endDateInput.value = ''; updateDynamicFields(); descriptionTextarea.focus(); } else { alert("A descrição não pode estar vazia."); descriptionTextarea.focus(); } }); saveButton?.addEventListener('click', () => saveStudentObservations(studentId)); observationsListContainer?.addEventListener('click', (e) => { const deleteButton = e.target.closest('.delete-observation-button'); if (deleteButton) { const itemElement = deleteButton.closest('.observation-item'); const index = parseInt(itemElement?.dataset.index, 10); if (!isNaN(index) && confirm("Excluir esta observação permanentemente?")) { const removed = currentStudentObservations.splice(index, 1); if (removed.length > 0) { console.log("Observação removida (localmente):", removed[0]); renderStudentObservations(studentId, -1, true); } else { console.warn("Tentativa de excluir observação com índice inválido:", index); } } } }); };
    const saveStudentObservations = (studentId) => { const student = findStudentById(studentId); if (!student) { console.error("Erro: Aluno não encontrado ao salvar observações:", studentId); alert("Erro ao salvar: Aluno não encontrado."); return; } student.notes = JSON.parse(JSON.stringify(currentStudentObservations)); saveData(); hideModal(); renderAttendanceTable(currentClassId, attendanceDateInput.value || getCurrentDateString()); alert(`Observações de ${sanitizeHTML(student.name)} salvas com sucesso!`); console.log("Observações salvas:", student.notes); };
    const updateAttendanceStatus = (studentId, date, newStatus) => { const student = findStudentById(studentId); if (!student) { console.warn(`Aluno ${studentId} não encontrado para atualizar presença.`); return; } if (!date) { console.warn("Data inválida para atualizar presença."); return; } if (!student.attendance[date]) { student.attendance[date] = { status: null, justification: '' }; } const currentStatus = student.attendance[date].status; if (currentStatus === newStatus) { student.attendance[date].status = null; student.attendance[date].justification = ''; } else { student.attendance[date].status = newStatus; if (newStatus === 'P') { student.attendance[date].justification = ''; } } console.log(`Status de presença atualizado para ${studentId} em ${date}:`, student.attendance[date]); renderAttendanceTable(currentClassId, date); };
    const openJustificationModal = (studentId, date) => { const student = findStudentById(studentId); if (!student || !date) { console.error("Aluno ou data inválida para justificação."); return; } if (!student.attendance[date]) { student.attendance[date] = { status: 'F', justification: '' }; } else { student.attendance[date].status = 'F'; } const currentJustification = student.attendance[date].justification || ''; const title = `Justificativa - ${sanitizeHTML(student.name)} (${formatDate(date)})`; const modalContent = ` <form id="justification-form"> <div class="form-group"> <label for="justification-modal-text">Motivo da Falta:</label> <textarea id="justification-modal-text" placeholder="Digite a justificativa aqui..." style="min-height: 100px;">${sanitizeHTML(currentJustification)}</textarea> </div> </form>`; const footerButtons = `<button type="button" id="save-justification-button" class="success"><span class="icon icon-salvar"></span> Salvar Justificativa</button>`; showModal(title, modalContent, footerButtons, 'justification-modal'); const saveBtn = document.getElementById('save-justification-button'); if(saveBtn) { const newSaveBtn = saveBtn.cloneNode(true); saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn); newSaveBtn.addEventListener('click', () => { const justificationText = document.getElementById('justification-modal-text').value.trim(); const studentToUpdate = findStudentById(studentId); if (studentToUpdate && studentToUpdate.attendance[date]) { studentToUpdate.attendance[date].status = 'F'; studentToUpdate.attendance[date].justification = justificationText; console.log(`Justificativa atualizada para ${studentId} em ${date}: "${justificationText}"`); hideModal(); renderAttendanceTable(currentClassId, date); } else { console.error("Não foi possível salvar justificação: aluno ou registro de presença ausente."); alert("Erro ao salvar justificativa."); hideModal(); } }); } };
    const openMoveStudentModal = (studentId) => { const student = findStudentById(studentId); if (!student) { alert("Erro: Aluno não encontrado."); return; } const currentClass = findClassById(student.classId); if (!currentClass) { alert("Erro: Turma atual do aluno não encontrada."); return; } const school = findSchoolById(currentClass.schoolId); if (!school) { alert("Erro: Escola do aluno não encontrada."); return; } const otherClassesInSchool = appData.classes .filter(c => c.schoolId === school.id && c.id !== currentClass.id) .sort((a, b) => a.name.localeCompare(b.name)); let classOptionsHtml = '<option value="">-- Selecione a Turma de Destino --</option>'; if (otherClassesInSchool.length > 0) { otherClassesInSchool.forEach(cls => { classOptionsHtml += `<option value="${cls.id}">${sanitizeHTML(cls.name)} (${sanitizeHTML(cls.subject || 'N/A')})</option>`; }); } else { classOptionsHtml = '<option value="" disabled>Nenhuma outra turma nesta escola</option>'; } const title = `Mover Aluno: ${sanitizeHTML(student.name)}`; const modalContent = ` <form id="move-student-form"> <p><strong>Aluno:</strong> ${sanitizeHTML(student.name)} (#${student.number || 'S/N'})</p> <p class="mb-1"><strong>Turma Atual:</strong> ${sanitizeHTML(currentClass.name)}</p> <input type="hidden" id="move-student-id" value="${studentId}"> <div class="form-group"> <label for="move-student-destination-class">Mover para a Turma:</label> <select id="move-student-destination-class" required ${otherClassesInSchool.length === 0 ? 'disabled' : ''}> ${classOptionsHtml} </select> ${otherClassesInSchool.length === 0 ? '<p class="text-secondary text-sm mt-1">Não há outras turmas cadastradas nesta escola para mover o aluno.</p>' : ''} </div> <div class="form-group"> <label>Opções de Dados:</label> <div class="checkbox-group"> <input type="checkbox" id="move-student-attendance-checkbox" checked> <label for="move-student-attendance-checkbox">Mover Histórico de Frequência?</label> </div> <p class="text-sm text-secondary mt-1">Nota: O histórico de notas NÃO será movido.</p> </div> </form> `; const footerButtons = ` <button type="button" id="confirm-move-student-button" class="success" ${otherClassesInSchool.length === 0 ? 'disabled' : ''}> <span class="icon icon-mover"></span> Mover Aluno </button>`; showModal(title, modalContent, footerButtons, 'move-student-modal'); const confirmButton = document.getElementById('confirm-move-student-button'); if (confirmButton) { confirmButton.replaceWith(confirmButton.cloneNode(true)); document.getElementById('confirm-move-student-button').addEventListener('click', confirmMoveStudent); } };
    const confirmMoveStudent = () => { const studentId = document.getElementById('move-student-id')?.value; const destinationClassId = document.getElementById('move-student-destination-class')?.value; const moveAttendance = document.getElementById('move-student-attendance-checkbox')?.checked; if (!studentId || !destinationClassId) { alert("Erro: Por favor, selecione a turma de destino."); return; } const student = findStudentById(studentId); if (!student) { alert("Erro: Aluno não encontrado."); return; } const destinationClass = findClassById(destinationClassId); if (!destinationClass) { alert("Erro: Turma de destino não encontrada."); return; } const originalClass = findClassById(student.classId); if (student.classId === destinationClassId) { alert("O aluno já está nesta turma."); return; } if (!confirm(`Mover ${sanitizeHTML(student.name)} da turma "${sanitizeHTML(originalClass?.name)}" para "${sanitizeHTML(destinationClass.name)}"?\n\nATENÇÃO: O histórico de notas será RESETADO.\nFrequência será ${moveAttendance ? 'mantida' : 'removida'}.`)) { return; } console.log(`Moving student ${studentId} to class ${destinationClassId}. Move Attendance: ${moveAttendance}`); if (originalClass?.classroomLayout?.seats) { originalClass.classroomLayout.seats.forEach(seat => { if (seat.studentId === studentId) { seat.studentId = null; } }); } student.classId = destinationClassId; student.grades = {}; console.log(` -> Grades cleared for student ${studentId}`); if (!moveAttendance) { student.attendance = {}; console.log(` -> Attendance cleared for student ${studentId}`); } saveData(); hideModal(); if (currentClassId === originalClass?.id && currentSection === 'class-details-section') { renderStudentList(originalClass.id); if (gradeSetSelect.value) renderGradesTable(originalClass.id, gradeSetSelect.value); if (attendanceDateInput.value) renderAttendanceTable(originalClass.id, attendanceDateInput.value); renderClassroomMap(originalClass.id); } else if (currentClassId === destinationClassId && currentSection === 'class-details-section') { renderClassroomMap(destinationClassId); } alert(`Aluno ${sanitizeHTML(student.name)} movido para a turma ${sanitizeHTML(destinationClass.name)} com sucesso! (Histórico de notas resetado)`); };
    const openGradeStructureModal = () => { if (!currentClassId) return; const currentClass = findClassById(currentClassId); const title = `Estrutura Notas - ${sanitizeHTML(currentClass.name)}`; let structureHtml = ''; const gradeStructure = currentClass.gradeStructure || []; if (gradeStructure.length > 0) { gradeStructure.forEach((gs, index) => { const colorRanges = gs.colorRanges || []; let colorRangesHtml = ''; colorRanges.forEach((range, rIndex) => { colorRangesHtml += ` <div class="color-range-item" data-range-index="${rIndex}"> <label>De:</label> <input type="number" class="gs-color-min" step="0.1" placeholder="0.0" value="${range.min ?? ''}"> <label>Até:</label> <input type="number" class="gs-color-max" step="0.1" placeholder="10.0" value="${range.max ?? ''}"> <label>Cor:</label> <input type="color" class="gs-color-input" value="${range.color || '#ffffff'}"> <button type="button" class="delete-color-range-button danger icon-button" title="Excluir Faixa"> <span class="icon icon-excluir icon-only"></span> </button> </div> `; }); structureHtml += ` <div class="card mb-2" data-gs-index="${index}" data-gs-id="${gs.id}"> <div class="card-header"> <input type="text" class="gs-name" value="${sanitizeHTML(gs.name)}" placeholder="Nome do Conjunto de Notas"> <button type="button" class="delete-gs-button danger icon-button" title="Excluir Conjunto ${sanitizeHTML(gs.name)}"> <span class="icon icon-excluir icon-only"></span> </button> </div> <div class="card-content"> <div class="gs-section gs-instruments-container"> <h4>Instrumentos de Avaliação</h4> ${gs.gradeLabels.map((label, lblIndex) => ` <div class="grade-label-item" data-label-index="${lblIndex}"> <input type="text" class="gs-label" value="${sanitizeHTML(label)}" placeholder="Nome da Avaliação (Ex: Prova 1)"> <button type="button" class="delete-gs-label-button danger icon-button" title="Excluir Instrumento"> <span class="icon icon-excluir icon-only"></span> </button> </div>`).join('')} <button type="button" class="add-gs-label-button success mt-1"><span class="icon icon-adicionar"></span> Instrumento</button> </div> <div class="gs-section gs-color-ranges-container"> <h4>Faixas de Cores para Notas</h4> <div class="color-ranges-list">${colorRangesHtml}</div> <button type="button" class="add-color-range-button success mt-1"><span class="icon icon-adicionar"></span> Faixa de Cor</button> </div> </div> </div>`; }); } else { structureHtml = '<p>Nenhuma estrutura definida. Clique em "Adicionar Conjunto".</p>'; } const modalContent = ` <form id="grade-structure-form"> <div id="grade-sets-list">${structureHtml}</div> <button type="button" id="add-grade-set-button" class="success mt-2"><span class="icon icon-adicionar"></span> Adicionar Conjunto</button> </form>`; const footerButtons = `<button type="button" id="save-grade-structure-button" class="success"><span class="icon icon-salvar"></span> Salvar Estrutura</button>`; showModal(title, modalContent, footerButtons, 'grade-structure-modal'); setupGradeStructureModalListeners(); };
    const setupGradeStructureModalListeners = () => { const gradeSetsListContainer = document.getElementById('grade-sets-list'); if (!gradeSetsListContainer) return; const addSetButton = document.getElementById('add-grade-set-button'); const saveStructureButton = document.getElementById('save-grade-structure-button'); gradeSetsListContainer.removeEventListener('click', handleGradeStructureClicks); gradeSetsListContainer.addEventListener('click', handleGradeStructureClicks); if (addSetButton) { addSetButton.replaceWith(addSetButton.cloneNode(true)); document.getElementById('add-grade-set-button').addEventListener('click', addGradeSet); } if (saveStructureButton) { saveStructureButton.replaceWith(saveStructureButton.cloneNode(true)); document.getElementById('save-grade-structure-button').addEventListener('click', saveGradeStructure); } };
    const handleGradeStructureClicks = (e) => { if (e.target.classList.contains('add-gs-label-button') || e.target.closest('.add-gs-label-button')) { const button = e.target.closest('.add-gs-label-button'); const instrumentsContainer = button.closest('.gs-instruments-container'); const template = document.getElementById('grade-label-item-template'); const clone = template.content.cloneNode(true); instrumentsContainer.insertBefore(clone, button); } else if (e.target.classList.contains('delete-gs-label-button') || e.target.closest('.delete-gs-label-button')) { const itemToDelete = e.target.closest('.grade-label-item'); itemToDelete?.remove(); } else if (e.target.classList.contains('add-color-range-button') || e.target.closest('.add-color-range-button')) { const button = e.target.closest('.add-color-range-button'); const rangesList = button.previousElementSibling; const template = document.getElementById('color-range-item-template'); const clone = template.content.cloneNode(true); rangesList.appendChild(clone); } else if (e.target.classList.contains('delete-color-range-button') || e.target.closest('.delete-color-range-button')) { const itemToDelete = e.target.closest('.color-range-item'); itemToDelete?.remove(); } else if (e.target.classList.contains('delete-gs-button') || e.target.closest('.delete-gs-button')) { const cardToDelete = e.target.closest('.card[data-gs-index]'); const setName = cardToDelete?.querySelector('.gs-name')?.value || 'este conjunto'; if (confirm(`Tem certeza que deseja excluir "${setName}" e todas as notas associadas?`)) { const list = cardToDelete?.parentElement; cardToDelete?.remove(); list?.querySelectorAll('.card[data-gs-index]').forEach((card, i) => card.dataset.gsIndex = i); if (list && list.children.length === 0) { list.innerHTML = '<p>Nenhuma estrutura definida.</p>'; } } } };
    const addGradeSet = () => { const list = document.getElementById('grade-sets-list'); const newSetIndex = list.querySelectorAll('.card[data-gs-index]').length; const defaultRangesHtml = ` <div class="color-range-item" data-range-index="0"> <label>De:</label> <input type="number" class="gs-color-min" step="0.1" placeholder="0.0" value="0"> <label>Até:</label> <input type="number" class="gs-color-max" step="0.1" placeholder="4.9" value="4.9"> <label>Cor:</label> <input type="color" class="gs-color-input" value="#dc3545"> <button type="button" class="delete-color-range-button danger icon-button" title="Excluir Faixa"><span class="icon icon-excluir icon-only"></span></button> </div> <div class="color-range-item" data-range-index="1"> <label>De:</label> <input type="number" class="gs-color-min" step="0.1" placeholder="5.0" value="5.0"> <label>Até:</label> <input type="number" class="gs-color-max" step="0.1" placeholder="6.9" value="6.9"> <label>Cor:</label> <input type="color" class="gs-color-input" value="#ffc107"> <button type="button" class="delete-color-range-button danger icon-button" title="Excluir Faixa"><span class="icon icon-excluir icon-only"></span></button> </div> <div class="color-range-item" data-range-index="2"> <label>De:</label> <input type="number" class="gs-color-min" step="0.1" placeholder="7.0" value="7.0"> <label>Até:</label> <input type="number" class="gs-color-max" step="0.1" placeholder="10.0" value="10.0"> <label>Cor:</label> <input type="color" class="gs-color-input" value="#d4edda"> <button type="button" class="delete-color-range-button danger icon-button" title="Excluir Faixa"><span class="icon icon-excluir icon-only"></span></button> </div> `; const newSetHtml = ` <div class="card mb-2" data-gs-index="${newSetIndex}" data-gs-id=""> <div class="card-header"> <input type="text" class="gs-name" value="Novo Conjunto ${newSetIndex + 1}" placeholder="Nome do Conjunto de Notas"> <button type="button" class="delete-gs-button danger icon-button" title="Excluir Conjunto"> <span class="icon icon-excluir icon-only"></span> </button> </div> <div class="card-content"> <div class="gs-section gs-instruments-container"> <h4>Instrumentos de Avaliação</h4> <div class="grade-label-item" data-label-index="0"> <input type="text" class="gs-label" value="Nota 1" placeholder="Nome da Avaliação"> <button type="button" class="delete-gs-label-button danger icon-button" title="Excluir Instrumento"> <span class="icon icon-excluir icon-only"></span> </button> </div> <button type="button" class="add-gs-label-button success mt-1"><span class="icon icon-adicionar"></span> Instrumento</button> </div> <div class="gs-section gs-color-ranges-container"> <h4>Faixas de Cores para Notas</h4> <div class="color-ranges-list">${defaultRangesHtml}</div> <button type="button" class="add-color-range-button success mt-1"><span class="icon icon-adicionar"></span> Faixa de Cor</button> </div> </div> </div>`; const noStructureP = list.querySelector('p'); if (noStructureP) noStructureP.remove(); list.insertAdjacentHTML('beforeend', newSetHtml); };
    const saveGradeStructure = () => { if (!currentClassId) return; const currentClass = findClassById(currentClassId); if (!currentClass) return; const newStructure = []; const gradeSetCards = document.querySelectorAll('#grade-sets-list .card[data-gs-index]'); let valid = true; const existingSetIds = new Set(currentClass.gradeStructure.map(gs => gs.id)); const currentSetIds = new Set(); gradeSetCards.forEach(card => { if (!valid) return; const nameInput = card.querySelector('.gs-name'); const name = nameInput.value.trim(); const setId = card.dataset.gsId || `gs_${currentClassId}_${Date.now()}_${Math.random().toString(16).slice(5)}`; currentSetIds.add(setId); const labels = []; const labelInputs = card.querySelectorAll('.gs-label'); if (!name) { alert('Nome do conjunto é obrigatório.'); nameInput.focus(); valid = false; return; } if (labelInputs.length === 0) { alert(`Conjunto "${name}" precisa ter pelo menos um Instrumento de Avaliação.`); valid = false; return; } labelInputs.forEach(lblInput => { const label = lblInput.value.trim(); if (!label) { alert(`Nome do Instrumento em "${name}" é obrigatório.`); lblInput.focus(); valid = false; } if (valid) labels.push(label); }); if (!valid) return; const colorRanges = []; const rangeItems = card.querySelectorAll('.color-range-item'); rangeItems.forEach(item => { if (!valid) return; const minInput = item.querySelector('.gs-color-min'); const maxInput = item.querySelector('.gs-color-max'); const colorInput = item.querySelector('.gs-color-input'); const min = parseFloat(minInput.value); const max = parseFloat(maxInput.value); const color = colorInput.value; if (isNaN(min) || isNaN(max)) { alert(`Valores Mínimo e Máximo da faixa de cor em "${name}" devem ser números.`); (isNaN(min) ? minInput : maxInput).focus(); valid = false; return; } if (min > max) { alert(`Valor Mínimo (${min}) não pode ser maior que o Máximo (${max}) na faixa de cor em "${name}".`); minInput.focus(); valid = false; return; } colorRanges.push({ min: min, max: max, color: color }); }); if (!valid) return; newStructure.push({ id: setId, name: name, gradeLabels: labels, colorRanges: colorRanges }); }); if (valid) { const deletedSetIds = [...existingSetIds].filter(id => !currentSetIds.has(id)); if (deletedSetIds.length > 0) { console.log("Removing grades for deleted sets:", deletedSetIds); appData.students.forEach(student => { if (student.classId === currentClassId) { deletedSetIds.forEach(deletedId => { if (student.grades[deletedId]) { delete student.grades[deletedId]; } }); } }); } currentClass.gradeStructure = newStructure; saveData(); hideModal(); renderGradeSets(currentClassId); } };
    const saveGrades = () => { const gradeSetId = gradeSetSelect.value; if (!currentClassId || !gradeSetId) { console.warn("Cannot save grades: No class or grade set selected."); return; } const currentClass = findClassById(currentClassId); const gradeSet = currentClass?.gradeStructure?.find(gs => gs.id === gradeSetId); if(!gradeSet) { console.warn("Cannot save grades: Grade set not found."); return; } console.log("Saving grades for set:", gradeSetId); const rows = gradesTableContainer.querySelectorAll('tbody tr'); if(rows.length === 0) { console.warn("No student rows found to save grades."); return; } rows.forEach(row => { const studentId = row.dataset.studentId; const student = findStudentById(studentId); if (student) { if (!student.grades[gradeSetId]) student.grades[gradeSetId] = {}; const currentGrades = {}; gradeSet.gradeLabels.forEach(label => { const input = row.querySelector(`input[data-label="${label}"]`); const value = input?.value.trim(); currentGrades[label] = (value !== '' && !isNaN(parseFloat(value))) ? parseFloat(value) : null; }); const calculated = calculateSumAndAverageForData(currentGrades); student.grades[gradeSetId] = { ...currentGrades, sum: calculated.sum, average: calculated.average }; } else { console.warn(`Student with ID ${studentId} not found during grade save.`); } }); saveData(); alert(`Notas de "${sanitizeHTML(gradeSet.name)}" salvas!`); renderGradesTable(currentClassId, gradeSetId); };
    const escapeCsvField = (field) => { if (field === null || field === undefined) { return '""'; } let fieldStr = String(field); fieldStr = fieldStr.replace(/"/g, '""'); if (fieldStr.includes(',') || fieldStr.includes('"') || fieldStr.includes('\n') || fieldStr.includes('\r')) { return `"${fieldStr}"`; } return fieldStr; };
    const exportGradesCSV = () => { const gradeSetId = gradeSetSelect.value; if (!currentClassId || !gradeSetId) { alert("Selecione uma turma e um conjunto de notas para exportar."); return; } const currentClass = findClassById(currentClassId); const gradeSet = currentClass?.gradeStructure?.find(gs => gs.id === gradeSetId); const students = getStudentsByClass(currentClassId); if (!gradeSet || students.length === 0) { alert("Nenhum dado de nota para exportar."); return; } const className = currentClass?.name.replace(/[^a-z0-9]/gi, '_') || 'Turma'; const setName = gradeSet.name.replace(/[^a-z0-9]/gi, '_') || 'Conjunto'; let csvContent = "\uFEFF"; let header = [escapeCsvField("Aluno"), escapeCsvField("No.")]; gradeSet.gradeLabels.forEach(label => header.push(escapeCsvField(label))); header.push(escapeCsvField("Soma")); header.push(escapeCsvField("Média")); csvContent += header.join(",") + "\r\n"; students.forEach(student => { const studentGrades = student.grades[gradeSetId] || {}; const calculated = calculateSumAndAverageForData(studentGrades); let row = [escapeCsvField(student.name), escapeCsvField(student.number || '')]; gradeSet.gradeLabels.forEach(label => { const gradeValue = studentGrades[label]; row.push(escapeCsvField(gradeValue)); }); row.push(escapeCsvField(calculated.sum !== null ? calculated.sum.toFixed(1) : '')); row.push(escapeCsvField(calculated.average !== null ? calculated.average.toFixed(1) : '')); csvContent += row.join(",") + "\r\n"; }); const encodedUri = encodeURI(`data:text/csv;charset=utf-8,${csvContent}`); const link = document.createElement("a"); link.setAttribute("href", encodedUri); link.setAttribute("download", `notas_${className}_${setName}.csv`); document.body.appendChild(link); link.click(); document.body.removeChild(link); };
    const exportGradesPDF = async () => { const gradeSetId = gradeSetSelect.value; const button = exportGradesPdfButton; if (!currentClassId || !gradeSetId) { alert("Selecione uma turma e um conjunto de notas para exportar para PDF."); return; } const currentClass = findClassById(currentClassId); const gradeSet = currentClass?.gradeStructure?.find(gs => gs.id === gradeSetId); const students = getStudentsByClass(currentClassId); if (!gradeSet || students.length === 0) { alert("Nenhum dado de nota para exportar para PDF."); return; } const classNameSanitized = currentClass?.name.replace(/[^a-z0-9]/gi, '_') || 'Turma'; const setNameSanitized = gradeSet.name.replace(/[^a-z0-9]/gi, '_') || 'Conjunto'; const filename = `notas_${classNameSanitized}_${setNameSanitized}.pdf`; let tableHTML = ` <style> body { font-family: sans-serif; font-size: 9pt; } .pdf-table { border-collapse: collapse; width: 100%; margin-top: 10px; table-layout: fixed; } .pdf-table th, .pdf-table td { border: 1px solid #ccc; padding: 3px 4px; text-align: left; word-wrap: break-word; overflow-wrap: break-word; } .pdf-table th { background-color: #f2f2f2; font-weight: bold; text-align: center; font-size: 8pt; } .pdf-table td { font-size: 8pt; } .pdf-table tr { page-break-inside: avoid; } .pdf-table td.grade, .pdf-table td.sum, .pdf-table td.avg { text-align: center; } .pdf-table td.student-name { min-width: 100px; white-space: normal; } .pdf-table th.student-col { min-width: 105px; } .pdf-table th.grade-col { min-width: 40px; } .pdf-table th.sum-col, .pdf-table th.avg-col { min-width: 45px; } .pdf-table .number { font-weight: bold; display: inline-block; min-width: 15px; text-align: right; margin-right: 4px;} h4 { text-align: center; margin-bottom: 10px; font-size: 11pt; } </style> <h4>Notas - Turma: ${sanitizeHTML(currentClass.name)} - Conjunto: ${sanitizeHTML(gradeSet.name)}</h4> <table class="pdf-table"> <thead> <tr> <th class="student-col">Aluno</th> `; gradeSet.gradeLabels.forEach(label => { tableHTML += `<th class="grade-col">${sanitizeHTML(label)}</th>`; }); tableHTML += `<th class="sum-col">Soma</th><th class="avg-col">Média</th></tr></thead><tbody>`; students.forEach(student => { const studentGrades = student.grades[gradeSetId] || {}; const calculated = calculateSumAndAverageForData(studentGrades); tableHTML += `<tr><td class="student-name"><span class="number">${student.number || '-.'}</span>${sanitizeHTML(student.name)}</td>`; gradeSet.gradeLabels.forEach(label => { const gradeValue = studentGrades[label]; tableHTML += `<td class="grade">${(gradeValue !== null && gradeValue !== undefined) ? sanitizeHTML(gradeValue) : '-'}</td>`; }); tableHTML += `<td class="sum">${(calculated.sum !== null) ? calculated.sum.toFixed(1) : '-'}</td>`; tableHTML += `<td class="avg">${(calculated.average !== null) ? calculated.average.toFixed(1) : '-'}</td>`; tableHTML += `</tr>`; }); tableHTML += `</tbody></table>`; const opt = { margin: [8, 5, 8, 5], filename: filename, image: { type: 'jpeg', quality: 0.95 }, html2canvas: { scale: 2, useCORS: true, logging: false, }, jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }, pagebreak: { mode: ['avoid-all', 'css', 'legacy'] } }; const originalButtonText = button.innerHTML; button.disabled = true; button.innerHTML = '<span class="icon icon-hourglass-empty"></span>'; try { console.log("Generating PDF with options:", opt); await html2pdf().set(opt).from(tableHTML).save(); console.log("PDF de notas gerado com sucesso."); } catch (error) { console.error("Erro ao gerar PDF de notas:", error); alert("Ocorreu um erro ao gerar o PDF de notas. Verifique o console para detalhes."); } finally { button.disabled = false; button.innerHTML = originalButtonText; } };
    const saveAttendance = () => { const date = attendanceDateInput.value; if (!currentClassId || !date) { console.warn("Cannot save attendance: No class or date selected."); alert("Selecione uma turma e uma data."); return; } console.log("Saving all attendance data for", date); saveData(); alert(`Presença de ${formatDate(date)} salva!`); };
    const saveLessonPlan = () => { const date = lessonPlanDateInput.value; if (!currentClassId || !date) { alert("Selecione uma turma e uma data para salvar o plano."); return; } const currentClass = findClassById(currentClassId); if (!currentClass) return; const planText = lessonPlanTextarea.value.trim(); currentClass.lessonPlans = currentClass.lessonPlans || {}; if (planText) { currentClass.lessonPlans[date] = planText; console.log(`Lesson plan saved for ${date}:`, planText); } else { delete currentClass.lessonPlans[date]; console.log(`Lesson plan removed for ${date}`); } saveData(); alert(`Plano de aula para ${formatDate(date)} salvo!`); };
    const openMonthlyAttendanceModal = () => { if (!currentClassId) { alert("Selecione uma turma primeiro."); return; } const currentClass = findClassById(currentClassId); const title = `Frequência Mensal - ${sanitizeHTML(currentClass.name)}`; const today = new Date(); const currentYear = today.getFullYear(); const currentMonth = today.getMonth(); let yearOptions = ''; for (let y = currentYear + 1; y >= currentYear - 5; y--) { yearOptions += `<option value="${y}" ${y === currentYear ? 'selected' : ''}>${y}</option>`; } let monthOptions = ''; monthNames.forEach((name, index) => { monthOptions += `<option value="${index}" ${index === currentMonth ? 'selected' : ''}>${name}</option>`; }); const modalContent = ` <div id="monthly-attendance-controls"> <div class="date-selectors"> <label for="monthly-attendance-month">Mês:</label> <select id="monthly-attendance-month">${monthOptions}</select> <label for="monthly-attendance-year">Ano:</label> <select id="monthly-attendance-year">${yearOptions}</select> </div> <div class="export-buttons"> <button type="button" id="export-attendance-csv-button" class="secondary icon-button hidden" title="Exportar CSV"><span class="icon icon-upload"></span></button> <button type="button" id="export-attendance-pdf-button" class="secondary icon-button hidden" title="Exportar PDF"><span class="icon icon-pdf"></span></button> </div> </div> <div id="monthly-attendance-table-wrapper"> <p>Selecione o mês/ano para carregar os dados.</p> </div> <div id="monthly-attendance-chart-container" class="hidden"></div> <div id="monthly-attendance-summary"></div> `; showModal(title, modalContent, '', 'monthly-attendance-modal'); const monthSelect = document.getElementById('monthly-attendance-month'); const yearSelect = document.getElementById('monthly-attendance-year'); const exportCsvButton = document.getElementById('export-attendance-csv-button'); const exportPdfButton = document.getElementById('export-attendance-pdf-button'); const updateMonthlyView = () => { const selectedMonth = parseInt(monthSelect.value); const selectedYear = parseInt(yearSelect.value); renderMonthlyAttendanceData(currentClassId, selectedYear, selectedMonth); }; monthSelect.addEventListener('change', updateMonthlyView); yearSelect.addEventListener('change', updateMonthlyView); exportCsvButton.addEventListener('click', () => { const selectedMonth = parseInt(monthSelect.value); const selectedYear = parseInt(yearSelect.value); exportMonthlyAttendanceCSV(currentClassId, selectedYear, selectedMonth); }); exportPdfButton.addEventListener('click', () => { const selectedMonth = parseInt(monthSelect.value); const selectedYear = parseInt(yearSelect.value); exportMonthlyAttendancePDF(currentClassId, selectedYear, selectedMonth, exportPdfButton); }); updateMonthlyView(); };
    const renderMonthlyAttendanceData = (classId, year, month) => { const students = getStudentsByClass(classId); const currentModal = document.querySelector('#generic-modal.show.monthly-attendance-modal'); if (!currentModal) return; const tableWrapper = currentModal.querySelector('#monthly-attendance-table-wrapper'); const summaryContainer = currentModal.querySelector('#monthly-attendance-summary'); const chartContainer = currentModal.querySelector('#monthly-attendance-chart-container'); const exportCsvBtn = currentModal.querySelector('#export-attendance-csv-button'); const exportPdfBtn = currentModal.querySelector('#export-attendance-pdf-button'); if (!tableWrapper || !summaryContainer || !chartContainer) { console.error("Um ou mais elementos do modal mensal não encontrados."); return; } tableWrapper.innerHTML = ''; summaryContainer.innerHTML = ''; chartContainer.innerHTML = ''; if (students.length === 0) { tableWrapper.innerHTML = '<p style="text-align:center; padding: 1rem;">Nenhum aluno nesta turma.</p>'; if (exportCsvBtn) exportCsvBtn.classList.add('hidden'); if (exportPdfBtn) exportPdfBtn.classList.add('hidden'); chartContainer.classList.add('hidden'); return; } if (exportCsvBtn) exportCsvBtn.classList.remove('hidden'); if (exportPdfBtn) exportPdfBtn.classList.remove('hidden'); chartContainer.classList.remove('hidden'); const daysInMonth = getDaysInMonth(year, month); const table = document.createElement('table'); table.classList.add('monthly-attendance-table'); const thead = table.createTHead(); const tbody = table.createTBody(); const headerRow = thead.insertRow(); headerRow.innerHTML = `<th class="student-col-monthly">Aluno</th>`; for (let day = 1; day <= daysInMonth; day++) { headerRow.innerHTML += `<th>${day}</th>`; } headerRow.innerHTML += `<th class="freq-col-monthly">% Freq.</th>`; let totalClassP = 0; let totalClassPossibleAttendances = 0; const studentFrequencies = []; students.forEach(student => { const row = tbody.insertRow(); row.innerHTML = `<td class="student-col-monthly"><span class="student-number">${student.number || '-'}.</span> ${sanitizeHTML(student.name)}</td>`; let studentP = 0; let studentPossibleDays = 0; for (let day = 1; day <= daysInMonth; day++) { const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`; const attendanceRecord = student.attendance[dateStr]; const status = attendanceRecord?.status; const justification = attendanceRecord?.justification || ''; const dayOfWeek = getDayOfWeek(year, month, day); const isWeekend = dayOfWeek === 0 || dayOfWeek === 6; let cellContent = '-'; let cellClass = ''; if (isWeekend) { cellClass = 'weekend'; cellContent = ''; } else if (status === 'H') { cellClass = 'status-H'; cellContent = 'H'; } else { studentPossibleDays++; totalClassPossibleAttendances++; if (status === 'P') { cellContent = 'P'; cellClass = 'status-P'; studentP++; totalClassP++; } else if (status === 'F') { cellClass = justification ? 'status-FJ' : 'status-F'; cellContent = justification ? 'FJ' : 'F'; } else { cellContent = '-'; } } row.innerHTML += `<td class="${cellClass}">${cellContent}</td>`; } const frequencyPercent = studentPossibleDays > 0 ? Math.round((studentP / studentPossibleDays) * 100) : 0; const frequencyText = studentPossibleDays > 0 ? frequencyPercent + '%' : '--'; row.innerHTML += `<td class="freq-col-monthly">${frequencyText}</td>`; studentFrequencies.push({ name: student.name, number: student.number, freq: frequencyPercent }); }); tableWrapper.appendChild(table); const classFrequency = totalClassPossibleAttendances > 0 ? ((totalClassP / totalClassPossibleAttendances) * 100).toFixed(0) + '%' : '--'; summaryContainer.textContent = `Frequência Média da Turma (dias letivos): ${classFrequency}`; renderMonthlyAttendanceChart(studentFrequencies); };
    const renderMonthlyAttendanceChart = (frequencies) => { const currentModal = document.querySelector('#generic-modal.show.monthly-attendance-modal'); const chartContainer = currentModal?.querySelector('#monthly-attendance-chart-container'); if (!chartContainer) return; chartContainer.innerHTML = ''; if (frequencies.length === 0) { return; } const maxFreq = 100; const chartHeight = 100; frequencies.forEach(item => { const barContainer = document.createElement('div'); barContainer.classList.add('chart-bar-container'); const bar = document.createElement('div'); bar.classList.add('chart-bar'); const barHeightValue = (item.freq / maxFreq) * chartHeight; bar.style.height = `${barHeightValue}px`; bar.style.backgroundColor = item.freq >= 70 ? 'var(--accent-success)' : item.freq >= 50 ? 'var(--accent-warning)' : 'var(--accent-danger)'; bar.dataset.percentage = `${item.freq}%`; const label = document.createElement('div'); label.classList.add('chart-label'); label.textContent = item.number ? `${item.number}.` : ''; label.title = sanitizeHTML(item.name); barContainer.appendChild(bar); barContainer.appendChild(label); chartContainer.appendChild(barContainer); }); };
    const exportMonthlyAttendanceCSV = (classId, year, month) => { const students = getStudentsByClass(classId); if (students.length === 0) { alert("Nenhum aluno na turma para exportar."); return; } const currentClass = findClassById(classId); const className = currentClass?.name.replace(/[^a-z0-9]/gi, '_') || 'Turma'; const monthName = monthNames[month]; const daysInMonth = getDaysInMonth(year, month); let csvContent = "\uFEFF"; let header = [escapeCsvField("Aluno"), escapeCsvField("No.")]; for (let day = 1; day <= daysInMonth; day++) { header.push(escapeCsvField(String(day))); } header.push(escapeCsvField("Presente")); header.push(escapeCsvField("Falta")); header.push(escapeCsvField("Falta Just.")); header.push(escapeCsvField("Dias Não Letivos")); header.push(escapeCsvField("% Freq.")); csvContent += header.join(",") + "\r\n"; students.forEach(student => { let row = [escapeCsvField(student.name), escapeCsvField(student.number || '')]; let studentP = 0, studentF = 0, studentFJ = 0, studentH = 0, studentPossibleDays = 0; for (let day = 1; day <= daysInMonth; day++) { const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`; const attendanceRecord = student.attendance[dateStr]; const status = attendanceRecord?.status; const justification = attendanceRecord?.justification || ''; const dayOfWeek = getDayOfWeek(year, month, day); const isWeekend = dayOfWeek === 0 || dayOfWeek === 6; let cellValue = ''; if (isWeekend) { cellValue = ''; } else if (status === 'H') { cellValue = 'H'; studentH++; } else { studentPossibleDays++; if (status === 'P') { cellValue = 'P'; studentP++; } else if (status === 'F') { if (justification) { cellValue = 'FJ'; studentFJ++; } else { cellValue = 'F'; studentF++; } } else { cellValue = '-'; } } row.push(escapeCsvField(cellValue)); } const frequency = studentPossibleDays > 0 ? ((studentP / studentPossibleDays) * 100).toFixed(0) + '%' : ''; row.push(escapeCsvField(studentP)); row.push(escapeCsvField(studentF)); row.push(escapeCsvField(studentFJ)); row.push(escapeCsvField(studentH)); row.push(escapeCsvField(frequency)); csvContent += row.join(",") + "\r\n"; }); const encodedUri = encodeURI(`data:text/csv;charset=utf-8,${csvContent}`); const link = document.createElement("a"); link.setAttribute("href", encodedUri); link.setAttribute("download", `frequencia_${className}_${year}_${monthName}.csv`); document.body.appendChild(link); link.click(); document.body.removeChild(link); };
    const exportMonthlyAttendancePDF = async (classId, year, month, button) => { const students = getStudentsByClass(classId); if (students.length === 0) { alert("Nenhum aluno na turma para exportar para PDF."); return; } const currentClass = findClassById(classId); const classNameSanitized = currentClass?.name.replace(/[^a-z0-9]/gi, '_') || 'Turma'; const monthName = monthNames[month]; const filename = `frequencia_${classNameSanitized}_${year}_${monthName}.pdf`; const daysInMonth = getDaysInMonth(year, month); let tableHTML = ` <style> body { font-family: sans-serif; font-size: 7pt; } .pdf-table { border-collapse: collapse; width: 100%; margin-top: 8px; table-layout: fixed; } .pdf-table th, .pdf-table td { border: 1px solid #ccc; padding: 2px 3px; text-align: center; word-wrap: break-word; overflow-wrap: break-word; } .pdf-table th { background-color: #f2f2f2; font-weight: bold; font-size: 7pt; } .pdf-table td { font-size: 7pt; } .pdf-table tr { page-break-inside: avoid; } .pdf-table td.student-col { text-align: left; min-width: 90px; white-space: normal; } .pdf-table th.student-col { min-width: 90px; } .pdf-table th.day-col, .pdf-table td.day-col { min-width: 15px; max-width:16px; } .pdf-table td.weekend { background-color: #eee; } .pdf-table td.status-H { background-color: #e2e3e5; color: #495057; font-style: italic; } .pdf-table th.summary-col, .pdf-table td.summary-col { font-weight: bold; min-width: 20px; max-width: 25px; font-size: 6pt; } .pdf-table .number { font-weight: bold; display: inline-block; min-width: 12px; text-align: right; margin-right: 3px;} h4 { text-align: center; margin-bottom: 6px; font-size: 10pt; } </style> <h4>Frequência Mensal - Turma: ${sanitizeHTML(currentClass.name)} - ${monthName}/${year}</h4> <table class="pdf-table"> <thead> <tr> <th class="student-col">Aluno</th>`; for (let day = 1; day <= daysInMonth; day++) { tableHTML += `<th class="day-col">${day}</th>`; } tableHTML += `<th class="summary-col">P</th><th class="summary-col">F</th><th class="summary-col">FJ</th><th class="summary-col">H</th><th class="summary-col">%</th></tr></thead><tbody>`; students.forEach(student => { tableHTML += `<tr><td class="student-col"><span class="number">${student.number || '-.'}</span>${sanitizeHTML(student.name)}</td>`; let studentP = 0, studentF = 0, studentFJ = 0, studentH = 0, studentPossibleDays = 0; for (let day = 1; day <=daysInMonth; day++) { const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`; const attendanceRecord = student.attendance[dateStr]; const status = attendanceRecord?.status; const justification = attendanceRecord?.justification || ''; const dayOfWeek = getDayOfWeek(year, month, day); const isWeekend = dayOfWeek === 0 || dayOfWeek === 6; let cellContent = ''; let cellClass = 'day-col'; if (isWeekend) { cellClass += ' weekend'; } else if (status === 'H') { cellContent = 'H'; cellClass += ' status-H'; studentH++; } else { studentPossibleDays++; if (status === 'P') { cellContent = 'P'; studentP++; } else if (status === 'F') { if (justification) { cellContent = 'FJ'; studentFJ++; } else { cellContent = 'F'; studentF++; } } else { cellContent = '-'; } } tableHTML += `<td class="${cellClass}">${cellContent}</td>`; } const frequency = studentPossibleDays > 0 ? ((studentP / studentPossibleDays) * 100).toFixed(0) : '-'; tableHTML += `<td class="summary-col">${studentP}</td>`; tableHTML += `<td class="summary-col">${studentF}</td>`; tableHTML += `<td class="summary-col">${studentFJ}</td>`; tableHTML += `<td class="summary-col">${studentH}</td>`; tableHTML += `<td class="summary-col">${frequency}${frequency !== '-' ? '%' : ''}</td>`; tableHTML += `</tr>`; }); tableHTML += `</tbody></table>`; const opt = { margin: [5, 5, 5, 5], filename: filename, image: { type: 'jpeg', quality: 0.9 }, html2canvas: { scale: 2, useCORS: true, logging: false, }, jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }, pagebreak: { mode: ['avoid-all', 'css', 'legacy'] } }; const originalButtonText = button.innerHTML; button.disabled = true; button.innerHTML = '<span class="icon icon-hourglass-empty"></span>'; try { console.log("Generating PDF with options:", opt); await html2pdf().set(opt).from(tableHTML).save(); console.log("PDF de frequência gerado com sucesso."); } catch (error) { console.error("Erro ao gerar PDF de frequência:", error); alert("Ocorreu um erro ao gerar o PDF de frequência. Verifique o console para detalhes."); } finally { button.disabled = false; button.innerHTML = originalButtonText; } };
    const performSearch = (term) => { term = term.toLowerCase().trim(); if (!term) { hideModal(); return; } const results = { schools: [], classes: [], students: [] }; results.schools = appData.schools.filter(s => s.name.toLowerCase().includes(term)); results.classes = appData.classes.filter(c => c.name.toLowerCase().includes(term) || (c.subject && c.subject.toLowerCase().includes(term))); results.students = appData.students.filter(s => s.name.toLowerCase().includes(term) || (s.number && String(s.number) === term)); renderSearchResults(results, term); };
    const renderSearchResults = (results, term) => { let resultsHtml = `<p>Resultados para: <strong>${sanitizeHTML(term)}</strong></p><div class="item-list mt-1">`; let count = 0; const renderItem = (item, type, details = '') => { count++; const itemSchoolId = type === 'school' ? item.id : (item.schoolId || findClassById(item.classId)?.schoolId); const itemClassId = type === 'student' ? item.classId : (type === 'class' ? item.id : ''); return `<div class="list-item search-result-item" data-type="${type}" data-id="${item.id}" ${itemSchoolId ? `data-school-id="${itemSchoolId}"` : ''} ${itemClassId ? `data-class-id="${itemClassId}"` : ''}> <div class="item-info">${sanitizeHTML(item.name)} ${details ? `<small style='display:block; color: var(--text-secondary);'>${sanitizeHTML(details)}</small>` : ''}</div> <span class="result-type">${type.charAt(0).toUpperCase() + type.slice(1)}</span> </div>`; }; if (results.schools.length > 0) { resultsHtml += `<h5>Escolas</h5>`; results.schools.forEach(s => resultsHtml += renderItem(s, 'school')); } if (results.classes.length > 0) { resultsHtml += `<h5 class="mt-2">Turmas</h5>`; results.classes.forEach(c => { const school = findSchoolById(c.schoolId); resultsHtml += renderItem(c, 'class', `(${c.subject || 'N/A'}) - ${school?.name || '?'}`); }); } if (results.students.length > 0) { resultsHtml += `<h5 class="mt-2">Alunos</h5>`; results.students.forEach(s => { const cls = findClassById(s.classId); const school = findSchoolById(cls?.schoolId); resultsHtml += renderItem(s, 'student', `${s.number || '-'}. ${cls?.name || '?'} / ${school?.name || '?'}`); }); } if (count === 0) { resultsHtml += `<p style="text-align:center; padding: 1rem;">Nenhum resultado encontrado.</p>`; } resultsHtml += `</div>`; showModal(`Resultados da Busca`, resultsHtml, '', 'search-results-modal'); modalBody.querySelectorAll('.search-result-item').forEach(item => { item.addEventListener('click', () => { const type = item.dataset.type; const id = item.dataset.id; const classId = item.dataset.classId; const schoolId = item.dataset.schoolId; hideModal(); searchInput.value = ''; if (type === 'school') { selectSchool(id); showSection('classes-section'); } else if (type === 'class') { if(schoolId) selectSchool(schoolId); selectClass(id); showSection('class-details-section'); } else if (type === 'student') { if(schoolId) selectSchool(schoolId); if(classId) selectClass(classId); showSection('class-details-section'); setTimeout(() => { const studentElement = studentListContainer.querySelector(`.list-item[data-id="${id}"]`); studentElement?.scrollIntoView({ behavior: 'smooth', block: 'center' }); studentElement?.classList.add('active'); setTimeout(() => studentElement?.classList.remove('active'), 2000); }, 300); } }); }); };
    const toggleClassNotesEdit = (showEdit) => { classNotesDisplay.classList.toggle('hidden', showEdit); classNotesEdit.classList.toggle('hidden', !showEdit); if (showEdit) { const currentClass = findClassById(currentClassId); classNotesTextarea.value = currentClass?.notes || ''; classNotesTextarea.focus(); } };
    const saveClassNotes = () => { if(!currentClassId) return; const currentClass = findClassById(currentClassId); if(currentClass) { currentClass.notes = classNotesTextarea.value.trim(); classNotesContent.textContent = sanitizeHTML(currentClass.notes || 'Nenhuma anotação.'); saveData(); toggleClassNotesEdit(false); } };
    const exportData = () => { const dataStr = JSON.stringify(appData, null, 2); const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr); const exportFileDefaultName = `super_professor_pro_backup_${new Date().toISOString().slice(0,10)}.json`; const linkElement = document.createElement('a'); linkElement.setAttribute('href', dataUri); linkElement.setAttribute('download', exportFileDefaultName); linkElement.click(); linkElement.remove(); };
    const importData = (event) => {
        const file = event.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedData = JSON.parse(e.target.result);
                if (importedData && typeof importedData === 'object') {
                    if (confirm("Importar dados substituirá os atuais. Continuar?")) {
                        appData = {
                            schools: importedData.schools || [],
                            classes: importedData.classes || [],
                            students: importedData.students || [],
                            schedule: importedData.schedule || [],
                            settings: importedData.settings || { theme: 'theme-light', globalNotificationsEnabled: true, notificationSoundEnabled: true, customNotificationSound: null }
                        };
                        // Default settings
                        if (typeof appData.settings !== 'object' || appData.settings === null) appData.settings = {};
                        appData.settings.theme = appData.settings.theme || 'theme-light';
                        appData.settings.globalNotificationsEnabled = appData.settings.globalNotificationsEnabled !== undefined ? appData.settings.globalNotificationsEnabled : true;
                        appData.settings.notificationSoundEnabled = appData.settings.notificationSoundEnabled !== undefined ? appData.settings.notificationSoundEnabled : true;
                        appData.settings.customNotificationSound = appData.settings.customNotificationSound || null;
                        if (appData.settings.nonSchoolDays) delete appData.settings.nonSchoolDays;
                        if (appData.settings.customNotificationSound && typeof appData.settings.customNotificationSound === 'string' && !appData.settings.customNotificationSound.startsWith('data:audio')) {
                            console.warn("Imported custom sound data is invalid. Removing.");
                            appData.settings.customNotificationSound = null;
                        }
                        // Student data migration/defaulting
                        appData.students.forEach(s => {
                            s.attendance = s.attendance || {};
                            Object.keys(s.attendance).forEach(date => {
                                if(s.attendance[date] && typeof s.attendance[date] === 'object') {
                                    s.attendance[date].status = s.attendance[date].status || null;
                                    s.attendance[date].justification = String(s.attendance[date].justification || '');
                                } else {
                                    s.attendance[date] = { status: null, justification: ''};
                                }
                            });
                            s.notes = s.notes || [];
                            if (typeof s.notes === 'string') {
                                const oldNotes = s.notes.trim();
                                s.notes = oldNotes ? [{ date: getCurrentDateString(), text: oldNotes, category: 'Anotação' }] : [];
                            } else if (!Array.isArray(s.notes)) {
                                s.notes = [];
                            }
                            s.notes = s.notes.map(note => ({
                                date: note?.date && note.date !== 'N/A' ? note.date : getCurrentDateString(),
                                text: note?.text || '',
                                category: note?.category || 'Anotação',
                                suspensionStartDate: note?.suspensionStartDate || null,
                                suspensionEndDate: note?.suspensionEndDate || null
                            })).filter(note => note.text.trim());
                            // **** NOVO: Inicializa campo de programas governamentais ao importar ****
                            s.governmentPrograms = Array.isArray(s.governmentPrograms) ? s.governmentPrograms : [];
                        });
                        // Class data migration/defaulting
                        appData.classes.forEach(c => {
                            c.lessonPlans = c.lessonPlans || {};
                            c.gradeStructure = c.gradeStructure || [];
                            c.gradeStructure.forEach(gs => {
                                delete gs.periodType;
                                if(gs.colorRanges === undefined) gs.colorRanges = [];
                            });
                            const validPositions = ['top-left', 'top-center', 'top-right', 'bottom-left', 'bottom-center', 'bottom-right', 'left-top', 'left-center', 'left-bottom', 'right-top', 'right-center', 'right-bottom'];
                            if (!c.classroomLayout) {
                                c.classroomLayout = { rows: 5, cols: 6, teacherDeskPosition: 'top-center', seats: [] };
                            } else {
                                c.classroomLayout.seats = c.classroomLayout.seats || [];
                                if (!validPositions.includes(c.classroomLayout.teacherDeskPosition)) {
                                    c.classroomLayout.teacherDeskPosition = 'top-center';
                                }
                            }
                            if(c.representativeId === undefined) c.representativeId = null;
                            if(c.viceRepresentativeId === undefined) c.viceRepresentativeId = null;
                        });
                        appData.schedule.forEach(item => {
                            if (item.notificationsEnabled === undefined) {
                                item.notificationsEnabled = true;
                            }
                        });

                        currentSchoolId = null; currentClassId = null;
                        saveData();
                        applyTheme(appData.settings.theme);
                        updateNotificationSettingsUI();
                        updateCustomSoundUI();
                        restoreAppState();
                        renderSchoolList();
                        renderScheduleList();
                        if (currentSection === 'class-details-section' && currentClassId) {
                            selectClass(currentClassId, true);
                        } else if (currentSection === 'classes-section' && currentSchoolId) {
                            renderClassList(currentSchoolId);
                        }
                        showSection(currentSection || 'schedule-section');
                        alert("Dados importados!");
                    }
                } else {
                    alert("Erro: Arquivo JSON inválido.");
                }
            } catch (error) {
                console.error("Erro importar:", error);
                alert("Erro ao ler arquivo JSON.");
            } finally {
                event.target.value = null;
            }
        };
        reader.readAsText(file);
    };
    const clearAllData = () => { if (confirm("ATENÇÃO! Apagar TODOS os dados? Isso inclui escolas, turmas, alunos, notas, frequências, horários e configurações.")) { if (confirm("SEGUNDA CONFIRMAÇÃO: Tem certeza ABSOLUTA que deseja apagar TUDO? Esta ação não pode ser desfeita.")) { appData = { schools: [], classes: [], students: [], schedule: [], settings: { theme: 'theme-light', globalNotificationsEnabled: true, notificationSoundEnabled: true, customNotificationSound: null } }; currentSchoolId = null; currentClassId = null; saveData(); applyTheme(appData.settings.theme); updateNotificationSettingsUI(); updateCustomSoundUI(); restoreAppState(); renderSchoolList(); renderScheduleList(); classListContainer.innerHTML = '<p style="padding: 1rem; text-align: center;">Selecione escola.</p>'; studentListContainer.innerHTML = '<p style="padding: 1rem; text-align: center;">Selecione turma.</p>'; gradesTableContainer.innerHTML = '<p style="padding: 1rem; text-align: center;">Selecione conjunto.</p>'; attendanceTableContainer.innerHTML = '<p style="padding: 1rem; text-align: center;">Selecione data.</p>'; lessonPlanTextarea.value = ''; saveGradesButton.classList.add('hidden'); saveAttendanceButton.classList.add('hidden'); saveLessonPlanButton.classList.add('hidden'); attendanceActionsContainer.classList.add('hidden'); classroomContainerDisplay.innerHTML = '<p style="padding: 1rem; text-align: center; grid-column: 1 / -1; grid-row: 1 / -1;">Configure o mapa.</p>'; showSection(currentSection || 'schedule-section'); alert("Todos os dados foram apagados."); } } };
    const toggleRepresentative = (studentId) => { const cls = findClassById(currentClassId); if (!cls) return; const studentName = findStudentById(studentId)?.name || 'Aluno(a)'; if (cls.representativeId === studentId) { if (confirm(`Remover ${sanitizeHTML(studentName)} do cargo de Representante?`)) { cls.representativeId = null; console.log(`DEMO: ${studentId} não é mais Rep.`); saveData(); renderStudentList(currentClassId); } } else { const confirmationMessage = `Promover ${sanitizeHTML(studentName)} a Representante?${cls.viceRepresentativeId === studentId ? ' (Ele deixará de ser Vice)' : ''}`; if (confirm(confirmationMessage)) { if (cls.viceRepresentativeId === studentId) cls.viceRepresentativeId = null; cls.representativeId = studentId; console.log(`DEMO: ${studentId} definido como Rep.`); saveData(); renderStudentList(currentClassId); } } };
    const toggleViceRepresentative = (studentId) => { const cls = findClassById(currentClassId); if (!cls) return; const studentName = findStudentById(studentId)?.name || 'Aluno(a)'; if (cls.viceRepresentativeId === studentId) { if (confirm(`Remover ${sanitizeHTML(studentName)} do cargo de Vice-Representante?`)) { cls.viceRepresentativeId = null; console.log(`DEMO: ${studentId} não é mais Vice.`); saveData(); renderStudentList(currentClassId); } } else { const confirmationMessage = `Promover ${sanitizeHTML(studentName)} a Vice-Representante?${cls.representativeId === studentId ? ' (Ele deixará de ser Rep.)' : ''}`; if (confirm(confirmationMessage)) { if (cls.representativeId === studentId) cls.representativeId = null; cls.viceRepresentativeId = studentId; console.log(`DEMO: ${studentId} definido como Vice.`); saveData(); renderStudentList(currentClassId); } } };
    const toggleActions = (listItemElement) => { const currentlyExpanded = studentListContainer.querySelector('.list-item.expanded'); if (currentlyExpanded && currentlyExpanded !== listItemElement) { currentlyExpanded.classList.remove('expanded'); const oldBtnIcon = currentlyExpanded.querySelector('.expand-actions-button .icon'); if (oldBtnIcon) oldBtnIcon.classList.replace('icon-chevron-up', 'icon-chevron-down'); } listItemElement.classList.toggle('expanded'); const btnIcon = listItemElement.querySelector('.expand-actions-button .icon'); if (btnIcon) { if (listItemElement.classList.contains('expanded')) { btnIcon.classList.replace('icon-chevron-down', 'icon-chevron-up'); } else { btnIcon.classList.replace('icon-chevron-up', 'icon-chevron-down'); } } };
    const showHelpModal = () => { const title = "Ajuda - Aba Detalhes da Turma"; const content = ` <h3><span class="icon icon-alunos"></span> Card Alunos</h3> <p>Lista todos os alunos da turma selecionada. Você pode:</p> <ul> <li>Clicar no botão <button class="expand-actions-button" disabled style="padding: 0.3rem 0.6rem; font-size: 0.8rem; background-color: var(--bg-tertiary); color: var(--text-secondary); border: 1px solid var(--border-color); border-radius: 4px;"><span class="icon icon-chevron-down icon-only"></span></button> para ver as ações disponíveis para cada aluno.</li> <li>Promover/Remover <strong>Representante</strong> (<span class="icon icon-representante"></span>) e <strong>Vice</strong> (<span class="icon icon-vice"></span>). Alunos promovidos terão uma borda animada.</li> <li>Acessar <strong>Observações</strong> (<span class="icon icon-anotacao"></span>): Registre anotações, observações (comportamento, desempenho), ocorrências, advertências ou suspensões (com datas de início e fim).</li> <li><strong>Editar</strong> (<span class="icon icon-editar"></span>) os dados do aluno (Nome, Número, Programas Gov.).</li> <li><strong>Mover</strong> (<span class="icon icon-mover"></span>) o aluno para outra turma da mesma escola (histórico de frequência opcional, notas são resetadas).</li> <li><strong>Excluir</strong> (<span class="icon icon-excluir"></span>) o aluno permanentemente da turma.</li> </ul> <h3><span class="icon icon-presenca"></span> Card Presença</h3> <p>Registre a frequência diária dos alunos:</p> <ul> <li>Selecione a <strong>Data</strong> desejada no calendário.</li> <li>Clique em <button class="attendance-toggle present"><span class="icon icon-presenca"></span> P</button> para marcar <strong>Presença</strong> ou <button class="attendance-toggle absent"><span class="icon icon-falta"></span> F</button> para marcar <strong>Falta</strong>.</li> <li>Clicando novamente em <button class="attendance-toggle absent selected justified" disabled><span class="icon icon-falta"></span> FJ</button>, você pode adicionar/editar uma <strong>Justificativa</strong> (o botão mudará para FJ).</li> <li>Use os botões <button class="success" disabled><span class="icon icon-todos-presentes"></span>Todos P.</button> ou <button class="secondary" disabled><span class="icon icon-nao-letivo"></span>Não Letivo</button> para ações rápidas na data selecionada.</li> <li>Alunos com <strong>Suspensão</strong> (<span class="icon icon-suspensao"></span>) ativa na data terão a linha destacada (<span class="suspended-indicator"><span class="icon icon-block"></span> Susp.</span>) e botões P/F desabilitados. Clique na linha para ver detalhes da suspensão.</li> <li>Lembre-se de clicar em <button class="success" disabled><span class="icon icon-salvar"></span> Salvar Presença</button> após as marcações do dia para persistir os dados.</li> <li>Veja o resumo mensal clicando em <button class="secondary icon-button" disabled><span class="icon icon-calendario icon-only"></span></button>.</li> </ul> <h3><span class="icon icon-mapa"></span> Card Mapa da Sala</h3> <p>Visualize e organize a disposição dos alunos na sala:</p> <ul> <li>Clique no ícone <button class="secondary icon-button" disabled><span class="icon icon-editar icon-only"></span></button> para entrar no modo de edição.</li> <li>Ajuste o número de <strong>Fileiras</strong> e <strong>Colunas</strong>.</li> <li>Defina a posição da <strong>Mesa do Professor</strong>.</li> <li>Arraste alunos da lista "Alunos sem lugar" para uma mesa vazia, ou entre mesas.</li> <li>Clique em uma mesa ocupada para desassociar o aluno.</li> <li>Clique em uma mesa vazia e depois em um aluno sem lugar para associá-lo.</li> <li>Clique em <button class="success" disabled><span class="icon icon-salvar"></span> Salvar Mapa</button> para guardar a disposição.</li> </ul> <h3><span class="icon icon-notas"></span> Card Notas e Médias</h3> <p>Gerencie as avaliações e notas dos alunos:</p> <ul> <li>Primeiro, configure a estrutura clicando em <button class="secondary icon-button" disabled><span class="icon icon-estrutura icon-only"></span></button>: Crie "Conjuntos de Notas" (ex: 1º Bimestre), adicione "Instrumentos" (ex: Prova 1, Trabalho) e defina faixas de cores opcionais para as médias.</li> <li>Após configurar, selecione o <strong>Conjunto</strong> desejado no menu dropdown.</li> <li>Insira as notas dos alunos nas colunas correspondentes. A Soma e Média são calculadas automaticamente.</li> <li>Clique em <button class="success" disabled><span class="icon icon-salvar"></span> Salvar Notas</button> para registrar as notas inseridas.</li> <li>Exporte as notas do conjunto selecionado para CSV (<span class="icon icon-upload"></span>) ou PDF (<span class="icon icon-pdf"></span>).</li> </ul> <h3><span class="icon icon-plano"></span> Card Planejamento da Aula</h3> <p>Registre o conteúdo ou tópico planejado para cada dia letivo:</p> <ul> <li>Selecione a <strong>Data</strong> desejada.</li> <li>Digite o planejamento no campo de texto.</li> <li>Clique em <button class="success" disabled><span class="icon icon-salvar"></span> Salvar Plano</button>.</li> </ul> <h3><span class="icon icon-anotacao"></span> Card Anotações da Turma</h3> <p>Espaço para anotações gerais sobre a turma:</p> <ul> <li>Clique em <button class="secondary icon-button" disabled><span class="icon icon-editar icon-only"></span></button> para habilitar a edição.</li> <li>Digite suas anotações gerais sobre a turma (combinados, lembretes, etc.).</li> <li>Clique em <button class="success" disabled><span class="icon icon-salvar"></span> Salvar</button> para guardar as anotações.</li> </ul> <hr style="margin: 1.5rem 0;"> <p>Use o botão <button class="card-toggle-button" disabled><span class="icon icon-chevron-up"></span></button> no canto de cada card para mostrar ou esconder seu conteúdo.</p> `; showModal(title, content, '', 'help-modal'); };
    let touchStartX = 0; let touchEndX = 0; let touchStartY = 0; let isSwiping = false; const swipeThreshold = 110; const verticalThreshold = 60; mainContent.addEventListener('touchstart', (e) => { const targetTagName = e.target.tagName.toLowerCase(); const isInteractive = ['input', 'button', 'select', 'textarea', 'a'].includes(targetTagName); const isInScrollable = e.target.closest('.table-scroll-wrapper, .modal-body, .list-item-actions, #monthly-attendance-table-wrapper, #student-observations-list, .classroom-container, .unassigned-students-list, .school-quorum-info'); if (isInteractive || isInScrollable) { isSwiping = false; return; } touchStartX = e.changedTouches[0].screenX; touchStartY = e.changedTouches[0].screenY; touchEndX = touchStartX; isSwiping = true; }, { passive: true }); mainContent.addEventListener('touchmove', (e) => { if (!isSwiping) return; touchEndX = e.changedTouches[0].screenX; const touchEndY = e.changedTouches[0].screenY; if (Math.abs(touchEndY - touchStartY) > verticalThreshold) { isSwiping = false; } }, { passive: true }); mainContent.addEventListener('touchend', (e) => { if (!isSwiping) { touchStartX = 0; touchEndX = 0; touchStartY = 0; return; } isSwiping = false; const deltaX = touchEndX - touchStartX; const deltaY = e.changedTouches[0].screenY - touchStartY; if (Math.abs(deltaX) > swipeThreshold && Math.abs(deltaX) > Math.abs(deltaY) * 1.8) { const visibleNavButtons = Array.from(navButtons).filter(btn => !btn.disabled && !btn.parentElement.classList.contains('hidden')); const currentActiveIndex = visibleNavButtons.findIndex(btn => btn.classList.contains('active')); if (currentActiveIndex === -1) return; let nextIndex; if (deltaX < 0) { nextIndex = currentActiveIndex + 1; if (nextIndex >= visibleNavButtons.length) return; } else { nextIndex = currentActiveIndex - 1; if (nextIndex < 0) return; } const targetButton = visibleNavButtons[nextIndex]; if(targetButton) { targetButton.click(); } } touchStartX = 0; touchEndX = 0; touchStartY = 0; });
    const notificationMessages = { start: ["<span class='icon icon-rocket-launch'></span> Preparar... Apontar... Aula! Sua aula ({CLASS}) na {SCHOOL} começa em 5 minutos.", "<span class='icon icon-coffee'></span> Último gole de café? Sua aula ({CLASS}) na {SCHOOL} começa em 5 minutos!", "<span class='icon icon-notifications'></span> O sino quase tocou! Aula ({CLASS}) na {SCHOOL} em 5 minutos. ", "<span class='icon icon-directions-run'></span> Corre, professor! Faltam 5 minutos para a aula ({CLASS}) na {SCHOOL} começar.", "<span class='icon icon-auto-awesome'></span> Hora de brilhar! Sua aula ({CLASS}) na {SCHOOL} inicia em 5 minutos.", "<span class='icon icon-alarm'></span> Tic-tac... 5 minutos para o início da aula ({CLASS}) na {SCHOOL}!"], end: ["<span class='icon icon-sports-score'></span> Quase lá! Sua aula ({CLASS}) na {SCHOOL} termina em 5 minutos.", "<span class='icon icon-face'></span> Ufa! Só mais 5 minutinhos de aula ({CLASS}) na {SCHOOL}.", "<span class='icon icon-notifications'></span> O sino da liberdade (quase)! Aula ({CLASS}) na {SCHOOL} acaba em 5 minutos.", "<span class='icon icon-ads-click'></span> Missão quase completa! A aula ({CLASS}) na {SCHOOL} termina em 5 minutos.", "<span class='icon icon-celebration'></span> Bom trabalho! Reta final da aula ({CLASS}) na {SCHOOL} - 5 minutos restantes.", "<span class='icon icon-hourglass-empty'></span> Contagem regressiva: 5 minutos para o fim da aula ({CLASS}) na {SCHOOL}."] };
    const getRandomMessage = (type, scheduleItem) => { const messages = notificationMessages[type]; if (!messages || messages.length === 0) return "Alerta de Horário!"; const randomIndex = Math.floor(Math.random() * messages.length); let message = messages[randomIndex]; const school = findSchoolById(scheduleItem.schoolId); message = message.replace('{CLASS}', sanitizeHTML(scheduleItem.note || '')); message = message.replace('{SCHOOL}', sanitizeHTML(school?.name || 'escola')); return message; };
    const showNotification = (message) => { if (!notificationBanner || !notificationMessage) return; notificationMessage.innerHTML = message; notificationBanner.classList.add('show'); playSound(); setTimeout(hideNotification, 10000); };
    const hideNotification = () => { if (notificationBanner) notificationBanner.classList.remove('show'); };
    const playSound = () => { if (!appData.settings.notificationSoundEnabled) return; if (appData.settings.customNotificationSound) { try { const customAudio = new Audio(appData.settings.customNotificationSound); customAudio.play().catch(error => { console.warn("Erro ao tocar som personalizado:", error); defaultNotificationSound?.play().catch(e => console.warn("Erro ao tocar som padrão (fallback):", e)); }); } catch (error) { console.error("Erro ao criar Audio com som personalizado:", error); defaultNotificationSound?.play().catch(e => console.warn("Erro ao tocar som padrão (fallback 2):", e)); } } else { defaultNotificationSound?.play().catch(error => { console.warn("Erro ao tocar som da notificação padrão:", error); }); } };
    const checkNotifications = () => { shownNotificationsThisMinute = {}; if (!appData.settings.globalNotificationsEnabled) { return; } const now = new Date(); const currentDayIndex = now.getDay(); const currentDayName = weekdays[currentDayIndex]; const currentHour = now.getHours(); const currentMinute = now.getMinutes(); appData.schedule.forEach(item => { if (!item.notificationsEnabled || item.day !== currentDayName || !item.startTime || !item.endTime) { return; } const notificationKeyBase = item.id; try { const [startHour, startMinute] = item.startTime.split(':').map(Number); const [endHour, endMinute] = item.endTime.split(':').map(Number); if (isNaN(startHour) || isNaN(startMinute) || isNaN(endHour) || isNaN(endMinute)) { console.warn(`Invalid time format for schedule item ${item.id}`); return; } let notifyStartMinute = startMinute - NOTIFICATION_LEAD_TIME_MINUTES; let notifyStartHour = startHour; if (notifyStartMinute < 0) { notifyStartMinute += 60; notifyStartHour -= 1; if (notifyStartHour < 0) notifyStartHour = 23; } let notifyEndMinute = endMinute - NOTIFICATION_LEAD_TIME_MINUTES; let notifyEndHour = endHour; if (notifyEndMinute < 0) { notifyEndMinute += 60; notifyEndHour -= 1; if (notifyEndHour < 0) notifyEndHour = 23; } const startNotificationKey = notificationKeyBase + '_start'; if (currentHour === notifyStartHour && currentMinute === notifyStartMinute) { if (!shownNotificationsThisMinute[startNotificationKey]) { console.log(`Triggering START notification for ${item.id}`); const message = getRandomMessage('start', item); showNotification(message); shownNotificationsThisMinute[startNotificationKey] = true; } } const endNotificationKey = notificationKeyBase + '_end'; if (currentHour === notifyEndHour && currentMinute === notifyEndMinute) { if (!shownNotificationsThisMinute[endNotificationKey]) { console.log(`Triggering END notification for ${item.id}`); const message = getRandomMessage('end', item); showNotification(message); shownNotificationsThisMinute[endNotificationKey] = true; } } } catch (error) { console.error(`Error processing schedule item ${item.id}:`, error); } }); };
    const startNotificationChecker = () => { if (notificationCheckInterval) { clearInterval(notificationCheckInterval); } console.log("Starting notification checker..."); checkNotifications(); notificationCheckInterval = setInterval(checkNotifications, 60000); };
    const stopNotificationChecker = () => { if (notificationCheckInterval) { clearInterval(notificationCheckInterval); notificationCheckInterval = null; console.log("Stopped notification checker."); } };
    const updateNotificationSettingsUI = () => { if (enableGlobalNotificationsCheckbox && enableNotificationSoundCheckbox) { enableGlobalNotificationsCheckbox.checked = appData.settings.globalNotificationsEnabled; enableNotificationSoundCheckbox.checked = appData.settings.notificationSoundEnabled; enableNotificationSoundCheckbox.disabled = !appData.settings.globalNotificationsEnabled; } };
    const updateCustomSoundUI = () => { if (!customSoundFilenameDisplay || !currentCustomSoundDisplay || !currentCustomSoundName || !removeCustomSoundButton) return; const soundName = localStorage.getItem('superProfessorPro_customSoundName'); if (appData.settings.customNotificationSound && soundName) { customSoundFilenameDisplay.textContent = soundName; customSoundFilenameDisplay.title = soundName; currentCustomSoundName.textContent = soundName; currentCustomSoundDisplay.classList.remove('hidden'); } else { appData.settings.customNotificationSound = null; localStorage.removeItem('superProfessorPro_customSoundName'); customSoundFilenameDisplay.textContent = 'Nenhum arquivo escolhido'; customSoundFilenameDisplay.title = ''; currentCustomSoundDisplay.classList.add('hidden'); currentCustomSoundName.textContent = ''; } if (customNotificationSoundInput) customNotificationSoundInput.value = null; };
    const handleCustomSoundUpload = (event) => { const file = event.target.files[0]; if (!file) { return; } if (!file.type.startsWith('audio/')) { alert('Por favor, selecione um arquivo de áudio válido (MP3, WAV, OGG, etc.).'); updateCustomSoundUI(); return; } const fileSizeMB = file.size / 1024 / 1024; if (fileSizeMB > MAX_CUSTOM_SOUND_SIZE_MB) { alert(`Arquivo muito grande (${fileSizeMB.toFixed(1)}MB). O limite é ${MAX_CUSTOM_SOUND_SIZE_MB}MB.`); updateCustomSoundUI(); return; } const reader = new FileReader(); reader.onload = (e) => { appData.settings.customNotificationSound = e.target.result; localStorage.setItem('superProfessorPro_customSoundName', file.name); saveData(); updateCustomSoundUI(); alert(`Som "${file.name}" carregado com sucesso!`); }; reader.onerror = (e) => { console.error("Erro ao ler arquivo de áudio:", e); alert("Ocorreu um erro ao tentar carregar o arquivo de som."); updateCustomSoundUI(); }; reader.readAsDataURL(file); };
    const removeCustomSound = () => { if (confirm("Remover o som de notificação personalizado?")) { appData.settings.customNotificationSound = null; localStorage.removeItem('superProfessorPro_customSoundName'); saveData(); updateCustomSoundUI(); alert("Som personalizado removido."); } };
    
    const updateProfileUI = () => {
        if (!appData.userProfile) appData.userProfile = { name: '', avatar: '' };
        if (profileNameInput) profileNameInput.value = appData.userProfile.name || '';
        
        const sideMenuName = document.getElementById('side-menu-name');
        if (sideMenuName) sideMenuName.textContent = appData.userProfile.name || 'Professor';

        const settingsWelcomeName = document.getElementById('settings-welcome-name');
        if (settingsWelcomeName) settingsWelcomeName.textContent = appData.userProfile.name || 'Professor(a)';

        const sideMenuAvatarImg = document.getElementById('side-menu-avatar-img');
        const sideMenuAvatarPlaceholder = document.getElementById('side-menu-avatar-placeholder');

        if (profileAvatarImg && profileAvatarPlaceholder) {
            if (appData.userProfile.avatar) {
                profileAvatarImg.src = appData.userProfile.avatar;
                profileAvatarImg.style.display = 'block';
                profileAvatarPlaceholder.style.display = 'none';
                
                if (sideMenuAvatarImg && sideMenuAvatarPlaceholder) {
                    sideMenuAvatarImg.src = appData.userProfile.avatar;
                    sideMenuAvatarImg.style.display = 'block';
                    sideMenuAvatarPlaceholder.style.display = 'none';
                }
            } else {
                profileAvatarImg.src = '';
                profileAvatarImg.style.display = 'none';
                profileAvatarPlaceholder.style.display = 'block';
                
                if (sideMenuAvatarImg && sideMenuAvatarPlaceholder) {
                    sideMenuAvatarImg.src = '';
                    sideMenuAvatarImg.style.display = 'none';
                    sideMenuAvatarPlaceholder.style.display = 'block';
                }
            }
        }
    };

    const handleAvatarUpload = (event) => {
        const file = event.target.files[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) {
            alert('Por favor, selecione uma imagem válida.');
            return;
        }
        const fileSizeMB = file.size / 1024 / 1024;
        if (fileSizeMB > 2) {
            alert(`A imagem é muito grande (${fileSizeMB.toFixed(1)}MB). O limite é 2MB.`);
            return;
        }
        const reader = new FileReader();
        reader.onload = (e) => {
            if (!appData.userProfile) appData.userProfile = { name: '', avatar: '' };
            appData.userProfile.avatar = e.target.result;
            saveData();
            updateProfileUI();
        };
        reader.onerror = (e) => {
            console.error("Erro ao ler imagem:", e);
            alert("Ocorreu um erro ao tentar carregar a imagem.");
        };
        reader.readAsDataURL(file);
    };

    const saveProfile = () => {
        if (!appData.userProfile) appData.userProfile = { name: '', avatar: '' };
        if (profileNameInput) {
            appData.userProfile.name = profileNameInput.value.trim();
        }
        saveData();
        updateProfileUI();
        alert("Perfil salvo com sucesso!");
    };

    const markAllStudentsPresent = () => { const date = attendanceDateInput.value; if (!currentClassId || !date) { alert("Selecione uma turma e uma data primeiro."); return; } const studentsInClass = getStudentsByClass(currentClassId); if (studentsInClass.length === 0) return; console.log(`Action: Marking all present for class ${currentClassId} on ${date}`); studentsInClass.forEach(student => { if (!student.attendance[date]) student.attendance[date] = { status: null, justification: '' }; if (student.attendance[date].status !== 'H' && !isStudentSuspendedOnDate(student.id, date)) { student.attendance[date].status = 'P'; student.attendance[date].justification = ''; } }); renderAttendanceTable(currentClassId, date); console.log("Data updated for Mark All Present. Remember to Save."); };
    const toggleNonSchoolDay = () => { const date = attendanceDateInput.value; if (!currentClassId || !date) { alert("Selecione uma turma e uma data primeiro."); return; } const studentsInClass = getStudentsByClass(currentClassId); if (studentsInClass.length === 0) return; const isCurrentlyNonSchool = studentsInClass.every(std => std.attendance[date]?.status === 'H'); if (isCurrentlyNonSchool) { if (confirm(`Deseja desmarcar ${formatDate(date)} como dia NÃO LETIVO?\nA presença dos alunos será resetada para esta data.`)) { studentsInClass.forEach(student => { if (!student.attendance[date]) student.attendance[date] = {}; student.attendance[date].status = null; student.attendance[date].justification = ''; }); console.log("Action: Unmarked Non-School Day in data."); renderAttendanceTable(currentClassId, date); alert(`Dia ${formatDate(date)} desmarcado como não letivo. Clique em Salvar Presença para confirmar.`); } } else { if (confirm(`Deseja marcar ${formatDate(date)} como dia NÃO LETIVO para esta turma?\nToda a presença registrada nesta data será substituída por 'H'.`)) { studentsInClass.forEach(student => { if (!student.attendance[date]) student.attendance[date] = {}; student.attendance[date].status = 'H'; student.attendance[date].justification = ''; }); console.log("Action: Marked Non-School Day in data."); renderAttendanceTable(currentClassId, date); alert(`Dia ${formatDate(date)} marcado como não letivo. Clique em Salvar Presença para confirmar.`); } } };
    const editClassroomMap = () => { const cls = findClassById(currentClassId); if (!cls) return; tempClassroomLayout = JSON.parse(JSON.stringify(cls.classroomLayout || { rows: 5, cols: 6, teacherDeskPosition: 'top-center', seats: [] })); clearSeatSelection(); mapRowsInput.value = tempClassroomLayout.rows; mapColsInput.value = tempClassroomLayout.cols; teacherDeskPositionSelect.value = tempClassroomLayout.teacherDeskPosition; classroomMapEditControls.classList.remove('hidden'); renderClassroomMap(currentClassId, true); mapRowsInput.removeEventListener('input', handleDimensionChange); mapColsInput.removeEventListener('input', handleDimensionChange); teacherDeskPositionSelect.removeEventListener('change', handleTeacherDeskChange); mapRowsInput.addEventListener('input', handleDimensionChange); mapColsInput.addEventListener('input', handleDimensionChange); teacherDeskPositionSelect.addEventListener('change', handleTeacherDeskChange); };
    const cancelClassroomMapEdit = () => { tempClassroomLayout = null; clearSeatSelection(); classroomMapEditControls.classList.add('hidden'); renderClassroomMap(currentClassId, false); mapRowsInput.removeEventListener('input', handleDimensionChange); mapColsInput.removeEventListener('input', handleDimensionChange); teacherDeskPositionSelect.removeEventListener('change', handleTeacherDeskChange); };
    const saveClassroomLayout = () => { if (!currentClassId || !tempClassroomLayout) return; const cls = findClassById(currentClassId); if (!cls) return; const newLayout = { rows: parseInt(mapRowsInput.value) || 5, cols: parseInt(mapColsInput.value) || 6, teacherDeskPosition: teacherDeskPositionSelect.value || 'top-center', seats: tempClassroomLayout.seats }; if (newLayout.rows < 1 || newLayout.rows > 20 || newLayout.cols < 1 || newLayout.cols > 20) { alert("Fileiras e Colunas devem estar entre 1 e 20."); return; } cls.classroomLayout = newLayout; saveData(); tempClassroomLayout = null; cancelClassroomMapEdit(); alert("Mapa da sala salvo!"); };
    const handleDimensionChange = () => { if (!tempClassroomLayout) return; const newRows = parseInt(mapRowsInput.value) || tempClassroomLayout.rows; const newCols = parseInt(mapColsInput.value) || tempClassroomLayout.cols; if (newRows !== tempClassroomLayout.rows || newCols !== tempClassroomLayout.cols) { const oldSeats = tempClassroomLayout.seats; tempClassroomLayout.rows = newRows; tempClassroomLayout.cols = newCols; tempClassroomLayout.seats = oldSeats.filter(seat => seat.row <= newRows && seat.col <= newCols); renderClassroomMap(currentClassId, true); } };
    const handleTeacherDeskChange = () => { if (!tempClassroomLayout) return; tempClassroomLayout.teacherDeskPosition = teacherDeskPositionSelect.value; renderClassroomMap(currentClassId, true); };
    const handleStudentListDragStart = (e) => { draggedElement = e.target; draggedStudentId = e.target.dataset.studentId; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', draggedStudentId); setTimeout(() => draggedElement?.classList.add('dragging'), 0); clearSeatSelection(); console.log(`Drag Start (List): Student ID ${draggedStudentId}`); };
    const handleSeatDragStart = (e) => { draggedElement = e.target; draggedStudentId = e.target.dataset.studentId; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', draggedStudentId); setTimeout(() => draggedElement?.classList.add('dragging'), 0); clearSeatSelection(); console.log(`Drag Start (Seat): Student ID ${draggedStudentId} from Row ${e.target.dataset.row}, Col ${e.target.dataset.col}`); };
    const handleDragOver = (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; const target = e.target.closest('.seat, .unassigned-students-list'); if (target) { const targetIsSeat = target.classList.contains('seat'); const targetIsUnassigned = target.classList.contains('unassigned-students-list'); const draggingFromSeat = draggedElement && draggedElement.classList.contains('seat'); if (targetIsSeat && !target.classList.contains('occupied')) { target.classList.add('drag-over'); } else if (targetIsSeat && target.classList.contains('occupied') && draggedStudentId !== target.dataset.studentId) { target.classList.add('drag-over'); } else if (targetIsUnassigned && draggingFromSeat) { target.classList.add('drag-over'); } } };
    const handleDragLeave = (e) => { const target = e.target.closest('.seat, .unassigned-students-list'); if (target) { target.classList.remove('drag-over'); } };
    const handleDropOnSeat = (e) => { e.preventDefault(); const targetSeat = e.target.closest('.seat'); if (!targetSeat || !draggedStudentId || !tempClassroomLayout) return; targetSeat.classList.remove('drag-over'); const targetRow = parseInt(targetSeat.dataset.row); const targetCol = parseInt(targetSeat.dataset.col); const studentBeingDroppedId = e.dataTransfer.getData('text/plain') || draggedStudentId; console.log(`Drop: Student ${studentBeingDroppedId} onto Row ${targetRow}, Col ${targetCol}`); const existingStudentIdInTarget = targetSeat.dataset.studentId; tempClassroomLayout.seats = tempClassroomLayout.seats.filter(seat => seat.studentId !== studentBeingDroppedId); if (existingStudentIdInTarget && existingStudentIdInTarget !== studentBeingDroppedId) { console.log(` -> Target occupied by ${existingStudentIdInTarget}. Unassigning ${existingStudentIdInTarget}.`); tempClassroomLayout.seats = tempClassroomLayout.seats.filter(seat => !(seat.row === targetRow && seat.col === targetCol)); } let seatEntry = tempClassroomLayout.seats.find(s => s.row === targetRow && s.col === targetCol); if (!seatEntry) { seatEntry = { row: targetRow, col: targetCol, studentId: null }; tempClassroomLayout.seats.push(seatEntry); } else if (seatEntry.studentId && seatEntry.studentId !== studentBeingDroppedId){ seatEntry.studentId = null; } seatEntry.studentId = studentBeingDroppedId; console.log(" -> Updated Temp Layout (Drop on Seat):", JSON.parse(JSON.stringify(tempClassroomLayout.seats))); renderClassroomMap(currentClassId, true); draggedElement?.classList.remove('dragging'); draggedStudentId = null; draggedElement = null; };
    const handleDropOnUnassignedList = (e) => { e.preventDefault(); const targetList = e.target.closest('.unassigned-students-list'); if (!targetList || !draggedStudentId || !tempClassroomLayout) return; targetList.classList.remove('drag-over'); const studentBeingDroppedId = e.dataTransfer.getData('text/plain') || draggedStudentId; console.log(`Drop: Student ${studentBeingDroppedId} onto Unassigned List`); const wasSeatOccupied = tempClassroomLayout.seats.some(seat => seat.studentId === studentBeingDroppedId); if (!wasSeatOccupied) { console.log(" -> Student was already unassigned. No change needed."); draggedElement?.classList.remove('dragging'); draggedStudentId = null; draggedElement = null; return; } tempClassroomLayout.seats = tempClassroomLayout.seats.filter(seat => seat.studentId !== studentBeingDroppedId); console.log(" -> Updated Temp Layout (Drop on Unassigned):", JSON.parse(JSON.stringify(tempClassroomLayout.seats))); renderClassroomMap(currentClassId, true); draggedElement?.classList.remove('dragging'); draggedStudentId = null; draggedElement = null; };
    const clearSeatSelection = () => { if (selectedSeatForAssignment) { selectedSeatForAssignment.classList.remove('selected-for-assignment'); selectedSeatForAssignment = null; console.log("Seat selection cleared."); } };
    const handleSeatClickForAssignment = (event) => { const clickedSeat = event.currentTarget; if (!clickedSeat.classList.contains('empty') || !tempClassroomLayout) return; if (selectedSeatForAssignment === clickedSeat) { clearSeatSelection(); } else { clearSeatSelection(); selectedSeatForAssignment = clickedSeat; selectedSeatForAssignment.classList.add('selected-for-assignment'); console.log(`Seat selected for assignment: Row ${clickedSeat.dataset.row}, Col ${clickedSeat.dataset.col}`); } };
    const handleOccupiedSeatClick = (event) => { const clickedSeat = event.currentTarget; if (!tempClassroomLayout || !clickedSeat.classList.contains('occupied')) return; const studentIdToUnassign = clickedSeat.dataset.studentId; const row = parseInt(clickedSeat.dataset.row); const col = parseInt(clickedSeat.dataset.col); if (!studentIdToUnassign) return; const student = findStudentById(studentIdToUnassign); if (confirm(`Desassociar aluno ${sanitizeHTML(student?.name || studentIdToUnassign)} desta mesa (R${row}, C${col})?`)) { console.log(`Click Unassign: Student ${studentIdToUnassign} from Row ${row}, Col ${col}`); tempClassroomLayout.seats = tempClassroomLayout.seats.filter(seat => !(seat.row === row && seat.col === col)); clearSeatSelection(); renderClassroomMap(currentClassId, true); } };
    const handleUnassignedStudentClickForAssignment = (event) => { if (!selectedSeatForAssignment) { console.log("Unassigned student clicked, but no seat selected."); return; } const clickedStudentElement = event.currentTarget; const studentIdToAssign = clickedStudentElement.dataset.studentId; const targetRow = parseInt(selectedSeatForAssignment.dataset.row); const targetCol = parseInt(selectedSeatForAssignment.dataset.col); if (!studentIdToAssign || isNaN(targetRow) || isNaN(targetCol) || !tempClassroomLayout) { console.error("Error during click assignment: Missing data"); clearSeatSelection(); return; } console.log(`Click Assign: Student ${studentIdToAssign} to Row ${targetRow}, Col ${targetCol}`); let seatEntry = tempClassroomLayout.seats.find(s => s.row === targetRow && s.col === targetCol); if (!seatEntry) { seatEntry = { row: targetRow, col: targetCol, studentId: null }; tempClassroomLayout.seats.push(seatEntry); } else if (seatEntry.studentId) { console.warn(`Target seat ${targetRow}-${targetCol} was already occupied by ${seatEntry.studentId} during click assignment. Overwriting.`); } seatEntry.studentId = studentIdToAssign; console.log(" -> Updated Temp Layout (Click Assign):", JSON.parse(JSON.stringify(tempClassroomLayout.seats))); clearSeatSelection(); renderClassroomMap(currentClassId, true); };
    const toggleCardCollapse = (button) => { const card = button.closest('.card'); const icon = button.querySelector('.icon'); if (card && icon) { const isCollapsed = card.classList.toggle('collapsed'); icon.classList.toggle('icon-chevron-down', isCollapsed); icon.classList.toggle('icon-chevron-up', !isCollapsed); button.title = isCollapsed ? 'Mostrar' : 'Esconder'; } };
    const openNameSorterModal = () => { const title = "Sorteador de Nomes"; let content = ''; let footer = ''; const currentClass = currentClassId ? findClassById(currentClassId) : null; const students = currentClass ? getStudentsByClass(currentClassId) : []; if (!currentClass) { content = '<p>Por favor, selecione uma turma na aba "Detalhes" para usar o sorteador.</p>'; } else if (students.length === 0) { content = `<p>Não há alunos cadastrados na turma "${sanitizeHTML(currentClass.name)}".</p>`; } else { sorterStudentList = [...students]; sorterAvailableStudents = [...students]; sorterDrawnStudents = []; content = `<p class="mb-1 text-sm text-secondary">Turma: ${sanitizeHTML(currentClass.name)}</p> <div id="sorter-result-display">-- Clique em Sortear --</div> <div class="sorter-controls mt-2"> <div class="checkbox-group mb-0"> <input type="checkbox" id="sorter-no-repeat"> <label for="sorter-no-repeat">Sortear sem Repetição</label> </div> <span id="sorter-remaining-count" class="sorter-info hidden">${students.length} restantes</span> </div>`; footer = `<button type="button" id="reset-sorter-button" class="secondary"><span class="icon icon-sync"></span> Reiniciar</button> <button type="button" id="sort-next-button" class="success"><span class="icon icon-sorteio"></span> Sortear Próximo</button>`; } showModal(title, content, footer, 'name-sorter-modal'); if (currentClass && students.length > 0) { const sortButton = document.getElementById('sort-next-button'); const resetButton = document.getElementById('reset-sorter-button'); const noRepeatCheckbox = document.getElementById('sorter-no-repeat'); const remainingCountDisplay = document.getElementById('sorter-remaining-count'); const resultDisplay = document.getElementById('sorter-result-display'); const updateRemainingCount = () => { if (noRepeatCheckbox.checked) { remainingCountDisplay.textContent = `${sorterAvailableStudents.length} restantes`; remainingCountDisplay.classList.remove('hidden'); sortButton.disabled = sorterAvailableStudents.length === 0; } else { remainingCountDisplay.classList.add('hidden'); sortButton.disabled = false; } }; sortButton.addEventListener('click', () => sortNextName(resultDisplay, noRepeatCheckbox.checked, updateRemainingCount)); resetButton.addEventListener('click', () => resetSorter(resultDisplay, updateRemainingCount)); noRepeatCheckbox.addEventListener('change', () => resetSorter(resultDisplay, updateRemainingCount)); } };
    const sortNextName = (displayElement, noRepeat, updateCountCallback) => { let listToDrawFrom = noRepeat ? sorterAvailableStudents : sorterStudentList; if (listToDrawFrom.length === 0) { displayElement.textContent = "Fim!"; updateCountCallback(); return; } const randomIndex = Math.floor(Math.random() * listToDrawFrom.length); const drawnStudent = listToDrawFrom[randomIndex]; displayElement.innerHTML = `<span style="font-weight:normal; font-size: 0.8em; display:block;">${drawnStudent.number || '-.'}</span> ${sanitizeHTML(drawnStudent.name)}`; if (noRepeat) { sorterDrawnStudents.push(drawnStudent); sorterAvailableStudents.splice(randomIndex, 1); } updateCountCallback(); };
    const resetSorter = (displayElement, updateCountCallback) => { sorterAvailableStudents = [...sorterStudentList]; sorterDrawnStudents = []; displayElement.textContent = "-- Reiniciado --"; updateCountCallback(); };
    const formatTime = (totalSeconds) => { const hours = Math.floor(totalSeconds / 3600); const minutes = Math.floor((totalSeconds % 3600) / 60); const seconds = totalSeconds % 60; return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`; };
    const updateStopwatchDisplay = () => { const display = document.getElementById('timer-display'); if (display) { display.textContent = formatTime(stopwatchSeconds); } };
    const startStopwatch = () => { if (isStopwatchRunning) return; isStopwatchRunning = true; document.getElementById('start-timer-button')?.classList.add('hidden'); document.getElementById('pause-timer-button')?.classList.remove('hidden'); stopwatchInterval = setInterval(() => { stopwatchSeconds++; updateStopwatchDisplay(); }, 1000); };
    const pauseStopwatch = () => { if (!isStopwatchRunning) return; isStopwatchRunning = false; clearInterval(stopwatchInterval); stopwatchInterval = null; document.getElementById('start-timer-button')?.classList.remove('hidden'); document.getElementById('pause-timer-button')?.classList.add('hidden'); };
    const resetStopwatch = () => { pauseStopwatch(); stopwatchSeconds = 0; updateStopwatchDisplay(); };
    const openTimerModal = () => { const title = "Cronômetro / Timer"; if (stopwatchInterval) clearInterval(stopwatchInterval); stopwatchInterval = null; stopwatchSeconds = 0; isStopwatchRunning = false; const content = `<div id="timer-display">00:00:00</div> <div class="timer-controls"> <button type="button" id="start-timer-button" class="success"><span class="icon icon-play-arrow"></span> Iniciar</button> <button type="button" id="pause-timer-button" class="warning hidden"><span class="icon icon-pause"></span> Pausar</button> <button type="button" id="reset-timer-button" class="secondary"><span class="icon icon-sync"></span> Zerar</button> </div> <hr style="margin: 1.5rem 0 1rem 0; border-color: var(--border-color);"> <p class="text-center text-secondary text-sm">Funcionalidade de Timer (contagem regressiva) em desenvolvimento.</p>`; showModal(title, content, '', 'timer-modal'); document.getElementById('start-timer-button')?.addEventListener('click', startStopwatch); document.getElementById('pause-timer-button')?.addEventListener('click', pauseStopwatch); document.getElementById('reset-timer-button')?.addEventListener('click', resetStopwatch); modal.addEventListener('click', (e) => { if (e.target === modal || e.target.closest('.close-button')) { pauseStopwatch(); } }); };
    const openGroupGeneratorModal = () => { const title = "Gerador de Grupos"; let content = ''; let footer = ''; const currentClass = currentClassId ? findClassById(currentClassId) : null; const students = currentClass ? getStudentsByClass(currentClassId) : []; if (!currentClass) { content = '<p>Por favor, selecione uma turma na aba "Detalhes" para usar o gerador.</p>'; } else if (students.length === 0) { content = `<p>Não há alunos cadastrados na turma "${sanitizeHTML(currentClass.name)}".</p>`; } else { content = ` <p class="mb-1 text-sm text-secondary">Turma: ${sanitizeHTML(currentClass.name)} (${students.length} alunos)</p> <div class="group-options"> <div class="radio-group"> <input type="radio" id="group-by-number" name="group-method" value="number" checked> <label for="group-by-number">Dividir em:</label> <input type="number" id="group-number-input" value="2" min="2"> <label for="group-number-input">grupos</label> </div> <div class="radio-group"> <input type="radio" id="group-by-size" name="group-method" value="size"> <label for="group-by-size">Grupos de:</label> <input type="number" id="group-size-input" value="2" min="1"> <label for="group-size-input">alunos</label> </div> </div> <div id="group-results-container"> <!-- Results will be displayed here --> <p class="text-secondary text-center mt-2">Clique em "Gerar Grupos".</p> </div> `; footer = `<button type="button" id="generate-groups-button" class="success"><span class="icon icon-grupos"></span> Gerar Grupos</button>`; } showModal(title, content, footer, 'group-generator-modal'); if (currentClass && students.length > 0) { const generateButton = document.getElementById('generate-groups-button'); const numberInput = document.getElementById('group-number-input'); const sizeInput = document.getElementById('group-size-input'); const numberRadio = document.getElementById('group-by-number'); const sizeRadio = document.getElementById('group-by-size'); const resultsContainer = document.getElementById('group-results-container'); numberRadio.addEventListener('change', () => { numberInput.disabled = false; sizeInput.disabled = true; }); sizeRadio.addEventListener('change', () => { numberInput.disabled = true; sizeInput.disabled = false; }); numberInput.disabled = !numberRadio.checked; sizeInput.disabled = !sizeRadio.checked; generateButton.addEventListener('click', () => generateGroups(students, resultsContainer)); } };
    const shuffleArray = (array) => { for (let i = array.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [array[i], array[j]] = [array[j], array[i]]; } return array; };
    const generateGroups = (studentList, resultsContainer) => { const method = document.querySelector('input[name="group-method"]:checked').value; const numberInput = document.getElementById('group-number-input'); const sizeInput = document.getElementById('group-size-input'); const shuffledStudents = shuffleArray([...studentList]); let groups = []; resultsContainer.innerHTML = ''; try { if (method === 'number') { const numGroups = parseInt(numberInput.value); if (isNaN(numGroups) || numGroups < 2 || numGroups > shuffledStudents.length) { alert("Número de grupos inválido. Deve ser entre 2 e o número de alunos."); return; } for (let i = 0; i < numGroups; i++) groups.push([]); let currentGroupIndex = 0; shuffledStudents.forEach(student => { groups[currentGroupIndex].push(student); currentGroupIndex = (currentGroupIndex + 1) % numGroups; }); } else { const groupSize = parseInt(sizeInput.value); if (isNaN(groupSize) || groupSize < 1) { alert("Tamanho do grupo inválido. Deve ser pelo menos 1."); return; } for (let i = 0; i < shuffledStudents.length; i += groupSize) { groups.push(shuffledStudents.slice(i, i + groupSize)); } } if (groups.length > 0) { groups.forEach((group, index) => { const groupDiv = document.createElement('div'); groupDiv.classList.add('generated-group'); const groupTitle = document.createElement('h5'); groupTitle.textContent = `Grupo ${index + 1}`; groupDiv.appendChild(groupTitle); const ul = document.createElement('ul'); group.forEach(student => { const li = document.createElement('li'); li.innerHTML = `<span class="student-number">${student.number || '-.'}</span> ${sanitizeHTML(student.name)}`; ul.appendChild(li); }); groupDiv.appendChild(ul); resultsContainer.appendChild(groupDiv); }); } else { resultsContainer.innerHTML = '<p class="text-secondary text-center mt-2">Não foi possível gerar grupos com essas opções.</p>'; } } catch (error) { console.error("Erro ao gerar grupos:", error); resultsContainer.innerHTML = '<p class="text-danger text-center mt-2">Ocorreu um erro ao gerar os grupos.</p>'; } };
    const updateCalculatorDisplay = () => { if(calculatorDisplay) { calculatorDisplay.textContent = calculator.displayValue.replace('.', ','); } };
    const resetCalculator = () => { calculator.displayValue = '0'; calculator.firstOperand = null; calculator.waitingForSecondOperand = false; calculator.operator = null; calculator.weightedPairs = []; if(weightedAverageResult) weightedAverageResult.textContent = '--'; renderWeightedPairsList(); updateCalculatorDisplay(); console.log('Calculator reset'); };
    const inputDigit = (digit) => { const { displayValue, waitingForSecondOperand } = calculator; if (waitingForSecondOperand) { calculator.displayValue = digit; calculator.waitingForSecondOperand = false; } else { calculator.displayValue = displayValue === '0' ? digit : displayValue + digit; } updateCalculatorDisplay(); };
    const inputDecimal = () => { if (calculator.waitingForSecondOperand) { calculator.displayValue = '0.'; calculator.waitingForSecondOperand = false; updateCalculatorDisplay(); return; } if (!calculator.displayValue.includes('.')) { calculator.displayValue += '.'; } updateCalculatorDisplay(); };
    const handleOperator = (nextOperator) => { const { firstOperand, displayValue, operator } = calculator; const inputValue = parseFloat(displayValue.replace(',', '.')); if (operator && calculator.waitingForSecondOperand) { calculator.operator = nextOperator; console.log('Operator changed to', nextOperator); return; } if (firstOperand === null && !isNaN(inputValue)) { calculator.firstOperand = inputValue; } else if (operator) { const result = performCalculation[operator](firstOperand, inputValue); const resultString = Number.isFinite(result) ? String(result) : 'Erro'; calculator.displayValue = resultString; calculator.firstOperand = result; updateCalculatorDisplay(); } calculator.waitingForSecondOperand = true; calculator.operator = nextOperator; console.log('State after operator:', JSON.parse(JSON.stringify(calculator))); };
    const performCalculation = { 'divide': (first, second) => second === 0 ? NaN : first / second, 'multiply': (first, second) => first * second, 'add': (first, second) => first + second, 'subtract': (first, second) => first - second, '=': (first, second) => second, };
    const clearAll = () => { resetCalculator(); };
    const clearEntry = () => { if (calculator.waitingForSecondOperand) { resetCalculator(); } else { calculator.displayValue = '0'; } updateCalculatorDisplay(); };
    const backspace = () => { if (calculator.waitingForSecondOperand) return; calculator.displayValue = calculator.displayValue.slice(0, -1); if (calculator.displayValue === '' || calculator.displayValue === '-') { calculator.displayValue = '0'; } updateCalculatorDisplay(); };
    const handleCalculatorButtonClick = (event) => { const { target } = event; if (!target.matches('button')) return; const action = target.dataset.action; const value = target.dataset.value; const operator = target.dataset.operator; console.log(`Button Click: action=${action}, value=${value}, operator=${operator}`); if (value !== undefined) { inputDigit(value); } else if (operator !== undefined) { handleOperator(operator); } else if (action === 'decimal') { inputDecimal(); } else if (action === 'clearAll') { clearAll(); } else if (action === 'clearEntry') { clearEntry(); } else if (action === 'backspace') { backspace(); } else if (action === 'calculate') { if (calculator.operator && calculator.firstOperand !== null) { handleOperator(calculator.operator); calculator.operator = null; calculator.waitingForSecondOperand = false; } } };
    const addWeightedPair = () => { const gradeStr = weightedGradeInput.value.trim().replace(',', '.'); const weightStr = weightedWeightInput.value.trim().replace(',', '.'); const grade = parseFloat(gradeStr); const weight = parseFloat(weightStr); if (isNaN(grade)) { alert("Por favor, insira uma nota válida."); weightedGradeInput.focus(); return; } if (isNaN(weight) || weight <= 0) { alert("Por favor, insira um peso válido (maior que zero)."); weightedWeightInput.focus(); return; } calculator.weightedPairs.push({ grade, weight }); renderWeightedPairsList(); weightedGradeInput.value = ''; weightedWeightInput.value = ''; weightedGradeInput.focus(); weightedAverageResult.textContent = '--'; };
    const renderWeightedPairsList = () => { if (!weightedPairsList) return; weightedPairsList.innerHTML = ''; if (calculator.weightedPairs.length === 0) { weightedPairsList.innerHTML = '<p>Nenhum par adicionado.</p>'; if (calculateWeightedAvgButton) calculateWeightedAvgButton.disabled = true; return; } if (calculateWeightedAvgButton) calculateWeightedAvgButton.disabled = false; const template = document.getElementById('weighted-pair-item-template'); calculator.weightedPairs.forEach((pair, index) => { const clone = template.content.cloneNode(true); const li = clone.querySelector('.pair-item'); li.dataset.index = index; const textSpan = li.querySelector('span'); textSpan.querySelector('strong:nth-child(1)').textContent = String(pair.grade).replace('.', ','); textSpan.querySelector('strong:nth-child(2)').textContent = String(pair.weight).replace('.', ','); const deleteButton = li.querySelector('.delete-pair-button'); deleteButton.addEventListener('click', () => removeWeightedPair(index)); weightedPairsList.appendChild(clone); }); };
    const removeWeightedPair = (index) => { if (index >= 0 && index < calculator.weightedPairs.length) { calculator.weightedPairs.splice(index, 1); renderWeightedPairsList(); if(weightedAverageResult) weightedAverageResult.textContent = '--'; } };
    const calculateWeightedAverage = () => { if (!weightedAverageResult) return; if (calculator.weightedPairs.length === 0) { weightedAverageResult.textContent = '--'; return; } let totalWeightedSum = 0; let totalWeight = 0; calculator.weightedPairs.forEach(pair => { totalWeightedSum += pair.grade * pair.weight; totalWeight += pair.weight; }); if (totalWeight === 0) { weightedAverageResult.textContent = 'Erro (Peso 0)'; return; } const average = totalWeightedSum / totalWeight; weightedAverageResult.textContent = `Média: ${average.toFixed(2).replace('.', ',')}`; };
    const switchCalculatorMode = (mode) => { calculator.mode = mode; resetCalculator(); if (mode === 'standard') { standardCalcSection?.classList.remove('hidden'); weightedCalcSection?.classList.add('hidden'); calcModeStandardBtn?.classList.add('active'); calcModeWeightedBtn?.classList.remove('active'); } else { standardCalcSection?.classList.add('hidden'); weightedCalcSection?.classList.remove('hidden'); calcModeStandardBtn?.classList.remove('active'); calcModeWeightedBtn?.classList.add('active'); } };
    const openAdvancedCalculatorModal = () => { resetCalculator(); switchCalculatorMode('standard'); calculatorModal?.classList.add('show'); const currentCalcButtonsContainer = document.querySelector('#calculator-standard-section .calculator-buttons'); currentCalcButtonsContainer?.removeEventListener('click', handleCalculatorButtonClick); currentCalcButtonsContainer?.addEventListener('click', handleCalculatorButtonClick); if(calcModeStandardBtn) calcModeStandardBtn.onclick = () => switchCalculatorMode('standard'); if(calcModeWeightedBtn) calcModeWeightedBtn.onclick = () => switchCalculatorMode('weighted'); if(addPairButton) addPairButton.onclick = addWeightedPair; if(calculateWeightedAvgButton) calculateWeightedAvgButton.onclick = calculateWeightedAverage; calculatorModal?.querySelectorAll('[data-dismiss="modal"]').forEach(btn => { const newBtn = btn.cloneNode(true); btn.parentNode.replaceChild(newBtn, btn); newBtn.addEventListener('click', hideModal); }); calculatorModal?.addEventListener('click', (e) => { if (e.target === calculatorModal) { hideModal(); } }, { once: false }); };
    const openToolModal = (toolType) => { if (toolType === 'advanced-calculator') { openAdvancedCalculatorModal(); return; } let title = "Ferramenta"; let content = "<p>Funcionalidade em desenvolvimento.</p>"; let modalClass = ''; let footer = ''; switch (toolType) { case 'name-sorter': openNameSorterModal(); return; case 'timer-stopwatch': openTimerModal(); return; case 'group-generator': openGroupGeneratorModal(); return; default: title = "Funcionalidade Indisponível"; content = "<p>Esta ferramenta ainda não foi implementada.</p>"; } showModal(title, content, footer, modalClass); };
    const updateScheduleItemsUI = () => { if (currentSection !== 'schedule-section' || !scheduleListContainer) return; const now = new Date(); const currentDayIndex = now.getDay(); const currentDayName = weekdays[currentDayIndex]; const currentTimeInMinutes = now.getHours() * 60 + now.getMinutes(); const scheduleItemsElements = scheduleListContainer.querySelectorAll(`.schedule-item`); let nextItemFoundForToday = false; scheduleItemsElements.forEach(el => { const itemId = el.dataset.id; const item = findScheduleById(itemId); if (!item) return; const startMinutes = parseInt(el.dataset.startMinutes); const endMinutes = parseInt(el.dataset.endMinutes); const progressBar = el.querySelector('.progress-bar'); el.classList.remove('current', 'next'); if (progressBar) progressBar.style.width = '0%'; if (item.day === currentDayName && !isNaN(startMinutes) && !isNaN(endMinutes)) { const isCurrent = currentTimeInMinutes >= startMinutes && currentTimeInMinutes < endMinutes; const isUpcoming = currentTimeInMinutes < startMinutes; if (isCurrent) { el.classList.add('current'); const duration = endMinutes - startMinutes; const elapsed = currentTimeInMinutes - startMinutes; const progress = duration > 0 ? Math.min(100, Math.max(0, (elapsed / duration) * 100)) : 0; if (progressBar) progressBar.style.width = `${progress}%`; nextItemFoundForToday = true; } else if (isUpcoming && !nextItemFoundForToday) { el.classList.add('next'); nextItemFoundForToday = true; } } }); };
    const startScheduleUpdates = () => { stopScheduleUpdates(); console.log("Starting schedule UI updates..."); updateScheduleItemsUI(); scheduleUpdateInterval = setInterval(updateScheduleItemsUI, 1000); };
    const stopScheduleUpdates = () => { if (scheduleUpdateInterval) { clearInterval(scheduleUpdateInterval); scheduleUpdateInterval = null; console.log("Stopped schedule UI updates."); } };

    // Funções do Modal de Novidades
    function showWhatsNew() {
        if (!whatsNewModal || !whatsNewTitle || !whatsNewBody) {
            console.error("Elementos do modal de novidades não encontrados!");
            return;
        }
        
        showingWhatsNew = true;
        const isLoggedIn = !!auth.currentUser;
        const lastSeenVersion = localStorage.getItem('lastSeenAppVersion');
        
        // Determinar o título com base no estado
        if (lastSeenVersion === null) {
            whatsNewTitle.innerHTML = "Bem-vindo ao Super Professor Pro! <span class='icon icon-rocket-launch'></span>";
        } else if (lastSeenVersion !== CURRENT_APP_VERSION) {
            whatsNewTitle.textContent = `Novidades da Versão ${CURRENT_APP_VERSION}!`;
        } else {
            whatsNewTitle.innerHTML = "Mantenha seus dados seguros! <span class='icon icon-cloud'></span>";
        }
        
        let newsContent = `
            <p>Confira as últimas melhorias e funcionalidades adicionadas para facilitar ainda mais seu dia a dia:</p>
            
            <h4 style="color: #9b72cb;"><span class="icon icon-auto-awesome"></span> Novas Ferramentas de IA</h4>
            <ul>
                <li><strong><span class="icon icon-auto-awesome"></span> Assistente de Provas:</strong> Gere provas completas com base no assunto e nível escolar, direto na aba Ferramentas.</li>
                <li><strong><span class="icon icon-auto-awesome"></span> Gerador de Questões:</strong> Crie questões específicas (múltipla escolha, dissertativas, etc.) rapidamente.</li>
                <li><strong><span class="icon icon-auto-awesome"></span> Análise de Turma:</strong> Obtenha insights pedagógicos sobre sua turma com base no número de alunos e anotações.</li>
                <li><strong><span class="icon icon-plano"></span> Plano de Aula Inteligente:</strong> O gerador de esboço de aula foi aprimorado e agora conta com uma interface dedicada.</li>
                <li><strong><span class="icon icon-pdf"></span> Exportação para PDF:</strong> Exporte facilmente os conteúdos gerados pela IA (provas, questões, planos) diretamente para PDF.</li>
            </ul>

            <h4 style="color: #28a745;"><span class="icon icon-language"></span> Uso Offline e Nuvem</h4>
            <ul>
                <li><strong><span class="icon icon-signal-cellular-alt"></span> Modo Offline Total:</strong> Agora você pode usar o app sem internet em tempo integral! Suas alterações são salvas no seu dispositivo e sincronizadas automaticamente quando houver conexão.</li>
                <li><strong><span class="icon icon-cloud"></span> Backup em Nuvem:</strong> Seus dados agora estão seguros na sua conta Google. Acesse de qualquer lugar e nunca perca suas informações.</li>
                <li><strong><span class="icon icon-sync"></span> Migração de Dados:</strong> Se você já usa o app sem conta, seus dados locais serão <strong>migrados automaticamente</strong> para a nuvem assim que você criar sua conta e entrar pela primeira vez!</li>
                <li><strong><span class="icon icon-warning"></span> Aviso de Segurança:</strong> Ao fazer <strong>Logout (Sair)</strong>, seus dados locais são removidos por segurança. Certifique-se de estar conectado à internet antes de sair para garantir que tudo foi sincronizado com a nuvem!</li>
            </ul>

            <h4><span class="icon icon-auto-awesome"></span> Outras Funcionalidades</h4>
            <ul>
                <li><strong><span class="icon icon-menu"></span> Novo Menu Lateral:</strong> Agora você pode escolher entre a barra inferior clássica ou um menu lateral (hambúrguer) para ganhar mais espaço na tela!</li>
                <li><strong><span class="icon icon-palette"></span> Temas e Cores:</strong> O menu lateral agora se adapta perfeitamente ao seu tema escolhido, com cores sólidas e elegantes.</li>
                <li><strong><span class="icon icon-rocket-launch"></span> Interface Limpa:</strong> Removemos o botão flutuante para uma experiência mais intuitiva e agradável.</li>
                <li><strong><span class="icon icon-groups"></span> Capacidade Ampliada:</strong> Agora você pode cadastrar até <strong>100 alunos</strong> por turma!</li>
                <li><strong><span class="icon icon-flag"></span> Indicador de Programas Sociais:</strong> Identifique visualmente alunos participantes de programas como Bolsa Família e Pé de Meia.</li>
                <li><strong><span class="icon icon-notas"></span> Quórum da Escola:</strong> Veja a porcentagem de presença geral diretamente na lista de escolas.</li>
                <li><strong><span class="icon icon-anotacao"></span> Categorias de Observações:</strong> Anotações, Ocorrências, Advertências e Suspensões com períodos específicos.</li>
                <li><strong><span class="icon icon-alarm"></span> Barra de Progresso:</strong> Acompanhe o andamento da sua aula atual em tempo real.</li>
            </ul>
        `;

        // Se não estiver logado, adicionamos o destaque sobre o login
        if (!isLoggedIn) {
            sessionStorage.setItem('loginPromptShown', 'true');
            const hasData = appData.schools.length > 0 || appData.schedule.length > 0;
            newsContent += `
                <div style="background: var(--bg-tertiary); padding: 15px; border-radius: 12px; margin-top: 1.5rem; border: 1px solid var(--accent-primary); box-shadow: 0 4px 12px var(--shadow-color);">
                    <h4 style="margin-top: 0; color: var(--accent-primary); display: flex; align-items: center; gap: 8px;">
                        <span class="icon icon-config"></span> Sincronize seus dados! <span class="icon icon-cloud"></span>
                    </h4>
                    <p style="font-size: 0.95rem; margin-bottom: 10px;">${hasData ? 'Vimos que você já tem dados cadastrados! Para nunca perdê-los, recomendamos criar uma conta.' : 'Para que seus dados fiquem sempre salvos e acessíveis de qualquer dispositivo, recomendamos criar uma conta agora.'}</p>
                    <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 0;"><span class="icon icon-auto-awesome"></span> <strong>Sincronização automática:</strong> Seus dados serão salvos na nuvem instantaneamente.</p>
                </div>
            `;
            
            // Alteramos o rodapé para os botões de login
            const modalFooter = whatsNewModal.querySelector('.modal-footer');
            if (modalFooter) {
                modalFooter.innerHTML = `
                    <div style="display: flex; flex-direction: column; gap: 10px; width: 100%;">
                        <button type="button" id="whats-new-login-button" class="primary w-full" style="padding: 14px; font-weight: bold; font-size: 1rem;">Fazer Login / Criar Conta</button>
                        <button type="button" id="whats-new-skip-button" class="secondary w-full" style="padding: 10px; font-size: 0.85rem; border: none; background: transparent; color: var(--text-secondary);">Continuar sem conta (apenas local)</button>
                    </div>
                `;
                
                document.getElementById('whats-new-login-button')?.addEventListener('click', () => {
                    hideWhatsNew();
                    showSection('settings-section');
                    setTimeout(() => { authButton.click(); }, 100);
                });
                
                document.getElementById('whats-new-skip-button')?.addEventListener('click', hideWhatsNew);
            }
        } else {
            // Se já estiver logado, mantemos o botão padrão
            const modalFooter = whatsNewModal.querySelector('.modal-footer');
            if (modalFooter) {
                modalFooter.innerHTML = `<button type="button" id="ok-whats-new">Entendi</button>`;
                document.getElementById('ok-whats-new')?.addEventListener('click', hideWhatsNew);
            }
        }

        whatsNewBody.innerHTML = newsContent;
        whatsNewModal.classList.add('show');
    };

    function hideWhatsNew() { 
        if (whatsNewModal) { 
            whatsNewModal.classList.remove('show'); 
            showingWhatsNew = false;
            console.log("Whats New closed, showingWhatsNew set to false.");
        } 
    };

    // --- Event Listeners Globais e Específicos ---
    navButtons.forEach(button => { 
        button.addEventListener('click', () => { 
            const targetSection = button.dataset.section; 
            if (button.disabled) return; 
            showSection(targetSection); 
        }); 
    });

    const navStyleSelect = document.getElementById('nav-style-select');
    if (navStyleSelect) {
        navStyleSelect.addEventListener('change', (e) => {
            applyNavStyle(e.target.value);
            saveData();
        });
    }

    addScheduleButton.addEventListener('click', () => openScheduleModal());
    addSchoolButton.addEventListener('click', () => openSchoolModal());
    addClassButton.addEventListener('click', () => { if(currentSchoolId) openClassModal(); else alert("Selecione uma escola primeiro!"); });
    backToSchoolsButton.addEventListener('click', () => { currentSchoolId = null; currentClassId = null; showSection('schools-section'); stopScheduleUpdates(); });
    backToClassesButton.addEventListener('click', () => { if (tempClassroomLayout) { cancelClassroomMapEdit(); } showSection('classes-section'); stopScheduleUpdates(); });
    const combinedModalCloseHandler = (e) => { const targetModal = e.currentTarget; if (e.target === targetModal || e.target.closest('.close-button[data-dismiss="modal"]') || e.target.matches('button[data-dismiss="modal"]')) { if (targetModal.id === 'generic-modal' && targetModal.querySelector('#timer-display')) { pauseStopwatch(); } hideModal(); } };
    modal.addEventListener('click', combinedModalCloseHandler);
    calculatorModal.addEventListener('click', combinedModalCloseHandler);
    const aiToolModalEl = document.getElementById('ai-tool-modal');
    if (aiToolModalEl) aiToolModalEl.addEventListener('click', combinedModalCloseHandler);
    addStudentButton?.addEventListener('click', () => { if(currentClassId) openStudentModal(); else alert("Selecione uma turma primeiro!"); });
    gradeSetSelect.addEventListener('change', (e) => { if(currentClassId) { renderGradesTable(currentClassId, e.target.value); } });
    manageGradeStructureButton.addEventListener('click', openGradeStructureModal);
    saveGradesButton.addEventListener('click', saveGrades);
    exportGradesCsvButton?.addEventListener('click', exportGradesCSV);
    exportGradesPdfButton?.addEventListener('click', () => exportGradesPDF());
    attendanceDateInput.addEventListener('change', (e) => { if(currentClassId) { renderAttendanceTable(currentClassId, e.target.value); } });
    markAllPresentButton.addEventListener('click', markAllStudentsPresent);
    markNonSchoolDayButton.addEventListener('click', toggleNonSchoolDay);
    lessonPlanDateInput.addEventListener('change', (e) => { if(currentClassId) { renderLessonPlan(currentClassId, e.target.value); } });
    saveLessonPlanButton.addEventListener('click', saveLessonPlan);
    saveAttendanceButton.addEventListener('click', saveAttendance);
    viewMonthlyAttendanceButton.addEventListener('click', openMonthlyAttendanceModal);
    editClassNotesButton.addEventListener('click', () => toggleClassNotesEdit(true));
    saveClassNotesButton.addEventListener('click', saveClassNotes);
    cancelClassNotesButton.addEventListener('click', () => toggleClassNotesEdit(false));
    copyPixButton?.addEventListener('click', () => {
        const pixKey = pixKeyTextElement.textContent;
        
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(pixKey).then(() => {
                alert("Código PIX copiado para a área de transferência!");
            }).catch(err => {
                console.error("Erro ao copiar PIX:", err);
                fallbackCopyTextToClipboard(pixKey);
            });
        } else {
            fallbackCopyTextToClipboard(pixKey);
        }
        
        function fallbackCopyTextToClipboard(text) {
            const textArea = document.createElement("textarea");
            textArea.value = text;
            textArea.style.top = "0";
            textArea.style.left = "0";
            textArea.style.position = "fixed";
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                const successful = document.execCommand('copy');
                if (successful) {
                    alert("Código PIX copiado para a área de transferência!");
                } else {
                    alert("Não foi possível copiar o código PIX. Por favor, selecione e copie manualmente.");
                }
            } catch (err) {
                console.error("Erro ao copiar PIX:", err);
                alert("Não foi possível copiar o código PIX. Por favor, selecione e copie manualmente.");
            }
            
            document.body.removeChild(textArea);
        }
    });
    const themeSelect = document.getElementById('theme-select');
    if (themeSelect) {
        themeSelect.addEventListener('change', (e) => {
            applyTheme(e.target.value);
            saveData();
        });
    }

    const executeDataActionBtn = document.getElementById('execute-data-action');
    const dataActionSelect = document.getElementById('data-action-select');
    const importDataInput = document.getElementById('import-data-input');

    if (executeDataActionBtn && dataActionSelect) {
        executeDataActionBtn.addEventListener('click', () => {
            const action = dataActionSelect.value;
            if (action === 'export') {
                exportData();
            } else if (action === 'import') {
                importDataInput.click();
            } else if (action === 'clear') {
                clearAllData();
            } else {
                alert("Por favor, selecione uma ação.");
            }
        });
    }
    
    if (importDataInput) {
        importDataInput.addEventListener('change', importData);
    }
    
    if (profileAvatarContainer && profileAvatarInput) {
        profileAvatarContainer.addEventListener('click', () => profileAvatarInput.click());
        profileAvatarInput.addEventListener('change', handleAvatarUpload);
    }
    if (saveProfileButton) {
        saveProfileButton.addEventListener('click', saveProfile);
    }
    
    searchInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') { performSearch(searchInput.value); } });
    searchInput.addEventListener('input', () => { /* No dynamic search */ });
    searchInput.addEventListener('search', () => { if (!searchInput.value) { hideModal(); } });
    notificationCloseButton?.addEventListener('click', hideNotification);
    enableGlobalNotificationsCheckbox?.addEventListener('change', (e) => { appData.settings.globalNotificationsEnabled = e.target.checked; enableNotificationSoundCheckbox.disabled = !e.target.checked; if (!e.target.checked) { stopNotificationChecker(); hideNotification(); } else { startNotificationChecker(); } saveData(); });
    enableNotificationSoundCheckbox?.addEventListener('change', (e) => { appData.settings.notificationSoundEnabled = e.target.checked; saveData(); });
    customNotificationSoundInput?.addEventListener('change', handleCustomSoundUpload);
    removeCustomSoundButton?.addEventListener('click', removeCustomSound);
    editMapButton.addEventListener('click', editClassroomMap);
    cancelMapEditButton.addEventListener('click', cancelClassroomMapEdit);
    saveMapButton.addEventListener('click', saveClassroomLayout);
    unassignedStudentsContainer.addEventListener('dragover', handleDragOver);
    unassignedStudentsContainer.addEventListener('dragleave', handleDragLeave);
    unassignedStudentsContainer.addEventListener('drop', handleDropOnUnassignedList);
    toolsGrid?.addEventListener('click', (e) => { const toolCard = e.target.closest('.tool-card'); if (toolCard && toolCard.dataset.tool) { const toolType = toolCard.dataset.tool; openToolModal(toolType); } });
    mainContent.addEventListener('click', (e) => { const toggleButton = e.target.closest('.card-toggle-button'); if (toggleButton) { toggleCardCollapse(toggleButton); } });
    helpButton?.addEventListener('click', showHelpModal);
    mainContent.addEventListener('scroll', () => { if(classDetailsHeader) { classDetailsHeader.classList.toggle('scrolled', mainContent.scrollTop > 1); } });
    attendanceTableContainer.addEventListener('click', (e) => { const suspendedRow = e.target.closest('tr.clickable-suspended'); if (suspendedRow) { const studentId = suspendedRow.dataset.studentId; const noteIndex = parseInt(suspendedRow.dataset.suspensionNoteIndex); if (studentId && !isNaN(noteIndex)) { console.log(`Click em aluno suspenso ${studentId}, abrindo nota ${noteIndex}`); openStudentNotesModal(studentId, noteIndex); } } });
    studentListContainer.addEventListener('click', (e) => { const targetButton = e.target.closest('button'); if (!targetButton) return; const listItem = targetButton.closest('.list-item[data-id]'); if (!listItem) return; const studentId = listItem.dataset.id; if (targetButton.classList.contains('expand-actions-button') || targetButton.closest('.expand-actions-button')) { toggleActions(listItem); } else if (targetButton.classList.contains('move-student-button') || targetButton.closest('.move-student-button')) { openMoveStudentModal(studentId); } else if (targetButton.classList.contains('set-representative-button') || targetButton.closest('.set-representative-button')) { toggleRepresentative(studentId); } else if (targetButton.classList.contains('set-vice-button') || targetButton.closest('.set-vice-button')) { toggleViceRepresentative(studentId); } else if (targetButton.classList.contains('notes-student-button') || targetButton.closest('.notes-student-button')) { openStudentNotesModal(studentId); } else if (targetButton.classList.contains('edit-student-button') || targetButton.closest('.edit-student-button')) { openStudentModal(studentId); } else if (targetButton.classList.contains('delete-student-button') || targetButton.closest('.delete-student-button')) { if (confirm(`Excluir aluno "${findStudentById(studentId)?.name || ''}"?`)) { deleteStudent(studentId); } } });
    window.addEventListener('beforeunload', saveAppState);

    // Event Listeners para o Modal de Novidades
    closeWhatsNewButton?.addEventListener('click', hideWhatsNew);
    okWhatsNewButton?.addEventListener('click', hideWhatsNew);
    whatsNewModal?.addEventListener('click', (event) => { if (event.target === whatsNewModal) { hideWhatsNew(); } });
    showWhatsNewManualButton?.addEventListener('click', showWhatsNew);


    // --- Inicialização ---
    const updateSyncStatusUI = () => {
        if (!syncStatusText || !lastSyncTimeDisplay) return;
        
        if (!auth.currentUser) {
            syncStatusText.innerHTML = 'Status: <span style="color: #666;">Offline (Sem conta)</span>';
            lastSyncTimeDisplay.textContent = 'N/A';
            if (forceSyncButton) forceSyncButton.disabled = true;
            return;
        }

        if (forceSyncButton) forceSyncButton.disabled = false;
        
        if (navigator.onLine) {
            syncStatusText.innerHTML = 'Status: <span style="color: #28a745;">Online (Sincronizado)</span>';
        } else {
            syncStatusText.innerHTML = 'Status: <span style="color: #ffc107;">Offline (Aguardando conexão)</span>';
        }

        if (appData.lastUpdated) {
            const date = new Date(appData.lastUpdated);
            lastSyncTimeDisplay.textContent = date.toLocaleString();
        } else {
            lastSyncTimeDisplay.textContent = 'Nunca';
        }
    };

    // Firebase Auth Logic
    let isSyncing = false;
    
    const saveToFirestore = async () => {
        if (!auth.currentUser || isSyncing) return;
        if (!navigator.onLine) {
            console.log("Offline: Skipping Firestore save.");
            return;
        }
        try {
            isSyncing = true;
            const dataToSave = JSON.parse(JSON.stringify(appData));
            if (dataToSave.settings) {
                delete dataToSave.settings.customNotificationSound; // Don't save large base64 to Firestore
            }
            const path = 'users/' + auth.currentUser.uid;
            console.log("Attempting to save to Firestore at path:", path);
            console.log("Data to save:", dataToSave);
            try {
                await setDoc(doc(db, 'users', auth.currentUser.uid), dataToSave);
                console.log("Data saved to Firestore.");
            } catch (err) {
                console.error("Error during setDoc:", err);
                throw handleFirestoreError(err, OperationType.WRITE, path);
            }
        } catch (error) {
            console.error("Error saving to Firestore:", error);
        } finally {
            isSyncing = false;
            updateSyncStatusUI();
        }
    };

    const OperationType = {
        CREATE: 'create',
        UPDATE: 'update',
        DELETE: 'delete',
        LIST: 'list',
        GET: 'get',
        WRITE: 'write',
    };

    function handleFirestoreError(error, operationType, path) {
        const errInfo = {
            error: error instanceof Error ? error.message : String(error),
            authInfo: {
                userId: auth.currentUser?.uid,
                email: auth.currentUser?.email,
                emailVerified: auth.currentUser?.emailVerified,
                isAnonymous: auth.currentUser?.isAnonymous,
                tenantId: auth.currentUser?.tenantId,
                providerInfo: auth.currentUser?.providerData.map(provider => ({
                    providerId: provider.providerId,
                    displayName: provider.displayName,
                    email: provider.email,
                    photoUrl: provider.photoURL
                })) || []
            },
            operationType,
            path
        };
        console.error('Firestore Error: ', JSON.stringify(errInfo));
        // Se for erro de permissão, lançamos o erro formatado conforme as diretrizes
        if (errInfo.error.includes('Missing or insufficient permissions')) {
            throw new Error(JSON.stringify(errInfo));
        }
        // Para outros erros, apenas logamos e retornamos o erro original
        return error;
    }

    async function syncDataWithFirestore(user) {
        if (!user) return;
        if (!navigator.onLine) {
            console.log("Offline: Skipping Firestore sync.");
            if (syncStatusText) syncStatusText.innerHTML = 'Status: <span style="color: #6c757d;">Offline (Aguardando conexão)</span>';
            return;
        }
        try {
            const docRef = doc(db, 'users', user.uid);
            let docSnap;
            try {
                docSnap = await getDoc(docRef);
            } catch (err) {
                // Se falhar por estar offline, tentamos do cache
                if (err.message.includes('offline')) {
                    console.warn("Firestore offline, skipping sync.");
                    return;
                }
                throw handleFirestoreError(err, OperationType.GET, 'users/' + user.uid);
            }
            
            const localHasData = appData.schools.length > 0;

            if (docSnap.exists()) {
                const firestoreData = docSnap.data();
                const cloudHasData = firestoreData.schools && firestoreData.schools.length > 0;
                
                const localLastUpdated = appData.lastUpdated || 0;
                const firestoreLastUpdated = firestoreData.lastUpdated || 0;

                // Se o usuário tem dados locais e a nuvem também tem dados, e são diferentes
                if (localHasData && cloudHasData && Math.abs(localLastUpdated - firestoreLastUpdated) > 1000) {
                    const title = "Conflito de Sincronização";
                    const content = `
                        <p>Detectamos dados diferentes no seu dispositivo e na sua conta na nuvem.</p>
                        <p><strong>Dados Locais:</strong> ${appData.schools.length} escolas, atualizado em ${new Date(localLastUpdated).toLocaleString()}</p>
                        <p><strong>Dados na Nuvem:</strong> ${firestoreData.schools.length} escolas, atualizado em ${new Date(firestoreLastUpdated).toLocaleString()}</p>
                        <p style="margin-top: 1rem;">O que você deseja fazer?</p>
                    `;
                    const footer = `
                        <div style="display: flex; flex-direction: column; gap: 10px; width: 100%;">
                            <button type="button" id="migrate-local-to-cloud" class="success w-full">Manter dados deste dispositivo (MIGRAÇÃO)</button>
                            <button type="button" id="use-cloud-data" class="secondary w-full">Usar dados que já estão na nuvem</button>
                        </div>
                    `;
                    
                    showModal(title, content, footer, 'sync-conflict-modal');
                    
                    document.getElementById('migrate-local-to-cloud')?.addEventListener('click', async () => {
                        console.log("User chose to migrate local data.");
                        hideModal();
                        await saveToFirestore();
                        updateSyncStatusUI();
                    });
                    
                    document.getElementById('use-cloud-data')?.addEventListener('click', () => {
                        console.log("User chose to use cloud data.");
                        hideModal();
                        const localSound = appData.settings?.customNotificationSound;
                        appData = firestoreData;
                        if (!appData.settings) appData.settings = {};
                        appData.settings.customNotificationSound = localSound;
                        try { localStorage.setItem(DATA_STORAGE_KEY, JSON.stringify(appData)); } catch(e) {}
                        restoreAppState();
                        renderScheduleList();
                        renderSchoolList();
                        applyTheme(appData.settings.theme);
                        updateNotificationSettingsUI();
                        updateCustomSoundUI();
                        showSection(currentSection || 'schedule-section');
                        updateSyncStatusUI();
                    });
                    return;
                }
                
                if (firestoreLastUpdated > localLastUpdated || !localHasData) {
                    console.log("Cloud data is newer or local is empty. Syncing...");
                    const localSound = appData.settings?.customNotificationSound;
                    appData = firestoreData;
                    if (!appData.settings) appData.settings = {};
                    appData.settings.customNotificationSound = localSound;
                    
                    // Save locally without triggering firestore save
                    try { localStorage.setItem(DATA_STORAGE_KEY, JSON.stringify(appData)); } catch(e) {}
                    
                    restoreAppState();
                    renderScheduleList();
                    renderSchoolList();
                    applyTheme(appData.settings.theme);
                    updateNotificationSettingsUI();
                    updateCustomSoundUI();
                    if (currentSection === 'classes-section' && currentSchoolId) { renderClassList(currentSchoolId); }
                    else if (currentSection === 'class-details-section' && currentClassId) { selectClass(currentClassId, true); }
                    showSection(currentSection || 'schedule-section');
                } else if (localLastUpdated > firestoreLastUpdated) {
                    console.log("Local data is newer. Pushing to cloud...");
                    await saveToFirestore();
                }
                updateSyncStatusUI();
            } else {
                // Novo documento no Firestore
                if (localHasData) {
                    console.log("New account detected. Migrating local data to cloud...");
                }
                await saveToFirestore();
            }
        } catch (error) {
            console.error("Error syncing with Firestore:", error);
            if (syncStatusText) syncStatusText.innerHTML = 'Status: <span style="color: #dc3545;">Erro na sincronização</span>';
        }
    };

    forceSyncButton?.addEventListener('click', () => {
        if (!auth.currentUser) {
            alert("Você precisa estar logado para sincronizar com a nuvem.");
            return;
        }
        if (!navigator.onLine) {
            alert("Você está offline. Conecte-se à internet para sincronizar.");
            return;
        }
        syncDataWithFirestore(auth.currentUser);
        alert("Sincronização iniciada!");
    });

    window.addEventListener('online', updateSyncStatusUI);
    window.addEventListener('offline', updateSyncStatusUI);

    const loggedOutState = document.getElementById('logged-out-state');
    const loggedInState = document.getElementById('logged-in-state');
    const settingsUserEmail = document.getElementById('settings-user-email');

    // showLoginPrompt removido e integrado ao showWhatsNew


    onAuthStateChanged(auth, (user) => {
        if (user) {
            if (settingsUserEmail) settingsUserEmail.textContent = user.email;
            if (loggedOutState) loggedOutState.style.display = 'none';
            if (loggedInState) loggedInState.style.display = 'block';
            syncDataWithFirestore(user);
        } else {
            const wasLoggedIn = settingsUserEmail && settingsUserEmail.textContent !== '';
            if (settingsUserEmail) settingsUserEmail.textContent = '';
            if (loggedOutState) loggedOutState.style.display = 'block';
            if (loggedInState) loggedInState.style.display = 'none';
            
            if (wasLoggedIn) {
                // Reset data when logged out to ensure privacy
                appData = {
                    schools: [], classes: [], students: [], schedule: [],
                    settings: { theme: 'theme-light', globalNotificationsEnabled: true, notificationSoundEnabled: true, customNotificationSound: null, navStyle: 'fixed' }
                };
                currentSchoolId = null;
                currentClassId = null;
                currentSection = 'schedule-section';
                localStorage.removeItem(DATA_STORAGE_KEY);
                localStorage.removeItem('lastSection');
                localStorage.removeItem('lastSchoolId');
                localStorage.removeItem('lastClassId');
                renderScheduleList();
                renderSchoolList();
                applyTheme(appData.settings.theme);
                applyNavStyle(appData.settings.navStyle);
                showSection('schedule-section');
            } else {
                // Se não estava logado e acabou de entrar, verificamos se mostramos o prompt
                // Mas apenas se NÃO estivermos mostrando o modal de novidades (que chamará o prompt ao fechar)
                if (!showingWhatsNew && !sessionStorage.getItem('loginPromptShown')) {
                    console.log("Not showing Whats New, triggering login prompt delay...");
                    setTimeout(showWhatsNew, 2000);
                } else {
                    console.log("Whats New is active or already shown, skipping initial prompt.");
                }
            }
        }
    });

    if (logoutButton) {
        logoutButton.addEventListener('click', async () => {
            const confirmLogout = await customConfirm("Deseja realmente desconectar/trocar de conta?\n\nAviso: Certifique-se de que seus dados foram sincronizados. Alterações não salvas podem ser perdidas.");
            if (confirmLogout) {
                signOut(auth).then(() => {
                    customAlert('Deslogado com sucesso!');
                }).catch((error) => {
                    console.error('Logout error', error);
                });
            }
        });
    }

    authButton.addEventListener('click', () => {
        if (!auth.currentUser) {
            const modalContent = `
                <form id="login-form" style="display: flex; flex-direction: column; gap: 15px;">
                    <div style="text-align: center; margin-bottom: 10px;">
                        <p style="color: var(--text-secondary); font-size: 0.9rem;">Faça login para sincronizar seus dados na nuvem e acessá-los de qualquer dispositivo.</p>
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 10px; background: var(--bg-color); padding: 15px; border-radius: 8px; border: 1px solid var(--border-color);">
                        <button type="button" id="btn-login-google" class="primary" style="display: flex; align-items: center; justify-content: center; gap: 10px; padding: 12px; font-size: 1rem;">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="24px" height="24px"><path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"/><path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"/><path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"/><path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"/></svg>
                            Entrar com Google
                        </button>
                        <p style="text-align: center; font-size: 0.8rem; color: #28a745; margin: 0; font-weight: bold;"><span class="icon icon-auto-awesome"></span> Melhor método e mais seguro</p>
                    </div>

                    <div style="display: flex; align-items: center; margin: 10px 0;">
                        <hr style="flex-grow: 1; border: none; border-top: 1px solid var(--border-color);">
                        <span style="padding: 0 10px; color: var(--text-secondary); font-size: 0.8rem;">OU USE EMAIL</span>
                        <hr style="flex-grow: 1; border: none; border-top: 1px solid var(--border-color);">
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 15px; background: var(--bg-color); padding: 15px; border-radius: 8px; border: 1px solid var(--border-color);">
                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="login-email" style="font-weight: 500;">Email:</label>
                            <input type="email" id="login-email" placeholder="seu@email.com" required style="padding: 10px; border-radius: 6px; border: 1px solid var(--border-color); width: 100%; box-sizing: border-box;">
                        </div>
                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="login-password" style="font-weight: 500;">Senha:</label>
                            <input type="password" id="login-password" placeholder="Sua senha" required style="padding: 10px; border-radius: 6px; border: 1px solid var(--border-color); width: 100%; box-sizing: border-box;">
                        </div>
                        <div style="display: flex; gap: 10px; margin-top: 5px;">
                            <button type="button" id="btn-login-email" class="primary" style="flex: 1; padding: 10px;">Entrar</button>
                            <button type="button" id="btn-register-email" class="secondary" style="flex: 1; padding: 10px;">Registrar</button>
                        </div>
                    </div>
                </form>
            `;
            showModal('Entrar no Super Professor Pro', modalContent, '', 'login-modal-class');
            
            document.getElementById('btn-login-google').addEventListener('click', () => {
                signInWithPopup(auth, provider).then((result) => {
                    hideModal();
                    alert('Logado com sucesso!');
                }).catch((error) => {
                    console.error('Login error', error);
                    alert('Erro ao fazer login: ' + error.message);
                });
            });

            document.getElementById('btn-login-email').addEventListener('click', () => {
                const email = document.getElementById('login-email').value;
                const password = document.getElementById('login-password').value;
                if (!email || !password) {
                    alert('Preencha email e senha.');
                    return;
                }
                signInWithEmailAndPassword(auth, email, password).then(() => {
                    hideModal();
                    alert('Logado com sucesso!');
                }).catch((error) => {
                    console.error('Login error', error);
                    alert('Erro ao fazer login: ' + error.message);
                });
            });

            document.getElementById('btn-register-email').addEventListener('click', () => {
                const email = document.getElementById('login-email').value;
                const password = document.getElementById('login-password').value;
                if (!email || !password) {
                    alert('Preencha email e senha.');
                    return;
                }
                createUserWithEmailAndPassword(auth, email, password).then(() => {
                    hideModal();
                    alert('Registrado e logado com sucesso!');
                }).catch((error) => {
                    console.error('Register error', error);
                    alert('Erro ao registrar: ' + error.message);
                });
            });
        }
    });

    // Service Worker
    if ('serviceWorker' in navigator) { window.addEventListener('load', () => { navigator.serviceWorker.register('./pwabuilder-sw.js', { scope: './' }) .then(registration => { console.log('ServiceWorker registration successful with scope: ', registration.scope); }) .catch(err => { console.log('ServiceWorker registration failed (scope ./): ', err); navigator.serviceWorker.register('./pwabuilder-sw.js') .then(registration => { console.log('ServiceWorker registration successful with relative path scope: ', registration.scope); }) .catch(err2 => { console.log('ServiceWorker registration failed (relative path): ', err2); if (err2.message.includes('404') || err.message.includes('404')) { console.warn("Service Worker file 'pwabuilder-sw.js' not found. Ensure it's in the accessible root or correct relative path."); } else if (err.message.includes('scope') || err2.message.includes('scope')) { console.warn("Service Worker registration failed due to scope mismatch or security issues. Check HTTPS and path."); } }); }); }); }

    // Inicializações Finais
    updateSyncStatusUI();
    const dataWasLoaded = loadData();
    restoreAppState();
    renderScheduleList();
    renderSchoolList();
    applyTheme(appData.settings.theme);
    setTimeout(() => applyNavStyle(appData.settings.navStyle), 100);
    updateNotificationSettingsUI();
    updateCustomSoundUI();
    updateProfileUI();
    const todayStr = getCurrentDateString();
    if (attendanceDateInput) attendanceDateInput.value = todayStr;
    if (lessonPlanDateInput) lessonPlanDateInput.value = todayStr;
    if (currentSection === 'classes-section' && currentSchoolId) { renderClassList(currentSchoolId); }
    else if (currentSection === 'class-details-section' && currentClassId) { selectClass(currentClassId, true); }
    showSection(currentSection || 'schedule-section');
    if (appData.settings.globalNotificationsEnabled) { startNotificationChecker(); }

    // Lógica de Verificação da Versão e Login
    const lastSeenVersion = localStorage.getItem('lastSeenAppVersion');
    const isNewUser = lastSeenVersion === null;
    const hasUpdate = lastSeenVersion !== CURRENT_APP_VERSION;
    const isLoggedOut = !auth.currentUser;

    console.log('Versão Atual do App:', CURRENT_APP_VERSION);
    console.log('Última Versão Vista pelo Usuário:', lastSeenVersion);
    
    // Se for um novo usuário, houver atualização ou estiver deslogado (e não mostrou o prompt nesta sessão)
    if (isNewUser || hasUpdate || (isLoggedOut && !sessionStorage.getItem('loginPromptShown'))) {
        showingWhatsNew = true;
        console.log('Mostrando tela de boas-vindas/novidades...');
        // Pequeno delay para garantir que o app carregou e não conflitar com outros modais iniciais
        setTimeout(() => {
            showWhatsNew();
            // Só atualizamos a versão vista se realmente houve uma mudança ou é novo
            if (isNewUser || hasUpdate) {
                localStorage.setItem('lastSeenAppVersion', CURRENT_APP_VERSION);
                console.log('Versão vista atualizada no localStorage para:', CURRENT_APP_VERSION);
            }
        }, 1000);
    }

    // --- Lógica de IA (Assistente Gemini) ---
    const aiEnableToggle = document.getElementById('ai-enable-toggle');
    const aiSettingsContent = document.getElementById('ai-settings-content');
    const aiTutorialBtn = document.getElementById('ai-tutorial-btn');
    const aiTutorialContent = document.getElementById('ai-tutorial-content');
    const aiApiKeyInput = document.getElementById('ai-api-key');
    const saveAiKeyBtn = document.getElementById('save-ai-key-btn');
    const aiGeneratePlanBtn = document.getElementById('ai-generate-plan-btn');
    // lessonPlanTextarea is already declared at the top of the file
    
    // Carregar estado inicial
    const isAiEnabled = localStorage.getItem('ai_enabled') === 'true';
    const savedApiKey = localStorage.getItem('gemini_api_key') || '';
    
    if (aiEnableToggle) {
        aiEnableToggle.checked = isAiEnabled;
        aiSettingsContent.style.display = isAiEnabled ? 'block' : 'none';
        aiApiKeyInput.value = savedApiKey;
        
        aiEnableToggle.addEventListener('change', (e) => {
            const enabled = e.target.checked;
            localStorage.setItem('ai_enabled', enabled);
            aiSettingsContent.style.display = enabled ? 'block' : 'none';
            updateAiButtonVisibility();
        });
    }

    if (aiTutorialBtn) {
        aiTutorialBtn.addEventListener('click', () => {
            const isHidden = aiTutorialContent.style.display === 'none';
            aiTutorialContent.style.display = isHidden ? 'block' : 'none';
        });
    }

    if (saveAiKeyBtn) {
        saveAiKeyBtn.addEventListener('click', () => {
            const key = aiApiKeyInput.value.trim();
            if (key) {
                localStorage.setItem('gemini_api_key', key);
                showNotification('Chave de IA salva com sucesso!', 'success');
                updateAiButtonVisibility();
            } else {
                localStorage.removeItem('gemini_api_key');
                showNotification('Chave removida.', 'info');
                updateAiButtonVisibility();
            }
        });
    }

    function updateAiButtonVisibility() {
        const enabled = localStorage.getItem('ai_enabled') === 'true';
        const hasKey = !!localStorage.getItem('gemini_api_key');
        const show = (enabled && hasKey);
        
        const aiTools = document.querySelectorAll('.ai-tool');
        aiTools.forEach(tool => {
            tool.style.display = show ? '' : 'none';
        });
    }

    // Chama na inicialização para mostrar/esconder o botão na aba da turma
    updateAiButtonVisibility();

    // --- Lógica do Modal de IA ---
    const aiToolModal = document.getElementById('ai-tool-modal');
    const aiToolTitle = document.getElementById('ai-tool-title');
    const aiToolInputsContainer = document.getElementById('ai-tool-inputs-container');
    const aiToolGenerateBtn = document.getElementById('ai-tool-generate-btn');
    const aiToolLoading = document.getElementById('ai-tool-loading');
    const aiToolResultContainer = document.getElementById('ai-tool-result-container');
    const aiToolResultContent = document.getElementById('ai-tool-result-content');
    const aiToolCopyBtn = document.getElementById('ai-tool-copy-btn');
    const aiToolApplyBtn = document.getElementById('ai-tool-apply-btn');
    const aiToolExportPdfBtn = document.getElementById('ai-tool-export-pdf-btn');

    let currentAiTool = null;

    function openAiModal(toolType) {
        currentAiTool = toolType;
        aiToolResultContainer.classList.add('hidden');
        aiToolResultContent.innerHTML = '';
        aiToolInputsContainer.innerHTML = '';
        aiToolApplyBtn.classList.add('hidden');
        
        if (toolType === 'lesson-plan') {
            aiToolTitle.textContent = 'Gerar Esboço de Aula';
            aiToolInputsContainer.innerHTML = `
                <div class="form-group">
                    <label>Tema da Aula e Ano Escolar:</label>
                    <input type="text" id="ai-input-tema" placeholder="Ex: Revolução Francesa, 8º ano" class="w-full">
                </div>
            `;
            aiToolApplyBtn.classList.remove('hidden');
        } else if (toolType === 'exam-assistant') {
            aiToolTitle.textContent = 'Assistente de Provas';
            aiToolInputsContainer.innerHTML = `
                <div class="form-group">
                    <label>Assunto/Conteúdo da Prova:</label>
                    <input type="text" id="ai-input-assunto" placeholder="Ex: Equações do 2º grau" class="w-full">
                </div>
                <div class="form-group">
                    <label>Nível/Ano Escolar:</label>
                    <input type="text" id="ai-input-nivel" placeholder="Ex: 9º ano do Ensino Fundamental" class="w-full">
                </div>
                <div class="form-group">
                    <label>Quantidade de Questões:</label>
                    <input type="number" id="ai-input-qtd" value="5" min="1" max="20" class="w-full">
                </div>
            `;
        } else if (toolType === 'question-generator') {
            aiToolTitle.textContent = 'Gerador de Questões (Específicas)';
            aiToolInputsContainer.innerHTML = `
                <div class="form-group">
                    <label>Tópico Específico:</label>
                    <input type="text" id="ai-input-topico" placeholder="Ex: Fotossíntese" class="w-full">
                </div>
                <div class="form-group">
                    <label>Tipo de Questão:</label>
                    <select id="ai-input-tipo" class="w-full">
                        <option value="Múltipla Escolha">Múltipla Escolha</option>
                        <option value="Dissertativa">Dissertativa</option>
                        <option value="Verdadeiro ou Falso">Verdadeiro ou Falso</option>
                    </select>
                </div>
            `;
        } else if (toolType === 'analyze-class') {
            aiToolTitle.textContent = 'Analisar Turma';
            
            // Pega os dados da turma atual
            let contextText = "Nenhuma turma selecionada.";
            
            if (currentClassId) {
                const students = getStudentsByClass(currentClassId);
                const classNotes = document.getElementById('class-notes-content').textContent;
                contextText = `Turma com ${students.length} alunos.\nAnotações atuais: ${classNotes}`;
            }
            
            aiToolInputsContainer.innerHTML = `
                <div class="form-group">
                    <label>Contexto da Turma:</label>
                    <textarea id="ai-input-contexto" rows="4" class="w-full" readonly>${contextText}</textarea>
                </div>
                <div class="form-group">
                    <label>O que você deseja analisar?</label>
                    <input type="text" id="ai-input-pergunta" placeholder="Ex: Sugira estratégias para melhorar o engajamento" class="w-full">
                </div>
            `;
        }
        
        aiToolModal.classList.add('show');
    }

    if (aiGeneratePlanBtn) {
        aiGeneratePlanBtn.addEventListener('click', () => {
            const apiKey = localStorage.getItem('gemini_api_key');
            if (!apiKey) {
                showNotification('Configure sua chave de IA na aba de Ajustes.', 'error');
                return;
            }
            openAiModal('lesson-plan');
        });
    }

    const toolExamAssistant = document.getElementById('tool-exam-assistant');
    if (toolExamAssistant) {
        toolExamAssistant.addEventListener('click', () => {
            const apiKey = localStorage.getItem('gemini_api_key');
            if (!apiKey) {
                showNotification('Configure sua chave de IA na aba de Ajustes.', 'error');
                return;
            }
            openAiModal('exam-assistant');
        });
    }

    const toolQuestionGenerator = document.getElementById('tool-question-generator');
    if (toolQuestionGenerator) {
        toolQuestionGenerator.addEventListener('click', () => {
            const apiKey = localStorage.getItem('gemini_api_key');
            if (!apiKey) {
                showNotification('Configure sua chave de IA na aba de Ajustes.', 'error');
                return;
            }
            openAiModal('question-generator');
        });
    }

    const aiAnalyzeClassBtn = document.getElementById('ai-analyze-class-btn');
    if (aiAnalyzeClassBtn) {
        aiAnalyzeClassBtn.addEventListener('click', () => {
            const apiKey = localStorage.getItem('gemini_api_key');
            if (!apiKey) {
                showNotification('Configure sua chave de IA na aba de Ajustes.', 'error');
                return;
            }
            openAiModal('analyze-class');
        });
    }

    if (aiToolGenerateBtn) {
        aiToolGenerateBtn.addEventListener('click', async () => {
            const apiKey = localStorage.getItem('gemini_api_key');
            if (!apiKey) return;

            let promptText = "";

            if (currentAiTool === 'lesson-plan') {
                const tema = document.getElementById('ai-input-tema').value.trim();
                if (!tema) return showNotification('Preencha o tema.', 'error');
                promptText = `Aja como um professor experiente. Crie um esboço de plano de aula sobre: "${tema}". Inclua: 1. Objetivos, 2. Introdução, 3. Desenvolvimento, 4. Conclusão/Atividade. Seja direto e prático. Formate em Markdown.`;
            } else if (currentAiTool === 'exam-assistant') {
                const assunto = document.getElementById('ai-input-assunto').value.trim();
                const nivel = document.getElementById('ai-input-nivel').value.trim();
                const qtd = document.getElementById('ai-input-qtd').value;
                if (!assunto || !nivel) return showNotification('Preencha os campos.', 'error');
                promptText = `Aja como um professor experiente elaborando uma prova. Crie uma prova com ${qtd} questões sobre "${assunto}" para alunos do "${nivel}". Inclua uma mistura de questões objetivas e discursivas. No final, forneça o gabarito. Formate em Markdown.`;
            } else if (currentAiTool === 'question-generator') {
                const topico = document.getElementById('ai-input-topico').value.trim();
                const tipo = document.getElementById('ai-input-tipo').value;
                if (!topico) return showNotification('Preencha o tópico.', 'error');
                promptText = `Aja como um professor. Crie 1 questão do tipo "${tipo}" sobre o tópico "${topico}". Inclua a resposta correta e uma breve explicação. Formate em Markdown.`;
            } else if (currentAiTool === 'analyze-class') {
                const contexto = document.getElementById('ai-input-contexto').value;
                const pergunta = document.getElementById('ai-input-pergunta').value.trim();
                if (!pergunta) return showNotification('Preencha o que deseja analisar.', 'error');
                promptText = `Aja como um coordenador pedagógico experiente. Baseado no seguinte contexto da turma: "${contexto}", responda à seguinte solicitação do professor: "${pergunta}". Seja prático e ofereça estratégias acionáveis. Formate em Markdown.`;
            }

            aiToolGenerateBtn.disabled = true;
            aiToolLoading.classList.remove('hidden');
            aiToolResultContainer.classList.add('hidden');

            try {
                const ai = new GoogleGenAI({ apiKey: apiKey });
                const response = await ai.models.generateContent({
                    model: 'gemini-3-flash-preview',
                    contents: promptText
                });

                const generatedText = response.text;
                
                // Renderiza (pode usar marked.js se disponível, senão apenas texto)
                aiToolResultContent.innerHTML = generatedText.replace(/\n/g, '<br>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
                aiToolResultContent.dataset.rawText = generatedText;
                
                aiToolResultContainer.classList.remove('hidden');
                showNotification('Conteúdo gerado com sucesso!', 'success');

            } catch (error) {
                showNotification('Erro ao conectar com a IA: ' + error.message, 'error');
            } finally {
                aiToolGenerateBtn.disabled = false;
                aiToolLoading.classList.add('hidden');
            }
        });
    }

    if (aiToolCopyBtn) {
        aiToolCopyBtn.addEventListener('click', () => {
            const text = aiToolResultContent.dataset.rawText || aiToolResultContent.innerText;
            navigator.clipboard.writeText(text).then(() => {
                showNotification('Texto copiado!', 'success');
            }).catch(() => {
                showNotification('Erro ao copiar texto.', 'error');
            });
        });
    }

    if (aiToolApplyBtn) {
        aiToolApplyBtn.addEventListener('click', () => {
            const text = aiToolResultContent.dataset.rawText || aiToolResultContent.innerText;
            const currentText = lessonPlanTextarea.value;
            lessonPlanTextarea.value = currentText ? currentText + '\n\n--- Gerado por IA ---\n' + text : text;
            lessonPlanTextarea.dispatchEvent(new Event('input'));
            showNotification('Aplicado ao plano de aula!', 'success');
            aiToolModal.classList.remove('show');
        });
    }

    if (aiToolExportPdfBtn) {
        aiToolExportPdfBtn.addEventListener('click', () => {
            if (typeof html2pdf === 'undefined') {
                showNotification('Biblioteca de PDF não carregada.', 'error');
                return;
            }
            
            const element = document.createElement('div');
            element.innerHTML = `
                <style>
                    .pdf-content p, .pdf-content h1, .pdf-content h2, .pdf-content h3, .pdf-content li {
                        page-break-inside: avoid;
                    }
                </style>
                <div style="font-family: Arial, sans-serif; padding: 20px;" class="pdf-content">
                    <h1 style="color: #333; border-bottom: 2px solid #4285f4; padding-bottom: 10px; page-break-after: avoid;">${aiToolTitle.textContent}</h1>
                    <div style="margin-top: 20px; line-height: 1.6;">
                        ${aiToolResultContent.innerHTML}
                    </div>
                </div>
            `;

            const opt = {
                margin:       10,
                filename:     `${aiToolTitle.textContent.replace(/\s+/g, '_')}.pdf`,
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2, useCORS: true },
                jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' },
                pagebreak:    { mode: ['avoid-all', 'css', 'legacy'] }
            };

            html2pdf().set(opt).from(element).save().then(() => {
                showNotification('PDF exportado com sucesso!', 'success');
            }).catch(err => {
                console.error('Erro ao exportar PDF:', err);
                showNotification('Erro ao exportar PDF.', 'error');
            });
        });
    }

}); // Fim do DOMContentLoaded